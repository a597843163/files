



'''

    爬虫： urllib
        # get请求: 参数是接在url的?后面
        request.urlopen(url)
        request.urlretrieve()

        request.Request(url, headers={})
        myRequest.add_header("User-Agent", "")

        # post请求： paramData会放在http请求体中
        request.Request(url, paramData)

        # json
        json.loads("{}") : 将json字符串->json对象
        json.dumps() : 将json对象->json字符串


        http: 使用最多
        TCP : 即时通信，双向通讯，可靠的，面向连接
        UDP : 不可靠的，一般使用在局域网的情况下, 局域网的智能音箱



'''








