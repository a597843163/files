

# 匿名函数 : 没有名称的函数，lambda
#       一般在把函数当成参数传递时可以使用匿名函数

# 一般的函数
def fn(a, b):
    return a + b


# 匿名函数的写法
fn2 = lambda a, b: a+b
print(fn2(3, 5))



