from flask_sqlalchemy import SQLAlchemy

# 实例化orm模型，此时还未把flask添加上去
db =SQLAlchemy()



