## MySQL数据库

#### 非关系型数据库的优势：

1. 性能

   NOSQL是基于键值对的，可以想象成表中的主键和值的对应关系，而且不需要经过SQL层的解析，所以性能非常高。


2. 可扩展性

   同样也是因为基于键值对，数据之间没有耦合性，所以非常容易水平扩展。

#### 关系型数据库的优势：

1. 复杂查询

   可以用SQL语句方便的在一个表以及多个表之间做非常复杂的数据查询。


2. 事务支持

   使得对于安全性能很高的数据访问要求得以实现。

## MySQL数据库的介绍

##### 发展史

1996年，MySQL 1.0

2008年1月16号 Sun公司收购MySQL。

2009年4月20，Oracle收购Sun公司。


[MySQL](https://baike.baidu.com/item/MySQL/471251)是一种[开放源代码](https://baike.baidu.com/item/%E5%BC%80%E6%94%BE%E6%BA%90%E4%BB%A3%E7%A0%81)的关系型[数据库管理](https://baike.baidu.com/item/%E6%95%B0%E6%8D%AE%E5%BA%93%E7%AE%A1%E7%90%86)系统（RDBMS），使用最常用的数据库管理语言--[结构化查询语言](https://baike.baidu.com/item/%E7%BB%93%E6%9E%84%E5%8C%96%E6%9F%A5%E8%AF%A2%E8%AF%AD%E8%A8%80)（SQL）进行数据库管理。

MySQL是开放源代码的，因此任何人都可以在General Public License的许可下下载并根据个性化的需要对其进行修改。

MySQL因为其速度、可靠性和适应性而备受关注。大多数人都认为在不需要[事务](https://baike.baidu.com/item/%E4%BA%8B%E5%8A%A1)化处理的情况下，MySQL是管理内容最好的选择。



### 一 进入到MySQL数据库

```mysql
#正常的标准形式
mysql -h127.0.0.1 -uroot -p#-h HOST -u USER -p PASSWORD

#每个数据库都有一个默认的root超级管理员
#默认没有数据库的密码

#建议的使用方式
mysql -uroot -p

#如果访问的是本机的数据库 -h可以为 127.0.0.1/localhost/本机的ip地址
```

### 二 对于MySQL数据库的操作

**命令为：**

​	CREATE创建	 DROP删除 	SHOW查看	ALTER修改库或者表的结构

1. 查看所有的数据库

 mysql> show databases;

2. 选择数据库

   use 库名

3. 查看当前所在的数据库

   select database()

4. 查看当前库下 所有的表

   show tables()

5. 创建数据库

   create database 库名

6. 查看创建库的信息

   show create database 库名

7. 创建一个不存在的数据库 python 如果存在在不创建 不存在则创建 （不管在不在 都执行成功 防止报错）

   create database if not exists 库名

8. 删除数据库

   drop database 库名

9. 删除数据库 防止报错

   drop database if exists 库名

10. 设置数据库的字符集

 alter database 库名 character set utf8/latin1(**之前数据库默认latin1**)

11. 创建库 并设置字符集  在该库下创建的表和字段 默认都为 utf8字符编码

    create database 库名 character set utf8


### 三 对数据库的数据表进行操作

1. 查看所有的表

   show tables

2. 删除数据表

   drop table if exists 表名

3. 创建表

   ```mysql
    CREATE TABLE `user` (
      #字段名 数据类型
     `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
     `username` varchar(10) NOT NULL DEFAULT '帅哥',
     `sex` enum('w','m') DEFAULT NULL,
     PRIMARY KEY (`id`)
   ) ENGINE=MyISAM DEFAULT CHARSET=utf8
   ```

4. 对于表字段的删除

   alter table 表名 drop 字段名

5. 给表 添加字段

   alter table 表名 add 字段名..... after 字段名

### MySQL必须知道的

1. MySQL数据库的命令 不区分大小写
2. 每创建一个数据库 都会对应在当前MySQL数据库下 创建 一个为你数据库名字的文件夹 里面包含 该库下面的所有的表
3. 在Windows下 库名也不区分大小写  但是如果是在Linux 下 严格区分大小写
4. \G 以竖着形式进行查看
5. \c 撤销当前的命令
6. 如果 出现引号没有闭合的情况下  必须将另外的引号 补全  再次 \c 撤销命令
7. \q/quit/exit 对数据库进行退出


### MySQL开启不严谨报错

##### 修改my.ini配置文件

**路径:**C:\ProgramData\MySQL\MySQL Server 5.7

sql-mode="NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"

**latin1**有的版本默认字符编码

### MySQL服务无法正常启动的解决方法(1053错误)

是mysql权限问题，**开始->输入services.msc，找到MySQL服务，右键属性，登录，选择此帐户，然后选择Administrator和相应密码，确定。就能启动了。**

### 授权root可以通过外网IP进行访问

GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'password' WITH GRANT OPTION;