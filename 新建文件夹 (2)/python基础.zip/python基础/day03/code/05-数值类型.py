


# 数值类型：number
#   整数int
#   浮点数float

# 整数int
age = 20
print(age)
print(type(age))  # <class 'int'>

# 小数float
height = 1.77
print(height)  # 1.77
print(type(height))  # <class 'float'>

# 整数字符串
age = "20"
print(type(age)) # <class 'str'>


# 整数，小数，字符串的转换
# 转换成整数 int():
# num1 = 10
# num1 = 10.567  #会把小数部分去掉
# num1 = "20"
num1 = "-20"
# num1 = "20.345" #报错
# num1 = "123abc" #报错
num2 = int(num1)
print(num2)
# print(type(num2))


# 转换成小数 float():
# num3 = 10.2
# num3 = 10  # 10.0 ，会保留一位小数
num3 = "10.2"
# num3 = "10"  # 10.0
# num3 = "10abc" # 报错
num4 = float(num3)
print(num4)


# 转换成字符串 str():
# num5 = 100  # "100"
num5 = 11.2  # "11.2"
s = str(num5)
print(s)
print(type(s))  # <class 'str'>



# 浮点数 的精度问题
f1 = 1.1
f2 = 2.2
f3 = f1 + f2
print(f3)  # 3.3000000000000003


# 数值的操作
# max() : 求最大数  方法/函数/功能
n = max(11, 2, -3, 4)
print(n)  # 11

# min() : 求最小数
m = min(11, 2, -3, 4)
print(m)  # -3

# abs() : 求绝对值
n = abs(-2)
print(n)  # 2

# round() : 四舍五入
n = round(34.46)
print(n)  # 34

# 参数1：需要进行四舍五入的小数
# 参数2：需要保留的小数位数
m = round(34.567, 2)
print(m)  # 34.57





