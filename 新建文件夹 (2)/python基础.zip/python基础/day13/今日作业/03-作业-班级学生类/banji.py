# 属性：姓名，年龄，性别，成绩，学号

# 	班级类：
# 		属性：班级号，班级口号，学生列表
# 		方法：
# 			显示所有学生
# 			根据学号查找学生
# 			添加一个学生
# 			根据学号删除一个学生
#

class Student(object):
    def __init__(self,name,age,sex,sorce,student_id):
            self.name = name
            self.age  = age
            self.sex  = sex
            self.sorce= sorce
            self.student_id = student_id

    # 变成字典
    def  key(self):
        return self.student_id
    def value(self):
        return self.name+","+str(self.age)+","+self.sex+","+str(self.sorce)+","+str(self.student_id)

student1 = Student("张三",12,"男",95,123456)
student1key = student1.key()
student1value = student1.value()
student2 = Student("小红",11,"女",100,123457)
student2key = student2.key()
student2value = student2.value()
student3 = Student("小明",10,"男",60,000000)
student3key = student3.key()
student3value = student3.value()
# 对象要返回一个key，value值，添加到班级里面去
class Class(object):
        def __init__(self,number,logan):
            self.number = number
            self.logan  = logan
            self.dict1 = {}
            self.dict1[student1key] = student1value
            self.dict1[student2key] = student2value
            self.dict1[student3key] = student3value
        def studentdict(self):
            return self.dict1
        def findstudent(self,student_id):
            return self.dict1[student_id]
        def addstudent(self,studentkey,studentvalue):
            self.dict1[studentkey]=studentvalue
        def popstudent(self,student_id):
            self.dict1.pop(student_id)
class1 = Class(1701,"我是最棒的")
print(class1.studentdict())
print(class1.findstudent(123457))
print(class1.popstudent(123457))
print(class1.studentdict())
