# -*- coding: utf-8 -*-
import scrapy


class QiushibaikeSpider(scrapy.Spider):
    name = 'qiushibaike'
    # 允许爬的域名
    allowed_domains = ['www.qiushibaike.com']
    start_urls = ['http://www.qiushibaike.com/']

    def parse(self, response):
        # response是scrapy给我们封装好的响应对象
        div_list = response.xpath('//div[contains(@id,"qiushi_tag_")]')
        # print(div_list)
        items = []
        for div in div_list:
            name = div.xpath('.//h2[1]/text()').extract()[0] # 抓到结果后,用extract输出内容
            content = div.xpath('.//div[@class="content"]/span[1]/text()').extract()[0].strip('\n')
            item = {
                'name': name,
                'content': content
            }
            items.append(item)
        return items



