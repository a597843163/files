from django.contrib import admin
from .models import Grade

# 注册Grade,显示在后台管理站点上
admin.site.register(Grade)

