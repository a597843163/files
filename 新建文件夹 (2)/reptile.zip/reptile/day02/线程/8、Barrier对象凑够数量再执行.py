import threading, time


# 创建栅栏对象
barrier = threading.Barrier(3)


def run():
    print('子线程%s开始执行' % (threading.current_thread().name,))

    # 等待
    barrier.wait()

    time.sleep(2)
    print('子线程%s结束执行' % (threading.current_thread().name,))


if __name__ == '__main__':
    print('主线程开始')
    # 创建5个线程
    for i in range(5):
        threading.Thread(target=run).start()

    print('主线程结束')
    time.sleep(3)

    # threading.Thread(target=run).start()