from django.shortcuts import render
from .models import Students,teachers
# Create your views here.

def student(request):
    # 先获得班级所有数据
    s_list = Students.objects.all()
    t_list = teachers.objects.all()
    # 显示在页面上
    return render(request,'student.html',{'s_list':s_list})

def teacher(request):
    # 先获得班级所有数据
    t_list = teachers.objects.all()
    # 显示在页面上
    return render(request,'student.html',{'t_list':t_list})


