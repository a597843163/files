


'''
示例:  小狗吃食（闻一闻smell、舔一舔lick、咬一咬bite）
	  分别采用面向过程和面向对象来分析

面向过程 :  先闻一闻, 然后再舔一舔, 最后再咬一咬 (注重过程)
面向对象 :  小狗是一个对象, 它可以闻一闻食物, 可以舔一舔食物, 可以咬一咬食物. (不注重过程, 注重对象)

'''


# 面向过程
def smell():
    print("闻一闻")

def lick():
    print("舔一舔")

def bite():
    print("咬一咬")

smell()
lick()
bite()


# 面向对象
class Dog:
    def smell(self):
        print("闻一闻")
    def lick(self):
        print("舔一舔")
    def bite(self):
        print("咬一咬")

# 创建小狗对象
dog = Dog()
dog.smell()
dog.lick()
dog.bite()



