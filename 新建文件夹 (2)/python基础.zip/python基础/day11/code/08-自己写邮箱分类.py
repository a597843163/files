#  先遍历目录
#  文件单个处理

import os
def fn1(sourcePath):
    if not os.path.exists(sourcePath):
        return "目录不存在"
    fileNameList = os.listdir(sourcePath)
    for fileName in fileNameList :
        absPath = os.path.join(sourcePath,fileName)
        if os.path.isfile(absPath):
             fn2(absPath)
        if os.path.isdir(absPath):
            fn1(absPath)

def fn2(absPath):
    fenlei = r"F:\python千峰课件\day11\code\\邮箱分类"
    if not os.path.exists(fenlei):
            os.mkdir(fenlei)
    with open(absPath,"r",encoding="utf-8") as fp1 :
        while True:
            str1 = fp1.readline()    #得到了每一行的邮箱
            if len(str1) == 0:      # gao9984@163.com----gaoxiang
                break
            # 对邮编处理，提取名字
            list1 = str1.split("----")
            index1 = list1[0].rfind("@")
            index2 = list1[0].rfind(".")
            str2 = list1[0][index1+1:index2]        #  邮编名字  163

            #  创建路径（文件夹）
            str3 = os.path.join(fenlei,str2)    # 邮箱分类文件夹路径
            if not os.path.exists(str3):
                os.mkdir(str3)
            fileNewName = os.path.join(str3,str2+".txt")   # 文件路径
            with open(fileNewName,"a",encoding="utf-8") as fp2:
                fp2.write(str1)

if __name__ == "__main__":
    path =r"F:\python千峰课件\day11\code\newdir"
    fn1(path)

