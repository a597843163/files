

import re

# 匹配单个字符
# . 表示匹配除了换行以外的任意单个字符， 如果使用re.S,则可以匹配到换行
# res = re.search("go.gle", "gougle")
res = re.search("go.gle", "go\ngle", re.S)
print(res)
res = re.findall("go.gle", "abcgomgledefgongle")  # ['gomgle', 'gongle']
print(res)


# [] : 表示单个字符允许出现的范围
# [abc] : 表示该字符可以是a或b或c
# [345789] :表示可以出现345789中的其中一个
# [0-9] : 表示0到9的数字
# [a-z] : 表示小写
# [A-Z] : 表示大写
# [a-zA-Z] : 表示大写或小写，表示字母
# [a-zA-Z0-9_] : 表示数字字母下划线

# [^] : 如果在[]中有^,则表示取相反的范围
# [^0-9] : 表示非数字
# [^abc] : 表示非abc

# res = re.search("go[0-9]gle", "go6gle")
# res = re.search("go[abc]gle", "goagle")
# res = re.search("go[a-z]gle", "gofgle")
# res = re.search("go[a-zA-Z0-9_]gle", "gofgle")
# res = re.search("go[^0-9]gle", "gofgle")
res = re.search("go[^0-9a-z]gle", "goFgle")
print(res)


# \d : 表示数字，相当于: [0-9]
# \D : 表示非数字， 相当于：[^0-9]
# \w : 表示数字字母下划线， 相当于:[a-zA-Z0-9_]
# \W : 表示非数字字母下划线， 相当于:[^a-zA-Z0-9_]
# \s : 表示换行符\n，空格 ，换页符\f，制表符\t，回车符\r, 相当于:[\n \f\t\r]
# \S : 表示非换行符\n，空格 ，换页符\f，制表符\t，回车符\r, 相当于:[^\n \f\t\r]

# res = re.search("go\dgle", "go8gle")
# res = re.search("go\Dgle", "go8gle")  # None
# res = re.search("go\wgle", "go8gle")
# res = re.search("go\Wgle", "go8gle")  # None
# res = re.search("go\sgle", "go gle")
res = re.search("go\Sgle", "go gle")  # None
print(res)


# 边界匹配
# ^ : 表示行首匹配， 是否以指定字符串开头
# $ : 表示行尾匹配， 是否以指定字符串结尾
# ^  $ : 表示完全匹配
# \A : 表示开头匹配
# \Z : 表示结尾匹配

# ^$跟\A\Z 的区别： 如果是在re.M换行模式下，^$是会按照每一行单独匹配（每一行都会重新匹配）
#                                       \A\Z是不会按照每一行单独匹配

# \b : 边界匹配, 单词是否以某字符串结尾
# \B : 边界非匹配, 单词出现，且不是以某字符串结尾

res = re.search("^google", "google123")
res = re.search("^google", "abcgoogle123")  # None
res = re.search("google", "abcgoogle123")
res = re.search("google$", "abcgoogle")
res = re.search("google$", "abcgoogle123")  # None
res = re.search("^google$", "google")
res = re.search("^google$", "googlegoogle")  # None
res = re.search("^go[a-z]+gle$", "gooooooogle")   # + :表示前面字符串可以出现1次或多次

res = re.search("\Agoogle", "google123")
res = re.search("\Agoogle", "abcgoogle123")  # None
res = re.search("google\Z", "abcgoogle")
res = re.search("google\Z", "abcgoogle123")  # None
res = re.search("\Agoogle\Z", "google")
res = re.search("\Agoogle\Z", "googlegoogle")  # None

print(res)

# ^$ 和 \A\Z 的区别
res = re.findall("^#", "#google\n#baidu", re.M)  # ['#', '#']
res = re.findall("\A#", "#google\n#baidu", re.M)  # ['#']
print(res)

# \b ： 写成 \\b
# res = re.search("google\\b", "agoogle googleabc")  # 'agoogle'
res = re.search("google\B", "agoogle googleabc")  # 'google'
print(res)



# 数量
# ? : 表示出现0次或1次
# * ：表示出现0次或多次
# + ：表示出现1次或多次
# {} ：表示数量范围
# {4} : 表示出现4次
# {2,5} : 表示2次到5次
# {2,} : 表示至少2次
# {,5} : 表示最多5次

# 贪婪模式： 尽量多的匹配
# 非贪婪模式

res = re.findall("g?", "google")  # ['g', '', '', 'g', '', '', '']
res = re.findall("g?", "googgggle")   # ['g', '', '', 'g', 'g', 'g', 'g', '', '', '']， 非贪婪模式
res = re.findall("g*", "google")  # ['g', '', '', 'g', '', '', '']
res = re.findall("g*", "googgggle")  # ['g', '', '', 'gggg', '', '', ''] ， 贪婪模式
res = re.findall("g+", "google")  # ['g', 'g']
res = re.findall("g+", "googgggle")  # ['g', 'gggg'], 贪婪模式

res = re.findall("g{4}", "googgggle")  # ['gggg']
res = re.findall("g{2,5}", "googgggle")  # ['gggg']
res = re.findall("g{2,}", "googgggle")  # ['gggg']
res = re.findall("g{,5}", "googgggle")  # ['g', '', '', 'gggg', '', '', '']
print(res)


# 匹配用户名： 6-18位，数字字母下划线，且不能以数字开头
def fn(str):
    # res = re.search("[a-zA-Z_]\w{5,17}", str)
    res = re.search("^[a-zA-Z_]\w{5,17}$", str)
    if res:
        return True
    return False

print(fn("abc123"))

# 如果不写边界判断，如：^ $， 则表示只要字符串str中出现正则表达式指定的字符串即可，可以有其他多余的字符


# 中文
chinesePattern = "[\u4e00-\u9fa5]+"
res = re.search(chinesePattern, "fadsf哈哈")
print(res)

# 匹配手机号
# 规则：长度11位, 每位都是数字
#       第1位是1
#       第2位是3,4,5,7,8,9
#       第3位是0-9
#       后8位是0-9
phonePattern = r"^1[345789]\d{9}$"
res = re.search(phonePattern, "12345678901")  # None
res = re.search(phonePattern, "13456789012")
print(res)



# x|y  : x或y
# \d|X : 数字或者X


# 匹配qq号： 5-11位, 第一位不能为0
qqReg = "^[1-9]\d{4,10}$"


# 匹配任意一个邮箱   如：jack@163.com
#   jack@163.com
#   dd@1000phone.com
#   dd@126.cn
#   333@qq.com
#   sss@sina.com.cn
#   aaa.bbb.sss@sina.com.cn
# emailReg = "^\w+@163\.com$"  # 163邮箱
emailReg = "^\w+((\.\w+)*)@\w+(\.\w+)+$"


# 匹配身份证
# 321123 19991122 0088
idcardReg = "^\d{17}(\d|X)$"
# idcardReg = "^[1-6]{2}\d{4}((19)|(20))\d{2}[01]\d{5}(\d|X)$"








































