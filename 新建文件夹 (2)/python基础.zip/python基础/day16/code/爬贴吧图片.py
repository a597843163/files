from urllib import request
import  re
import os
url = "https://tieba.baidu.com/f?ie=utf-8&kw=%E8%A1%A8%E6%83%85%E5%8C%85&fr=search"

# 得到带用户代理的请求
Myrequest = request.Request(url,headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36"})
# 响应请求
response = request.urlopen(Myrequest)
htmlStr = response.read().decode("utf-8")
# 找链接 (正则)
lianjie = re.compile('<div class="threadlist_title pull_left j_th_tit ">(.*?)<div class="threadlist_author pull_right">',re.S)
resList = lianjie.findall(htmlStr,re.M)
for i in resList :
    lianjie2 = re.compile('href="(.*?)" title=',re.S)
    lianjieList = lianjie2.findall(i)
    endlianjie = "https://tieba.baidu.com"+lianjieList[0]
    # print(endlianjie) # 进入连接
    # 打开连接
    Myrequest1 = request.Request(endlianjie,headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36"})
    # 响应请求
    response = request.urlopen(Myrequest1)
    htmlStr1 = response.read().decode("utf-8")
    # print(htmlStr1)
    # 找图片连接
    # 范围
    jpg1 = re.compile('img class="BDE_Image".*?src="(.*?)"',re.S)
    jpgList = jpg1.findall(htmlStr1,re.M)
    # print(jpgList)
    if not len(jpgList)==0:
        for j in range(len(jpgList)):       #  j是图片连接
            path = r"C:\Users\sdsd\Desktop\电影名"
            jpgname = (jpgList[j].split("/"))[-1]
            absPath = os.path.join(path,jpgname)
            request.urlretrieve(jpgList[j],absPath)
            request.urlcleanup()









