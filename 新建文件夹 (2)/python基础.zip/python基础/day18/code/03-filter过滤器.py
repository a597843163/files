


# filter()


# 保留偶数
def fn(n):
    if n%2 == 0:
        return True

res = filter(fn, list(range(1, 101)))
print(res)  # <filter object at 0x00000000023FA978>
print(list(res))  # [2, 4, 6, 8, 10, 12, 14, ...]


# sorted()



