from django.conf.urls import url
from .views import grade_list


urlpatterns = [
    url(r'^list/$', grade_list),
    
    
]

