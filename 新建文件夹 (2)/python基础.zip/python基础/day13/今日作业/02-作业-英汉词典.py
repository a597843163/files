
# 英汉字典：使用类封装 Translate
#
# 如：
#   输入：a    得到结果：art. 一;字母A
#   输入：abc  得到结果：n. 基础知识;美国广播公司;澳大利亚广播公司
#

class Translate(object):
    def __init__(self,n):
        self.n = n
        self.dict1 ={}

    def lookup(self):
        fp = open("dict_eng.txt", "r", encoding="utf-8")
        res = fp.read()
        list1 = res.splitlines()
        for i in range(len(list1) // 2):
            str1 = list1[2 * i]
            str2 = list1[2 * i + 1]
            key = str1.replace("#","")
            value = str2.replace("Trans:","")
            self.dict1[key] = value
        fp.close()
        return self.dict1.get(self.n)

translate = Translate("abc")
print(translate.lookup())