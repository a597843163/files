alert("Hi")

function add(a, b){
	return a + b
}
