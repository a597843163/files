import threading,time

# 创建一个条件变量实例对象
condition = threading.Condition()

# 输出偶数
def even():
    with condition: #获取锁,使用前线程必须已获得锁定，否则将抛出异常。
        for i in range(0,10,2):
            print(i)
            condition.wait() #当前线程执行完成，等待另一个线程执行，并释放锁
            #通知对方
            condition.notify() #通知另一个线程可以运行了,遇到wait才会通知

def odd():
    with condition: #获取锁
        for i in range(1,10,2):
            print(i)
            #发送通知
            condition.notify() #通知上面的线程不用等了，该走了
            #等待
            condition.wait() #然后等待上一个线程给自己继续执行的信号

if __name__ == '__main__':
    t1 = threading.Thread(target=even)
    t2 = threading.Thread(target=odd)
    t1.start()
    t2.start()

