

#
#  类：创建类的目的是为了创建对象，同一个类可以创建任意多个具有相同属性和方法的对象
# 对象：由类创建的， 我们一般情况下都是使用对象
#
#   类： 泛指，指的是一类
#   对象： 具体的某一个实物，具体的
#
#   类               对象
#   人            宝强，马蓉
#  电脑           我的那台电脑
# 联想电脑        你的那台联想电脑
#  益达            你的那盒益达
#

#
#   类 是对象的抽象
#   对象 是类的具体
#
#  类创建对象：
#       比如生产苹果手机：
#           类： 生产苹果手机的模型
#           对象： 生产出来的每一台具体的苹果手机
#

#  父类 ： 被继承的类，  基类
#  子类 ： 继承父类的类，派生类

# class : 用来声明类
# Person : 类名，可以自定义，一般遵守大驼峰原则
# object : 超类，python语言顶级的类

# 创建一个Person类 继承了object类

# 创建类
class Person(object):

    # 属性
    name = "宝强"
    age = 33

    # 方法
    # self ： 指向当前类的对象， 主要是在类的内部使用
    #    类中方法的第一个参数需要写上self
    def eat(self):
        # self.name ：是类内部的对象调用了类内部属性name
        print(self.name, "是吃货")


# 类： 不占内存
# 对象： 占内存

# 创建对象
baoqiang = Person()
baoqiang.eat()  # 调用方法时不需要给self传参数
print(baoqiang.name)
print(baoqiang.age)



# 苹果手机类
# 分析苹果手机类中的属性和方法
#   属性：类型，尺寸，颜色，价格
#   方法：打电话，看电影，拍照，玩游戏，可以聊天
#
class Iphone(object):

    # 属性（静态的）
    model = "iphoneX"
    size = 5.8
    color = "黑色"
    price = 7000

    # 方法（行为，功能，动态的）
    def call(self):
        print("打电话")

    def watchMoive(self):
        print("看电影")

    def takePhoto(self):
        print("拍照")

    def playKingofGlory(self):
        print("玩王者荣耀")

    def chat(self):
        print("聊天")


# 创建对象（实例化）
iphoneX = Iphone()
print(iphoneX.model)
print(iphoneX.size)
print(iphoneX.color)
print(iphoneX.price)
iphoneX.call()
iphoneX.watchMoive()
iphoneX.takePhoto()
iphoneX.playKingofGlory()
iphoneX.chat()

# 创建另外一个对象
iphone8 = Iphone()
print(iphone8.color)
iphone8.playKingofGlory()
