import urllib.request
import re
# 分别爬取下面url的亚马逊图片，保存到本地images文件夹中

# url = "https://www.amazon.cn/s/ref=lp_2152154051_pg_2?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=2&ie=UTF8&qid=1516169582"
# url = "https://www.amazon.cn/s/ref=sr_pg_3?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=3&ie=UTF8&qid=1516169970"
# url = "https://www.amazon.cn/s/ref=sr_pg_4?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=4&ie=UTF8&qid=1516171321"
#

url = "https://www.amazon.cn/s/ref=lp_2152154051_pg_2"

paramDict = {
    "rh":"n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051",
    "page":"2",
    "ie":"UTF8",
    "qid":"1516169582"
}

# 把参数字典变成字符串
paramStr = urllib.parse.urlencode(paramDict)
paramData = paramStr.encode("utf-8")
# 把参数和url组成请求体
myRequest = urllib.request.Request(url,paramData)
print(1)

#得到网页代码
response = urllib.request.urlopen(myRequest)
htmlStr = response.read().decode("utf-8")
print(htmlStr)

# 图片大范围正则
reCom = re.compile('<div class="a-row a-gesture a-gesture-horizontal(.*?)<div class="a-section a-spacing-none a-text-center"></div>')
List1 = reCom.findall(htmlStr)
# print(List1)
# reCom = re.compile('<li id="result_.*?<img.*? src=\'(.*?)')





