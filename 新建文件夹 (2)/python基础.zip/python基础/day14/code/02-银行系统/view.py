


# 界面类
# View
#   功能：显示欢迎界面, 登录界面， 显示功能界面
#

import time

class View(object):

    # 模拟登录的账户
    loginDict = {"nie": "123456", "lisi":"123456"}

    # 显示欢迎界面
    @classmethod
    def welcomeView(cls):
        print("********************************************")
        print("***********                     ************")
        print("***********     聂氏银行系统     ************")
        print("***********     version:1.0     ************")
        print("***********                     ************")
        print("***********      OPPO R11S      ************")
        print("***********      照亮你的美      ************")
        print("***********                     ************")
        print("********************************************")

        # 显示logo和广告2秒
        time.sleep(2)

    # 登录界面
    @classmethod
    def loginView(cls):

        # loginDict = {"nie": "123456", "lisi": "123456"}

        # 模拟用户登录银行
        # 输入用户名
        userNameInput = input("请输入您的账号名称:")

        # 检测账号是否存在
        if not userNameInput in cls.loginDict:
            print("您输入的账号不存在")
            return -1


        # 输入密码
        passwdInput = input("请输入您的密码:")

        if passwdInput != cls.loginDict[userNameInput]:
            print("您输入的密码错误")
            return -1

        # 用户和密码输入成功， 登录成功！
        print("恭喜您，登录成功！ 正在加载系统...")
        time.sleep(2)


    # 功能界面
    @classmethod
    def functionView(cls):
        # 开户   查询    存款   取款    转账   改密   锁定    解锁     补卡   销户     退出

        print("********************************************")
        print("******                                ******")
        print("******          主功能界面             ******")
        print("******     (1)开户      (2)查询        ******")
        print("******     (3)存款      (4)取款        ******")
        print("******     (5)转账      (6)改密        ******")
        print("******     (7)锁定      (8)解锁        ******")
        print("******     (9)补卡      (0)销户        ******")
        print("******           (q)退出               ******")
        print("******                                 ******")
        print("******         OPPO R11S               ******")
        print("******         照亮你的美              ******")
        print("******                                 ******")
        print("*********************************************")



