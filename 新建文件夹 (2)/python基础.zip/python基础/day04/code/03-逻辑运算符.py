

'''

    逻辑运算符: and并且(与)， or或者， not非（取反）

        and: 且
            格式： 表达式1 and  表达式2
                表达式1=True, 表达式2=True  结果：True
                表达式1=True, 表达式2=False  结果：False
                表达式1=False, 表达式2=True  结果：False
                表达式1=False, 表达式2=False  结果：False

            归纳：两个都会真才为真，有一个为假则为假
'''

print(True and True)   # True
print(True and False)  # False
print(False and True)  # False
print(False and False) # False

print(4>3 and 4<5)  #True
# 3 + 2*4/6 + 100

# 短路操作
# 会先从左边开始判断，如果表达式的boolean类型为Flase，则直接返回该表达式的值
# Boolean中假的情况：0,"",None,[]
print(0 and 3)


'''
    or : 或者
        格式： 表达式1 or 表达式2
            表达式1=True or 表达式2=True  结果:True
            表达式1=True or 表达式2=False  结果:True
            表达式1=False or 表达式2=True  结果:True
            表达式1=False or 表达式2=False  结果:False
        
        归纳： 两个都会假才为假，只要有一个为真则为真    
    
'''

print(True or True)  # True
print(True or False)  # True
print(False or True)  # True
print(False or False)  # False

print(4>5 or 4>3)  #True


# 短路操作
# 从左往右依次判断，如果表达式的boolean的值为True，则直接返回该表达式的值
n = 3 or print(22)
print(n)


'''
    not: 非
        格式： not 表达式
            如果表达式=True  结果：False
            如果表达式=False 结果：True
    
'''

print(not True)  # False
print(not False)  # True

print(not 3>4)   # True

sex = "女"
if not sex == "男":
    print("不是男的")
else:
    print("是男的")


# 判断一个年份是否为闰年: 满足下面2个条件之一
#       1, 能够被4整除，且不能被100整除
#       2, 能够被400整除
year = int(input("请输入一个年份:"))
if (year%4==0 and year%100!=0) or year%400==0:
    print(year, "是闰年")
else:
    print(year, "是平年")



