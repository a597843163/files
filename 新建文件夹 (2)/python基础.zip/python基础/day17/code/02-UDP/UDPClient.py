

import socket

# UDP客户端

# 1, 创建UDP客户端的socket对象
# 2, 发送数据给服务端


# 1, 创建UDP客户端的socket对象
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 2, 发送数据给服务端
while True:

    # 发送数据
    sendData = input("客户端说: ")
    clientSocket.sendto(sendData.encode("utf-8"), ("10.36.137.101", 8887))

    # 接收数据
    data, address = clientSocket.recvfrom(1024)
    print("服务端说: ", data.decode("utf-8"))
    print("服务端说: ", address)















