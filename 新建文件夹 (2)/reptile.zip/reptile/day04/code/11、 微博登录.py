import urllib.request
import urllib.parse
import ssl
ssl._create_default_https_context = ssl._create_unverified_context

url = 'https://weibo.cn/2952685222/info'

# 设置头

headers = {
    'Host': 'weibo.cn',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Referer': 'https://weibo.cn/',
    'Accept-Language': 'zh-CN,zh;q=0.8',
    'Cookie': 'SCF=Al7z9PQcdgDMtjU17Dc_qW_0BZFA_Y275EsjJ-fmtM_rRucgJzgWVSwJf5q_-3IjQcdx4EOSwRwuv26bOFIbop4.; _T_WM=fae15839e7f4ff08c133adec8d92e8ae; _T_WL=1; _WEIBO_UID=2952685222; __guid=78840338.3732632820391480300.1527827377220.1392; SUB=_2A252FIlaDeRhGeRH7lAX-CvOyT6IHXVV9hcSrDV6PUJbkdANLRjAkW1NTcfzNBjQcPZe50ZI841Sysp85nnLMdMG; SUHB=0mxkZ7lZqbv87G; SSOLoginState=1527838986; monitor_count=27; Hm_lvt_52e895bbbf9a11fe56d2062a5dcf5248=1527838682,1527838693,1527838770,1527838775; Hm_lpvt_52e895bbbf9a11fe56d2062a5dcf5248=1527838980',
}

# 创建request对象
request = urllib.request.Request(url=url, headers=headers)

response = urllib.request.urlopen(request)

print(response.read().decode('utf-8'))