import urllib.request
import http.cookiejar
import urllib.parse
import ssl
ssl._create_default_https_context = ssl._create_unverified_context

# 创建cookie对象
cookie = http.cookiejar.CookieJar()

# 创建handler
hanlder = urllib.request.HTTPCookieProcessor(cookie)

# 创建opener
opener = urllib.request.build_opener(hanlder)

data = {
    'username': '18676689715',
    'password': 'xuke666',
    'savestate': '1',
    'r': 'http://weibo.cn/',
    'ec': '0',
    'pagerefer': '',
    'entry': 'mweibo',
    'wentry': '',
    'loginfrom': '',
    'client_id': '',
    'code': '',
    'qq': '',
    'mainpageflag': '1',
    'hff': '',
    'hfp': ''
}

data = urllib.parse.urlencode(data).encode('utf-8')
headers = {
    'Host': 'passport.weibo.cn',
    'Connection': 'keep-alive',
    'Origin': 'https://passport.weibo.cn',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': '*/*',
    'Referer': 'https://passport.weibo.cn/signin/login?entry=mweibo&r=http%3A%2F%2Fweibo.cn%2F&backTitle=%CE%A2%B2%A9&vt=',
    'Accept-Language': 'zh-CN,zh;q=0.8',
}

request = urllib.request.Request(url='https://passport.weibo.cn/sso/login', headers=headers, data=data)
response = opener.open(request)
print(response.read().decode('utf-8'))

headers = {
'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
}

# 访问个人详细信息
request = urllib.request.Request(url='https://weibo.cn/2952685222/info', headers=headers)
# 使用opener访问
response = opener.open(request)
print(response.read().decode('utf-8'))

