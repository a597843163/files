
# 1, 使用input分别输入自己的姓名name, 年龄age, 身高height, 体重weight,
# 然后再使用print输出
#    (输出格式:姓名:1 年龄:1 身高:1 体重:1)
'''
name = input("请输入姓名：")
age = int(input("请输入年龄："))
height = input("请输入身高:")
weight = input("请输入体重:")

print("姓名:%s 年龄:%d 身高:%s 体重:%s" % (name, age, height, weight))
'''
# print("姓名:", name, "年龄:", age, "身高:",height, "体重:",weight)

