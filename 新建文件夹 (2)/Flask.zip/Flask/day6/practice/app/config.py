

# 设置环境配置的基类
class Config:
    # 配置秘钥
    SECRET_KEY = 'asdfsadfw'
    # 设置本地的bootstrap
    BOOTSTRAP_SERVE_LOCAL = True
    # 设置sql回滚
    SQLALCHEMY_COMMIT_ON_TEARDOWN = True
    # 追踪取消
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # 数据库配置
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@127.0.0.1:3306/flask'
    DEBUG = True


