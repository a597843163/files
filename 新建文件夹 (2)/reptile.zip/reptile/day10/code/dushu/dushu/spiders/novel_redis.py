# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from dushu.items import NovelItem
from scrapy_redis.spiders import RedisCrawlSpider


class NovelSpider(RedisCrawlSpider):
    name = 'novel_redis'
    # allowed_domains = ['www.dushu.com']
    # start_urls = ['https://www.dushu.com/book/1078.html']
    redis_key = 'novel_redis:start_urls'

    rules = (
        Rule(LinkExtractor(allow=r'/book/107[78]_\d+\.html'), callback='parse_item', follow=True),

    )

    def parse_item(self, response):

        li_list = response.xpath('//div[@class="bookslist"]/ul/li')
        for li in li_list:
            item = NovelItem()
            name = li.xpath('.//h3/a/text()').extract_first()
            author = li.xpath('.//p[1]/a/text()').extract_first(default="暂缺作者")
            brief = li.xpath('.//p[last()-1]/text()').extract_first()
            item['name'] = name
            item['author'] = author
            item['brief'] = brief
            yield item



