# import pymongo


# 本地的host : 127.0.0.1 或 localhost
# mongodb开启的端口 : 27017

# 1.从pymongo 里面 找到 MongoClient
from pymongo import MongoClient

# 2.创建对象，连接mongodb成功, 终端上面的 mongo 命令就是创建连接的意思
conn = MongoClient(host='localhost', port=27017)
# 3.选择数据库,如下两种方式均可, 终端上面的 use lanyue 就是获取数据库的意思
db = conn.lanyue

# 4.查询出来的是一个列表,我们需要遍历列表中的数据,才能打印出来
ret = db.tanwannanyue.find({'level':{'$gt':100}})
for x in ret:
 	print(x)
# 5.关闭mongodb
conn.close()


# 查看当前数据库中所有的集合
# print(db.collection_names())

# 添加一个数据
# print(collection.insert({'name': '冯小刚', 'age': 48, 'sex': '男'}))
# ret = collection.insert_many([{'name': '冯玉祥', 'age': 68, 'sex': '男'}, {'name': '冯巩', 'age': 59, 'sex': '男'}])
# print(ret.inserted_ids)

# ret = collection.find({'sex': '女'})
# print(list(ret))
# for x in ret:
# 	print(x)

# ret = collection.find({'name':{'$regex':'迪'}})
# import re
# ret = collection.find({'name':re.compile(r'^郭')})
# ret = collection.find({'name':re.compile(r'^郭')}).sort('age', -1)
# for x in ret:
# 	print(x)

# ret = collection.update_many({'name': '冯巩'}, {'$set': {'age': 30}})
# print(ret.matched_count, ret.modified_count)

# ret = collection.delete_many({'name': '冯巩'})
# print(ret.deleted_count)


