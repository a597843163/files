import urllib.request
import urllib.parse
import time
import random
import hashlib
import ssl


ssl._create_default_https_context = ssl._create_unverified_context

url = 'http://fanyi.youdao.com/translate_o?smartresult=dict&smartresult=rule'
word = input('请输入您要查询的英文单词：')
salt = str(int(time.time() * 1000) + random.randint(0, 10))

# 签名o = n.md5("fanyideskweb" + t + i + "ebSeFb%=XZ%T[KZ)c(sy!");
sign_str = "fanyideskweb" + word + salt + "ebSeFb%=XZ%T[KZ)c(sy!"
sign = hashlib.md5(sign_str.encode('utf-8')).hexdigest()
# print(sign)

data = {
    'i': word,
    'from': 'AUTO',
    'to': 'AUTO',
    'smartresult': 'dict',
    'client': 'fanyideskweb',
    'salt': salt,
    'sign': sign,
    'doctype': 'json',
    'version': '2.1',
    'keyfrom': 'fanyi.web',
    'action': 'FY_BY_REALTIME',
    'typoResult': 'false'
}
# 编码
data = urllib.parse.urlencode(data).encode('utf-8')

# 头信息
headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'zh-CN,zh;q=0.8,en;q=0.6',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Cookie': 'OUTFOX_SEARCH_USER_ID=996671690@10.169.0.83; OUTFOX_SEARCH_USER_ID_NCOO=1243528552.6709015; fanyi-ad-id=44881; fanyi-ad-closed=1; JSESSIONID=aaaRWuFeMen-d-ZoFu_ow; ___rl__test__cookies=1527907381289',
    'Host': 'fanyi.youdao.com',
    'Origin': 'http://fanyi.youdao.com',
    'Proxy-Connection': 'keep-alive',
    'Referer': 'http://fanyi.youdao.com/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',

}

# 生成request对象
request = urllib.request.Request(url=url, headers=headers, data=data)

response = urllib.request.urlopen(request)

print(response.read().decode('utf-8'))
