


'''
    成员运算符：
        in  : 判断某个变量是否在序列中，如果在则返回True
        not in ：判断某个变量是否不在序列中， 如果不在则返回True
    格式： 变量 in 序列
'''

names = ["马蓉", "高圆圆", "江疏影", "林志玲", "杨颖"]
girlFriendName = "林志玲"
if girlFriendName in names:
    print(girlFriendName, "是我女朋友")
else:
    print(girlFriendName, "不是我的女朋友")

girlFriendName = "李小璐"
if girlFriendName not in names:
    print(girlFriendName, "不是我女朋友")
else:
    print(girlFriendName, "是我的女朋友")


'''
    身份运算符:
        身份：内存地址
        is :  判断两个变量的内存地址是否一致
        not is  ：判断两个变量的内存地址是否不一致
    格式： 变量1 is 变量2
'''

# ==  : 判断值是否相等
'''
num1 = 10
num2 = 10
print(num1 == num2)  # True

list1 = [1, 2, 3]
list2 = [1, 2, 3]
print(list1 == list2)   # True
'''

# is
num1 = 10
num2 = num1
print(num1 is num2)  # True

list1 = [1, 2, 3]
list2 = [1, 2, 3]
list3 = list2
print(list1 is list2)  # False

# id() : 获取内存地址
print(id(num1))  # 1551148416
print(id(num2))  # 1551148416
print(id(list1))  # 31467144
print(id(list2))  # 35831304
print(id(list3))  # 35831304


# 值类型： 不可变类型， 如：数值，boolean,字符串，元组
# 引用类型： 可变类型， 如： 列表list, 字典dict

# 值类型 ： 简单的赋值，没有关联
n1 = 10
n2 = n1
n1 = 20
print(n1, n2)  # 20 10

# 引用类型: 赋值，且有关联
l1 = [1, 2, 3]
l2 = l1
l1[0] = 4444
print(l1)  # [4444, 2, 3]
print(l2)  # [4444, 2, 3]


'''
ctrl+A : 全选
ctrl+S : 保存
ctrl+F : 查找
ctrl+Z : 撤销
ctrl+shift+z : 重做
ctrl+X : 剪切
ctrl+C : 复制
ctrl+V : 粘贴
ctrl+R : 替换
'''




