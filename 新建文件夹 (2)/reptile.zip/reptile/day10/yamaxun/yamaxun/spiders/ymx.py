# -*- coding: utf-8 -*-
import scrapy
from yamaxun.items import YamaxunItem

class YmxSpider(scrapy.Spider):
    name = 'ymx'
    allowed_domains = ['www.amazon.cn/s/ref=nb_sb_noss_2']
    start_urls = ['https://www.amazon.cn/s/ref=sr_pg_2?rh=i%3Aaps%2Ck%3A%E7%94%B7%E8%A3%85&keywords=%E7%94%B7%E8%A3%85&ie=UTF8&qid=1528379474&page=1']

    def parse(self, response):
        # 拿到所有的li元素,li标签拿的不完全
        li_list = response.xpath('//ul[@id="s-results-list-atf"]/li[contains(@id,"result_")]')
        for li in li_list:
            img_url = li.xpath('.//img/@src').extract_first()
            name = li.xpath('.//h2/text()').extract_first()
            price = li.xpath('.//span[@class="a-size-base a-color-price s-price a-text-bold"]/text()').extract_first()
            item = YamaxunItem()
            item['img_url'] = img_url
            item['name'] = name
            item['price'] = price
            yield item

        # 设定爬50页的数据
        for page in range(2,51):
            url = "https://www.amazon.cn/s/ref=sr_pg_{}?rh=i%3Aaps%2Ck%3A%E7%94%B7%E8%A3%85&keywords=%E7%94%B7%E8%A3%85&ie=UTF8&qid=1528379474&page={}".format(page,page)

            yield scrapy.Request(url,callback=self.parse,headers=headers)
            # yield scrapy.Request(url, callback=self.parse)