from multiprocessing import Queue, Process
from time import sleep


# write函数
def wirte(q):
    print('开始写入')
    for value in 'ABCDEF':
        # 把value写入q里面。
        print('写入%s' % (value,))
        q.put(value, block=False)
        sleep(2)
    print('写入结束')


# read函数
def read(q):
    print('开始读')
    while True:
        value = q.get(timeout=5)
        print('读出%s' % (value,))
    print('结束读')


if __name__ == '__main__':
    print('主进程开始')
    # 创建Q对象
    q = Queue(3)
    # 创建进程
    # p1 = Process(target=wirte, args=(q,))
    p2 = Process(target=read, args=(q,))
    # p1.start()
    p2.start()

    print('主进程结束')
