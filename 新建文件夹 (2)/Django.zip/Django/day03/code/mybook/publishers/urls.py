from django.conf.urls import url
from .views import publisher,index

urlpatterns = [
    url('^publisher/$',index,name='index'),
    url('^publisher/(\d+)/$',publisher,name='publisher')
]