import os
import random
import string

from PIL import Image
from flask import Blueprint, render_template, flash, get_flashed_messages, url_for, redirect, current_app, request
from app.forms import Register, Login, ChangePassword, Changeemail,UploadForm  # 导入表单注册wtf
from app.models import User  # 导入用户模型
from app.extensions import db,file
from app.email import send_mail
# flask中已经封装session的部分函数，
from flask_login import login_user, logout_user, login_required, current_user

# 注册
user = Blueprint('user', __name__)


@user.route('/register/', methods=['GET', 'POST'])
def register():
    form = Register()
    if form.validate_on_submit():
        """
        1.导入用户的model 实例化
        2.保存数据到表 #在user模型中 写一个装饰器 直接将密码机密成hash写入到表中
        3.发送激活账户的邮件
        4.使用flash 提醒激活成功
        5.写一个路由 处理激活的操作
        6.跳转到登陆页
        """
        u = User(username=form.username.data, password=form.password.data, email=form.email.data)
        db.session.add(u)
        # 只有当前视图执行完毕才会去提交添加到下面的邮件的token验证 需要用户当前的id  所以要立即添加成功 并发挥获取到当前用户的id
        db.session.commit()
        token = u.generate_activate_token()  # 生成激活邮件的token
        print(token)
        send_mail('邮件激活', u.email, html='activate', username=u.username, token=token)  # 发送激活邮件
        flash("账户注册成功 请前往邮箱中点击最后一步的操作 激活")
        return render_template('user/login.html')
    return render_template('user/register.html', form=form)


# 激活的链接,当用户点了激活，跳转此views
@user.route('/activate/<token>')
def activate(token):
    # print(token)
    if User.check_token(token):
        flash('账户确认成功')
        return redirect(url_for('user.login'))
    else:
        flash('账户确认失败')
        return redirect(url_for('main.index'))


# 登录
@user.route('/login/', methods=['GET', 'POST'])
def login():
    # pip install flask-login
    # 注册表单实例化
    form = Login()
    if form.validate_on_submit():
        # 判断username是否存在
        u = User.query.filter(User.username == form.username.data).first()
        if not u:
            flash('当前用户不存在')
            # 判断是否激活
        elif u.check_password(form.password.data) and not u.confirm:
            flash('当前用户未激活 请前去激活')
            login_user(u)  # 登录的用户对象传入login_user中
            return render_template('user/activation.html')
            # 检查密码是否存在  check_password 函数从数据库反向解析密码核对
        elif u.check_password(form.password.data):
            flash('欢迎{}登录成功!'.format(u.username))
            login_user(u)  # 登录的用户对象传入login_user中
            return redirect(url_for('main.index'))
    return render_template('user/login.html', form=form)

@user.route('/sendatv/')
def send_atv():
    u = current_user
    token = u.generate_activate_token()  # 生成激活邮件的token
    send_mail('邮件激活', u.email, html='activate', username=u.username, token=token)  # 发送激活邮件
    flash('邮件已经发送成功...请前往邮箱进行激活')
    return redirect(url_for('user.login'))

# 退出
@user.route('/logout/')
def logout():
    logout_user()
    flash('退出成功')
    return redirect(url_for('main.index'))

@user.route('/required/')
@login_required  # 加这个装饰器，必须登录以后才能访问
def required():
    return '我是必须登录以后才能访问的路由'


# 个人信息显示页面
@user.route('/myinfo/')
@login_required  # 加这个装饰器，必须登录以后才能访问
def myinfo():
    return render_template('user/myinfo.html')


# 修改密码默认页面
@user.route('/modifypassword/')
@login_required  # 加这个装饰器，必须登录以后才能访问
def modifypassword():
    return render_template('user/modifypassword.html')


# 发送邮件
@user.route('/modifypassword1/')
@login_required  # 加这个装饰器，必须登录以后才能访问
def modifypassword1():
    u = current_user
    token = u.generate_activate_token()  # 生成确认身份的邮件的token
    send_mail('修改密码', u.email, html='modifpassword', username=u.username, token=token)  # 发送激活邮件
    flash("发送修改密码邮件成功 请前往邮箱中确认身份")
    return render_template('user/modifypassword.html')


# 激活的链接,当用户点了激活，跳转此views
@user.route('/modifpassword2/<token>')
def modifpassword2(token):
    if User.check_token(token):
        flash('账户确认成功')
        return redirect(url_for('user.modifypassword3'))
    else:
        flash('账户确认失败')
        return redirect(url_for('main.index'))


# 用户修改密码的页面
@user.route('/modifypassword3/', methods=['GET', 'POST'])
@login_required  # 加这个装饰器，必须登录以后才能访问
def modifypassword3():
    form = ChangePassword()
    # 点击修改密码后
    if form.validate_on_submit():
        # 判断旧密码是否正确
        if current_user.check_password(form.oldpassword.data):
            # 把旧密码替换成新密码
            current_user.password = form.newpassword.data
            # 保存
            db.session.add(current_user)
            db.session.commit()
            flash("修改密码成功！！！")
    return render_template('user/modifypassword3.html', form=form)


# 修改邮箱
# 修改邮箱默认页面
@user.route('/modifyemail/', methods=['GET', 'POST'])
@login_required  # 加这个装饰器，必须登录以后才能访问
def modifyemail():
    form = Changeemail()
    if form.validate_on_submit():
        # 判断旧密码是否正确,且数据库中邮箱不存在
        e = User.query.filter(User.email == form.new_email.data).first()
        if current_user.check_password(form.password.data) and not e:
            u = current_user
            token = u.generate_activate_token()  # 生成激活邮件的token
            # 发送激活邮件
            send_mail('邮件激活', form.new_email.data, html='modifyemail', username=u.username, token=token,email=form.new_email.data)
            flash("修改邮箱，请前往邮箱中点击最后一步的操作，激活新邮箱")
    return render_template('user/modifyemail.html', form=form)

# 用户点击确认新邮箱后
@user.route('/modifyemail1/<token>/<email>/')
def modifyemail1(token, email):
    if User.check_token(token):
        current_user.email = email
        # 保存
        db.session.add(current_user)
        db.session.commit()
        flash("修改邮箱成功！！！")
        return redirect(url_for('user.myinfo'))
    else:
        flash('修改邮箱失败')
        return redirect(url_for('main.index'))

# 生成随机的图片名称
def random_picname(shuffix):
    Str = string.ascii_letters + '0123456789'
    newName = "".join(random.choices(Str,k=32))+shuffix
    return newName

@user.route('/change_icon/',methods=['GET','POST'])
def change_icon():
    '''
    1.上传的表单
    2.渲染模板
    3.拿到后缀
    4.导入生成随机图片名称的函数
    5.生成缩略图
    6.如果该文件已经上传成功，判断之前的头像是其他图片还是default图片,如果是其他图片，则将其删除
    7.将上传后的图片在模板中显示
    :return:
    '''
    form = UploadForm()
    if form.validate_on_submit():
        # 拿到后缀
        shuffix = (os.path.splitext(form.icon.data.filename)[-1]).lower()
        # 生成随机的图片名称
        newName = random_picname(shuffix)
        file.save(form.icon.data,name=newName)
        # 生成缩略图
        filePath = os.path.join(current_app.config['UPLOADED_PHOTOS_DEST'],newName)
        img = Image.open(filePath)
        img.thumbnail((300,300))
        img.save(filePath)
        # 判断之前的图片是否为default.jpg 不是的话删除
        if current_user.icon != 'default.jpg':
            os.remove(os.path.join(current_app.config['UPLOADED_PHOTOS_DEST'],current_user.icon))
        current_user.icon = newName
        db.session.add(current_user)
        flash('头像修改成功')
    # 拿到图片的路由
    img_url = file.url(current_user.icon)
    return render_template('user/change_icon.html',img_url=img_url,form=form)



