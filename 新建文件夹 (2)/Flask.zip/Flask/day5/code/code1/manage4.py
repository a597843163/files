from flask import Flask
from flask_script import Manager
from flask_sqlalchemy import SQLAlchemy #导入ORM

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:123456@127.0.0.1:3306/flask'
#检测数据是否发生改变 数据追踪 额外消耗资源 设置False 关闭追踪
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
#实例化ORM模型
db = SQLAlchemy(app)
manager = Manager(app)

#创建一个学生的表
class Students(db.Model):
    #不起名 默认为类名
    __tablename__ = 'stu'
    id = db.Column(db.Integer,primary_key=True)
    name = db.Column(db.String(10),index=True)
    sex = db.Column(db.Boolean,default=True)
    age = db.Column(db.Integer)

@app.route('/')
def index():
    return 'sqlalchemy'

@app.route('/create_table/')
def create_table():
    # db.drop_all()
    # db.create_all()
    return '创建表'

if __name__ == '__main__':
    manager.run()