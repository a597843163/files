


# startswith(): 判断是否以指定字符串开头
str1 = "hello world"
print(str1.startswith("hello"))

# endswith() : 判断是否以指定字符串结尾
print(str1.endswith("rld"))


# count(): 统计指定字符串出现的次数
str2 = "hello helloworld"
print(str2.count("l"))  # 5

str3 = "ababacccababa"
print(str3.count("aba"))  # 2


# ord() : 将字符转换成 ASCII码
str4 = "a"
print(ord(str4))  # 97

# chr() : 将ASCII码转换成字符
print(chr(98))  # b



# eval() : 执行一个字符串表达式，返回一个表达式的值
print(eval("12+23"))

# 可以将字符串形式的字典，列表转换成字典或列表
# json字符串
str1 = '{"name":"张三", "age":20}'

dict2 = eval(str1)

print(dict2["name"])  # 张三


# 字符串转换成列表
print(list("Iamboy"))  # ['I', 'a', 'm', 'b', 'o', 'y']

