

# control + / : 可以单行注释一行或多行
# input()
# input()

# 在控制台输入; input会让程序暂停
# 将输入的内容交给左边的变量name， 那么name就是你所输入的内容，
# 这里的等号=表示赋值
name = input("请输入您的大名:")
age = int(input("请输入您的芳龄:"))  # int():把字符串的数字转换成整数
# print(name)


# %s, %d, %f :占位符
# %s ：字符串的占位符
# %d : 整数的占位符
# %f : 浮点数(小数)的占位符
print("姓名:%s" % name)
print("年龄:%d" % age)
print("身高:%f" % 1.1)  # 1.100000
print("身高:%.2f" % 1.1) # 保留两位小数, 1.10
print("姓名:%s, 年龄:%d" % (name, age))


