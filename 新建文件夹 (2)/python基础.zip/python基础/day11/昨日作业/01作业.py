''''''

import os

# 1、封装函数，传入n，得到第n个斐波那契数
# 	    1 1 2 3 5 8 13 21
# ->  f(n) = f(n-1) + f(n-2)
# ->  n=1,n=2 f(n)=1
def fn1(n):
    if n==1 or n==2:
        return 1
    return fn1(n-1) + fn1(n-2)

# print(fn1(8))
# 前n个斐波那契数列
def fn2(n):
    for i in range(1, n+1):
        print(fn1(i), end=" ")
fn2(6)
print()

# 2、使用函数递归，分别统计文件夹newdir中文件和文件夹的个数
# 统计当前目录下的文件数量和文件夹数量
#   如果碰到文件，则文件数量+1
#   如果碰到文件夹，则文件夹数量+1，递归调用fn()并传入当前子文件夹目录，如“C:\wamp\www\day10\今日作业\newdir\dir1”
# count1 = 0  # 文件数量
# count2 = 0  # 目录数量
def fn(dirPath, clist):
    nameList = os.listdir(dirPath)

    for fileName in nameList:
        # 将当前所在目录和当前文件（目录）拼接成一个绝对路径
        absPath = os.path.join(dirPath, fileName)

        if os.path.isfile(absPath):  # 文件
            clist[0] += 1
        elif os.path.isdir(absPath):  # 目录
            clist[1] += 1

            # 递归调用fn, 把当前子目录的路径传入，那么就会自动继续遍历子目录下的所有文件和目录
            fn(absPath, clist)

# count1 = 0
# count2 = 0
countList = [0, 0]
fn(r"C:\wamp\www\day10\今日作业\newdir", countList)
print(countList)



# 值类型
# 引用类型

# 值类型: 不关联
a = 10
b = a  # a=10, b=10
b += 1  # a=10, b=11
print(a, b)  # 10 11


# 引用类型 : 有关联
list1 = [1, 2, 3]
list2 = list1  # list1=[1,2,3], list2=[1,2,3]
list2[1] = 99  # list1=[1,99,3], list2=[1,99,3]
print(list1, list2)  # [1, 99, 3] [1, 99, 3]



