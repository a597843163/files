

# 1,  将下面的字符串str1的敏感字符*用空字符串""替换:
#     然后将str1的空格用空字符串""替换;
#      str1 = "H e  l  ** l    o    Wo r         L d  !"
str1 = "H e  l  ** l    o    Wo r         L d  !"
str1 = str1.replace("*", "")
str1 = str1.replace(" ", "")
print(str1)  # HelloWorLd!


# 2, 去掉字符串123@zh@qq.com中的@;
str2 = "123@zh@qq.com"
str2 = str2.replace("@", "")
print(str2)  # 123zhqq.com


# 3, 任意给定的一串字符，统计字符串里面的大写字母和小写字母的个数
#   如： str1 = "HelloWorLD123"
str1 = "HelloWorLD123"
count1 = 0
count2 = 0
for i in str1:
    if i.isupper():  # 大写
        count1 += 1
    elif i.islower():  # 小写
        count2 += 1

print(count1, count2)  # 4 6


# 4, https://www.baidu.com/s?name=avery&age=20&sex=male
#   封装函数, 传入参数名，获取对应参数的值，
#   如：传入参数"name"返回avery，
#   如：传入参数"age"返回20，
#   如：传入参数"sex"返回male，
def getAttribute(key):
    urlStr = "https://www.baidu.com/s?name=avery&age=20&sex=male"

    # index = urlStr.find("?")
    # str1 = urlStr[index+1:]

    # 按照?拆分
    list1 = urlStr.split("?")
    str1 = list1[1]
    # print(str1)  # "name=avery&age=20&sex=male"

    # 按照&符号拆分
    list2 = str1.split("&")
    # print(list2)  # ['name=avery', 'age=20', 'sex=male']

    # 遍历
    # 方式1：
    # for str2 in list2:
    #     list3 = str2.split("=")
    #     if list3[0] == key:
    #         return list3[1]

    # 方式2：
    # dict1 = {}
    # for str2 in list2:
    #     list3 = str2.split("=")
    #     dict1[list3[0]] = list3[1]
    # # print(dict1)
    # return dict1.get(key)

    # 方式3：
    for str2 in list2:
        index = str2.find("=")
        if str2[:index] == key:
            return str2[index+1:]


print(getAttribute("sex"))



'''
https://www.baidu.com/s?name=avery&age=20&sex=male
http://localhost:80/day09/code/
http://www.12306.cn/mormhweb/
ftp://
svn://
git://
file://
协议： https://
域名：www.baidu.com （IP地址）
端口：80
路径： /day09/code/
? : 分隔 服务器地址 和 参数部分
参数部分: name=avery&age=20&sex=male

'''

# 5,  将字符串按照单词进行逆序，空格作为划分单词的唯一条件
#      如传入:”Welome to Beijing”改为 “Beijing to Welcome”
str1 = "Welome to Beijing"
list1 = str1.split()
list2 = list1[::-1]
str2 = " ".join(list2)
print(str2)

# 6,  实现函数，查找子串出现的次数，返回字符串str中出现子串的次数
#      如传入:”abcabcabc”, “abc”;  返回:3
#          “ababacccababa”, “aba”, 返回：4
def fn(str1,str2):
    n = 0
    n1 = 0
    for i in str1:
        n1 += 1
        if str2 == i+str1[n1:n1+2]:
            n +=1
    return n
print(fn("ababacccababa","aba"))


# 7, 已知千锋邮箱的用户名只能由数字字母下划线组成，域名为@1000phone.com,
#   写一个函数，判断一个字符串是否是千锋邮箱，是返回True，不是返回False。
#     mail@1000phone.com  是
#     $mail@1000phone.com  不是
#     mail@1000phone.comp  不是
def isLegalEmail(email):
    index = email.rfind("@")
    str1 = email[:index]
    for i in str1 :
        if not (i.isupper() or i.islower()or (i =="_") or "0"<= i <= "9"):
            return False
    if email[index:] != "@1000phone.com":
        return False
    return True
print(isLegalEmail("mail@1000phone.com"))

# 8, 将字符中单词用空格隔开
#       已知传入的字符串中只有字母,每个单词的首字母大写，
#       请将每个单词用空格隔开，只保留第一个单词的首字母大写
#       传入:”HelloMyWorld”
#       返回:”Hello my world”
str1 = "HelloMyWorld"
for i in str1[1:]:
        if i.isupper():
            x =   " "+i.lower()
            str1 = str1.replace(i,x)
print(str1)

