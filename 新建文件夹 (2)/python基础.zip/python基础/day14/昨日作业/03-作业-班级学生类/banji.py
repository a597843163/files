

# 	班级类：
# 		属性：班级号，班级口号，学生列表
# 		方法：
# 			显示所有学生
# 			根据学号查找学生
# 			添加一个学生
# 			根据学号删除一个学生
#           根据成绩排序(降序)

class Banji(object):
    def __init__(self, classId, slogan, stuList):
        self.classId = classId
        self.slogan = slogan
        self.stuList = stuList

    # 显示所有学生
    def showStudents(self):
        for stu in self.stuList:
            print(stu)

    # 根据学号查找学生
    def searchByStuno(self, stuno):
        for stu in self.stuList:
            if stuno == stu.stuno:
                return stu
        return "没有找到"

    # 添加一个学生
    def addStudent(self, stu):
        self.stuList.append(stu)

    # 根据学号删除一个学生
    def delStudentByStuno(self, stuno):
        for stu in self.stuList:
            if stu.stuno == stuno:
                self.stuList.remove(stu)

    # 根据成绩排序（降序）
    def sortStudent(self):
        self.stuList.sort(reverse=True, key=lambda x: x.score)

    # lambda x: x.score
    # def fn(x):
    #   return x.socre





