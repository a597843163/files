


import hashlib

#
# md5 的加密算法, 可以将字符串进行加密得到一个32位的密文
#                一个字符串对应一个密文
# md5 是不可逆的
# AES, DES : 可逆
# RSA ：
# base64
#
hash = hashlib.md5()
hash.update('admin'.encode('utf-8'))
tmp = hash.hexdigest()

print(tmp)
# 21232f297a57a5a743894a0e4a801fc3





