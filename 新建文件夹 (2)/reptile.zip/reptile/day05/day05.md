# day05

### 作业一： 爬取有道翻译

注意从js中分析post提交数据中不一样的地方。

```python
import urllib.request
import urllib.parse
import ssl
import time
import random
import hashlib

ssl._create_default_https_context = ssl._create_unverified_context

url = 'http://fanyi.youdao.com/translate_o?smartresult=dict&smartresult=rule'
word = input('请输入您要查询的英文单词：')

# salt值，是毫秒级时间，加上0到10的随机数字。
salt = time.time() * 1000 + random.randint(0, 10)

# sign 是fanyideskweb + word + salt + ebSeFb%=XZ%T[KZ)c(sy!的md5加密值
sign = 'fanyideskweb' + word + str(salt) + 'ebSeFb%=XZ%T[KZ)c(sy!'
sign_hash = hashlib.md5(sign.encode('utf-8')).hexdigest()

data = {
    'i': word,
    'from': 'AUTO',
    'to': 'AUTO',
    'smartresult': 'dict',
    'client': 'fanyideskweb',
    'salt': str(salt),
    'sign': sign_hash,
    'doctype': 'json',
    'version': '2.1',
    'keyfrom': 'fanyi.web',
    'action': 'FY_BY_REALTIME',
    'typoResult': 'false'
}

# 准备头
headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',

    'Accept-Language': 'zh-CN,zh;q=0.8,en;q=0.6',

    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Cookie': 'OUTFOX_SEARCH_USER_ID=996671690@10.169.0.83; OUTFOX_SEARCH_USER_ID_NCOO=1243528552.6709015; fanyi-ad-id=44881; fanyi-ad-closed=1; JSESSIONID=aaafw3lz273Mv-T9QJ7ow; ___rl__test__cookies=1527860863206',
    'Host': 'fanyi.youdao.com',
    'Origin': 'http://fanyi.youdao.com',
    'Proxy-Connection': 'keep-alive',
    'Referer': 'http://fanyi.youdao.com/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
}

data = urllib.parse.urlencode(data).encode('utf-8')
# 创建request对象
request = urllib.request.Request(url=url, headers=headers, data=data)

response = urllib.request.urlopen(request)

print(response.read().decode('utf-8'))
```

### 作业二：使用爬取ip代理网站的ip地址和端口，要求使用正则。

首先先对匹配ip地址的正则表达式很重要，其他就很简单了。

分析ip地址的模式：

```
xxx.xxx.xxx.xxx
0~255.0~255.0~255.0~255
0~9         \d
10~99       [1-9]\d
100~199     1\d{2}
200~249     2[0-4]\d
250~255     25[0-5]
```



### 正则

正则是程序猿（媛）的基本功。必须掌握。

几种常见正则的区别：http://www.cnblogs.com/chengmo/archive/2010/10/10/1847287.html

正则测试网站：http://tool.oschina.net/regex/

![](F:\1802\爬虫\day05\python正则.png)

**正则常用方法**

```python
# 正则的基本模块
import re
# 1. match 匹配
str = 'abc243lljlf,jklo0459'
# 编译正则表达式
pattern = re.compile(r'\w+')
# 从头开始匹配，只返回一个结果。可以指定查找范围。
m = pattern.match(str)
# m 是一个包含匹配结果的对象。没有匹配成功返回None
print(m)
# 如果想取出匹配到的字符串，使用m.group
print(m.group())

# 2. search ,查找，从左往右查找，直到查到一个数据为止。并不会查询所有。
pattern = re.compile(r'\d+')
s = pattern.search(str)
print(s)
# search匹配到之后也是用group取出匹配到的字符串。
print(s.group())


# 3. findall  返回所有匹配的结果，结果是一个list
f = pattern.findall(str)
print(f)

# 4. finditer 返回一个可迭代的对象。
ft =  pattern.finditer(str)
for item in ft:
    print('起始%s, 结束%s, 范围%s, 数据%s' % (item.start(), item.end(), item.span(), item.group()))


# 5.split分割字符串，返回列表
str = 'aa,, hi   : : 74 , world'
# 以正则中的字符来分割字符串。
p = re.compile(r'[\,\s\:]+')
sub_list = p.split(str)
print(sub_list)


# 6. sub替换
str = '123 Hello, 456 World'
p = re.compile(r'(\w+) (\w+)')
# 执行替换 \1 代表str中匹配到的第一个（\w+） \2表示匹配到的第二个（\w+）
print(p.sub(r'\2\1', str))
print(p.sub(r'\2 zhangsan', str))
# sub高级用法， sub第一个参数可以是一个函数。
# item表示匹配结果对象item.group(1)和上面的\1是一个样的
def fun(item):
    return 'cool' + item.group(2)
print(p.sub(fun, str))

#  7. 匹配汉字
# 汉字在unicode编码中有一个特定的区域，开始为\u4e00,结束为\u9fa5如果一个字符串的unicode编码在这个区间内，说明就是汉字。
str = '你好...xxxefjeio930345!@#O$我好。。。execue me 大家好fe'
p = re.compile(u'[\u4e00-\u9fa5]+')
print(p.findall(str))

# 8. 贪婪模式和非贪婪模式
str = 'aa<div>test1</div>bb<div>test2</div>cc'
# 非贪婪模式，匹配到一个就不匹配了。
p = re.compile(r'<div>(.*?)</div>')

m = p.search(str)
print(m, m.group())
m = p.findall(str)
print(m)
# 问好去掉就变成贪婪模式，尽量多的匹配。
p = re.compile(r'<div>(.*)</div>')

m = p.search(str)
print(m, m.group())
m = p.findall(str)
print(m)

```

### 使用正则提取糗百中的图片

```python
import urllib.request
import re
import os

def download_image(image_url):
	dirpath = './qiubai'
	# 获取文件名
	filename = os.path.basename(image_url)
	# 拼接文件全路径
	filepath = os.path.join(dirpath, filename)
	# 下载图片
	urllib.request.urlretrieve(image_url, filepath)
	print(filepath + '下载完毕')

def handle_content(request):
	# 拿到页面
	response = urllib.request.urlopen(request)
	html = response.read().decode('utf-8')
	# 处理html，通过正则表达式拿到所有的图片链接，并且将图片下载到本地,加上re.S表示.可以匹配换行。
    # 注意：在正则里面 “（）” 代表的是分组的意思，一个括号代表一个分组，你只能匹配到"()"中的内容
	pattern = re.compile(r'<div class="thumb">.*?<img src=(.*?) alt=.*?>.*?</div>', re.S)
	# 获取所有的图片的链接
	src_list = pattern.findall(html)
	# 遍历这个列表
	for src in src_list:
		# 取出两边的双引号
		src = src.strip('"')
		# 拼接完整的图片url
		image_url = 'https:' + src
		# 下载这个图片即可
		download_image(image_url)


# 构建请求对象并且返回
def handle_url(url, page):
	url = url + str(page)
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36'
	}
	request = urllib.request.Request(url=url, headers=headers)
	return request

def main():
	url = 'https://www.qiushibaike.com/pic/page/'
	start_page = int(input('请输入抓取的起始页码:'))
	end_page = int(input('请输入抓取的结束页码:'))
	print('开始下载...........')
	for page in range(start_page, end_page + 1):
		# 拼接url，生成一个request
		request = handle_url(url, page)
		# 获取内容，处理内容
		handle_content(request)
	print('全部下载完毕')


if __name__ == '__main__':
	main()
```



### xpath

**XPath 是一门在 XML 文档中查找信息的语言。XPath 可用来在 XML 文档中对元素和属性进行遍历。** 

要想理解xpath是什么要先知道xml是什么。

http://www.w3school.com.cn/xpath/

w3school的xpath教程是非常好的xpath教程。

XPath 使用路径表达式在 XML 文档中进行导航。

什么是xml  http://www.w3school.com.cn/xml/
	什么是xpath
		XPath 使用路径表达式在 XML 文档中进行导航
	
		//  从匹配选择的当前节点选择文档中的节点，而不考虑它们的位置
		.   选取当前节点
		@   选取属性
	打开谷歌浏览器，安装xpath插件，然后使用xpath插件
	按 ctrl + shift + x
	
	属性定位：根据属性查找标签
	层级定位：一级一级查找
	索引定位：【注】下标从1开始
		查找id是maincontent的div下面的h1节点
		//div[@id="maincontent"]/h1
	
		//div[@class="head_wrapper"]/div[@id="u"]/a[1]
	逻辑运算
		//div[@id="head" and @class="s_down"]
	模糊匹配
		查找所有的div，id中有he的div
		//div[contains(@id, "he")]
		查找所有的div，id中以he开头的div
		//div[starts-with(@id, "he")]
		查找所有的div，id中以he结尾的div
		//div[ends-with(@id, "he")]
	取文本
		//div[@class="head_wrapper"]/div[@id="u"]/a[1]/text()
		//div[@class="head_wrapper"]/div[@id="u"]/a[1]
		obj.text   将内容获取到
	取属性
		//div[@class="head_wrapper"]/div[@id="u"]/a[1]/@href
安装模块  lxml库
	这个库是解析html的库，主要就是解析和提取数据
	pip install lxml  -i https://pypi.douban.com/simple 安装好
	【注】pip安装包的时候，要记得将fiddler关闭
代码中使用
	from lxml import etree
	html_etree = etree.parse('可以获取本地html文件')     
	html_etree = etree.HTML('网上获取的html字符串(也可以是字节类型)')
	html_etree.xpath('xpath路径')
	返回的是一个列表

​	获取到节点对象之后obj
		obj.xpath('xpath路径')

```python
from lxml import etree #Element tree

str = '''<div>
    <ul>
         <li class="item-0"><a href="link1.html">first item</a></li>
         <li class="item-1"><a href="link2.html" class="bold">second items</a></li>
         <li class="item-inactive"><a href="link3.html">third item</a></li>
         <li class="item-1"><a href="link4.html"><span class="bold">fourth items</span></a></li>
         <li class="item-0"><a href="link5.html">fifth item</a>
     </ul>
 </div>
'''

# print(str)
# str.xpath('//*')
html = etree.HTML(str)
# print(html)
# print(etree.tostring(html).decode('utf-8'))

# # parse ：解析
# html = etree.parse('./test.html')
# print(etree.tostring(html).decode('utf-8'))

# 1、获取所有的li标签
# li_list = html.xpath('//li')
li_list = html.xpath('/html/body/div/ul/li')
# print(li_list)


# 2、获取li标签下的class属性
c_list = html.xpath('//*/@*')
# print(c_list)

#3、获取li标签下所有的span标签,
# 标签中内容：element.text
s_list = html.xpath('//li//span')
# print(s_list[0].text)

# print(html.xpath('//li//span/text()'))

# 4、获取倒数第二个li标签
r = html.xpath('//li[last()-1]')
# print(r)
# print(etree.tostring(r[0]).decode('utf-8'))
# result = r[0].xpath('./a')
# print(result)

# // 和 /  两个表示查询全部，不分层级；一个表示查询子层级，直属的标签
span = r[0].xpath('.//span')
# print(span)

# 5 、查询li 并且class值等于item-0
r = html.xpath('//li[@class!="item-0"]')
# print(r)
r = html.xpath('//li[contains(@class,"-inactive")]')
# print(r)

r = html.xpath('//li[not(contains(@class,"-ina"))]')
# print(r)

# 获取class 等于bold 的标签

r = html.xpath('//*[@class="bold"]')
# print(r)

r = html.xpath('//*[contains(text(),"items")]')
print(r)
```

例子：
	1.抓取图片
	http://sc.chinaz.com/tupian/xingganmeinvtupian.html
	http://sc.chinaz.com/tupian/xingganmeinvtupian_2.html
	2.58同城租房，存csv
	3.支付宝接口
	
	

```python
import urllib.request
from lxml import etree
import os
import ssl

ssl._create_default_https_context = ssl._create_unverified_context

def handle_url(url):
	headers = {
		'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537'
	}
	request = urllib.request.Request(url=url, headers=headers)
	return request

def download_image(image_url_list, name_list):
	# 获取文件夹名字
	dirpath = './images'
	# 遍历url列表，和名字列表
	for i in range(len(name_list)):
		# 根据url获取到图片的后缀名
		suffix = os.path.splitext(image_url_list[i])[-1]
		# 得到图片的全路径
		filepath = os.path.join(dirpath, name_list[i]) +suffix
		# 下载图片
		try:
			urllib.request.urlretrieve(image_url_list[i], filepath)
			print('%s 下载完毕' % filepath)
		except Exception as e:
			print('%s xxxxxxxxxxxxx图片丢失' % filepath)

def handle_data(request):
	response = urllib.request.urlopen(request)
	html = response.read().decode('utf-8')
	html_tree = etree.HTML(html)
	# print(type(html_tree))
	# //div[@id="container"]/div/div/a/img/@src
	image_url_list = html_tree.xpath('//div[@id="container"]/div/div/a/img/@src2')
	# print(len(image_url_list))
	# exit()
	name_list = html_tree.xpath('//div[@id="container"]/div/div/a/img/@alt')
	# 遍历image_url_list，依次下载图片
	download_image(image_url_list, name_list)

def main():
	start_page = int(input('请输入起始页面:'))
	end_page = int(input('请输入结束页面:'))
	url_tmp = 'http://sc.chinaz.com/tupian/xingganmeinvtupian'
	print('开始下载图片')
	for page in range(start_page, end_page + 1):
		if page != 1:
			url = url_tmp + '_' + str(page) + '.html'
		else:
			url = url_tmp + '.html'
		request = handle_url(url)
		handle_data(request)
	print('结束下载图片')


if __name__ == '__main__':
	main()
```

