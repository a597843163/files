from django.db import models

# Create your models here.

# 在这里定义模型类
class Grade(models.Model):
    # 字段/属性
    name = models.CharField(max_length=20)
    date = models.DateField()
    girl_num = models.PositiveIntegerField()
    boy_num = models.PositiveIntegerField()
    is_delete = models.BooleanField(default=False)

    def __str__(self):
        return self.name
