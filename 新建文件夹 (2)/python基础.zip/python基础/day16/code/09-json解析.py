

# API接口
# url接口

# get接口
# http://litchiapi.jstv.com/api/GetFeeds?column=0&PageSize=10&pageIndex=1&val=100511D3BE5301280E0992C73A9DEC41


# http的请求方式
# get请求
# post请求
# put,head,delete....

# get请求的特点
#   将参数部分加在url的?后面
#   优点：速度快
#   缺点：不安全，携带的数据量少


from urllib import request


url = "http://litchiapi.jstv.com/api/GetFeeds?column=0&PageSize=10&pageIndex=1&val=100511D3BE5301280E0992C73A9DEC41"
response = request.urlopen(url)
str1 = response.read().decode("utf-8")
print(str1)
print(type(str1))  # <class 'str'>

# eval()
# dict1 = eval(str1)
# print(dict1)
# print(type(dict1))  #<class 'dict'>


import json
# json.loads()
dict2 = json.loads(str1)
print(dict2)
print(type(dict2))  # <class 'dict'>















