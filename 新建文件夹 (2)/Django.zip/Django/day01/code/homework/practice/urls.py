from django.conf.urls import url
from .views import student,teacher

urlpatterns = [
    url(r'^student/',student),
    url(r'^teachers/',teacher),
]