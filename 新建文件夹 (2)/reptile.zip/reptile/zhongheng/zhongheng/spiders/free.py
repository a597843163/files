# -*- coding: utf-8 -*-
import scrapy

from zhongheng.items import ZhonghengItem
# from scrapy.spider import CrawlSpider,Rule
# from scrapy.linkextractor import LinkExtractor
from urllib import request

class FreeSpider(scrapy.Spider):
    name = 'free'
    allowed_domains = ['book.zongheng.com','huayu.baidu.com']
    # start_urls = ['http://book.zongheng.com/quanben/c0/c0/b9/u0/p1/v0/s1/t0/ALL.html']

    def start_requests(self):
        for i in range(1,26):
            url = 'http://book.zongheng.com/quanben/c0/c0/b9/u0/p{}/v0/s1/t0/ALL.html'.format(i)
            yield  scrapy.Request(url=url,callback=self.parse)

    def parse(self, response):
        li_list = response.xpath("//div[@class='con']/ul/li")
        for li in li_list:
            if not li.xpath('@class'):
                item = ZhonghengItem()
                # 名字
                name = li.xpath("./span[@class='chap']/a[@class='fs14']/text()").extract_first()
                # 找到第二个链接link,点进去下载图片
                link = li.xpath(".//span[@class='chap']/a[@class='fs14']/@href").extract_first()
                # 作者
                author = li.xpath("./span[@class='author']/a/text()").extract_first()
                # 类型
                style = li.xpath("./span[@class='kind']/a/@title").extract_first()
                item['name'] = name
                item['author'] = author
                item['style'] = style
                # 这里面涉及到一个传递item的问题，我们要学习如何传参,加上一个meta参数，meta参数是一个字典，过去之后，通过字典的键获取其值
                yield scrapy.Request(url=link, callback=self.info, meta={'item': item})


    def info(self,response):
        item = response.meta['item']
        # 点进去之后的imgurl
        img_url = response.xpath("//div[@class='book_cover fl']/p/a/img/@src").extract_first()
        # 概要
        summary = response.xpath('//div[@class="info_con"]/p/text()').extract_first()
        if not img_url:
            img_url = response.xpath("//div[@class='img']/a/img/@src").extract_first()
            summary = response.xpath("//div[@class='nr']/a/text()").extract_first()
        # print(img_url, summary)
        path = r'F:\pythonStudy\reptile\zhongheng\img\\' + item['name'] + '.jpeg'
        request.urlretrieve(img_url,path)
        item['img_url'] = img_url
        item['summary'] = summary
        yield item

