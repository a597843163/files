from urllib.request import urlretrieve

url = 'http://v3-tt.ixigua.com/c4c4b804e5d66d038e82efdc9b76fd53/5b17b542/video/m/22007d92b9b33b6435aab3197621b3feefd1157b33d0000cd1ec20ed98b/'

urlretrieve(url=url, filename='xigua.mp4')


