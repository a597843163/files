import pip
'''
day01:
    装软件
day02:
    1,数据存储原理
    2，原码反码补码
    3，注释
        单行注释
        多行注释    """注释内容"""
    4， 输入输出
        输入：input("请输入内容")
        输出：print("hello world")

day03:
    1，数据类型
        number，string，list，Boolean，set，Dict，Set，None，Byte
        type（）：判断数据类型
        isinstance（）：判断对象是属于什么类
    2，变量
        声明变量
             age = 20
             a = b = c =10
             a,b = 10,20
             a,b = (20,30)
             a,*b,c = 1,2,3,4




'''









