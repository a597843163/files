

from urllib import request

# 设置超时时间

for i in range(100):
    try:
        response = request.urlopen("http://www.baidu.com", timeout=0.1)
        htmlStr = response.read().decode("utf-8")
        # print(htmlStr)
        print("OK")
    except:
        print("出现异常")









