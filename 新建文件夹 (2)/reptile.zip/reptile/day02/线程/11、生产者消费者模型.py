import threading, time, queue, random


# 生产者
def producer(id, q):
    # 无限循环，不停的生产
    while True:
        value = random.randint(0, 10000)
        # 放入q中
        q.put(value)
        print('生产者%d生产了数据%d' % (id, value))
        time.sleep(1)


# 消费者
def consumer(id, q):
    # 无限循环 ，不停的消费
    while True:
        # 从q中取东西
        try:
            value = q.get(timeout=5)
            print('消费者%d消费了%d' % (id, value))
            time.sleep(2)
        except queue.Empty:
            print('东西都被吃完了')
            break


if __name__ == '__main__':
    # 创建queue实例
    q = queue.Queue()

    # 创建生产者线程
    for i in range(10):
        threading.Thread(target=producer, args=(i, q)).start()

    # 创建消费者线程
    for i in range(10):
        threading.Thread(target=consumer, args=(i, q)).start()