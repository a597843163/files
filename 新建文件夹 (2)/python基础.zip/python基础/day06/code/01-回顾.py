



'''

    循环：while，for
    while 循环条件:
        循环体

    for i in 序列：
        循环体

    break（掌握）,continue


    列表: list
        list1 = []
        list1 = [11, "22", True]

        列表的下标/索引： 从0开始
            list1[0]
            list1[0] = 99

        list1 + list2
        list1 * 3
        print(11 in list1)

        print(list1[2:5])


'''





