


# 作业1 : 分页获取豆瓣的数据 json数据
# url = "https://movie.douban.com/j/chart/top_list?type=11&interval_id=100%3A90&action=&start="+ str(i * 20)+"&limit=20"

from  urllib import request
import json
import os

def getData(url):

    response = request.urlopen(url)
    jsonStr = response.read().decode("utf-8")
    # print(jsonStr)
    # print(type(jsonStr))  # <class 'str'>

    # json解析: json字符串 --> json对象
    list1 = json.loads(jsonStr)

    for movieDict in list1:
        # print(movieDict["title"])

        # 把电影图片存入本地，且图片名取电影名
        cover_url = movieDict["cover_url"]  # 电影图片路径
        title = movieDict["title"]  # 电影名称
        path = r"C:\wamp\www\day17\昨日作业\images"
        absPath = os.path.join(path, title + ".png")
        request.urlretrieve(cover_url, absPath)


if __name__ == "__main__":

    for i in range(1, 2):
        url = "https://movie.douban.com/j/chart/top_list?type=11&interval_id=100%3A90&action=&start=" + str(
        i * 20) + "&limit=20"

        getData(url)











