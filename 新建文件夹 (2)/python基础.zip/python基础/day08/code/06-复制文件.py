


'''
    复制文件/拷贝文件：
        1, 读取原文件的内容
        2, 把读取的内容写入新文件
'''

# 先输入要复制的文件名
fileName = input("请输入您要复制的文件名称：")
# 情书.txt -> 情书-副本.txt
index = fileName.rfind(".")
# print(index)
# rfind() 从字符串的右边往左边查找第一次出现指定字符的位置（下标）
newFileName = fileName[:index] + "-副本1" + fileName[index:]
#                   "情书"     +  "-副本" +    ".txt"
# print(newFileName) # 情书-副本.txt


fp1 = open(fileName, "rb")  # 以读二进制的方式打开原来的文件
fp2 = open(newFileName, "ab")  # 以写二进制的方式打开新文件

# 一次性读取和写入
# content = fp1.read()
# fp2.write(content)


# 复制大文件
# 分多次读取和写入
while True:
    # 一次获取1024byte, 1KB
    content = fp1.read(1024)
    if len(content) == 0:  # 写完了
        break
    fp2.write(content)  # 写入

fp1.close()
fp2.close()





