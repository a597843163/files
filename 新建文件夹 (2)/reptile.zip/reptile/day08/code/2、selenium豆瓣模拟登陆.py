import time

from selenium import webdriver
from PIL import Image
from urllib.request import urlretrieve

driver = webdriver.Chrome()

driver.get('https://accounts.douban.com/login')
driver.implicitly_wait(10)

driver.find_element_by_id('email').send_keys('6239264208@qq.com')
driver.find_element_by_id('password').send_keys('jiangwei112')

# 获取标签里的属性
img_url = driver.find_element_by_id('captcha_image').get_attribute('src')
urlretrieve(img_url,'captcha.jpg')

# image = Image.open('captcha.jpg')
# image.show()

code = input('请输入验证码:')
driver.find_element_by_id('captcha_field').send_keys(code)
# time.sleep(5)
# 以标签name属性来查找
driver.find_element_by_name('login').click()

driver.save_screenshot('douban.png')
time.sleep(10)
driver.quit()


