# -*- coding: utf-8 -*-
import scrapy
import json

class BaiduSpider(scrapy.Spider):
    name = 'baidu'
    allowed_domains = ['www.baidu.com']
    start_urls = ['http://www.baidu.com']

    def start_requests(self):
        post_url = 'http://fanyi.baidu.com/sug'
        formdata = {
            'kw':'hello'
        }
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36'
        }
        yield scrapy.FormRequest(url=post_url, formdata=formdata, headers=headers)

    def parse(self, response):
        with open('./baidu.txt', 'w', encoding='utf-8') as fp:
            fp.write(json.dumps(json.loads(response.text), ensure_ascii=False))
        # print(response.text)
