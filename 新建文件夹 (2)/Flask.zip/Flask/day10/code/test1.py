


list1 = [66,33,44,11,22,88]

for i in range(len(list1)):
    for j in range(len(list1)-1-i):
        if list1[j]>list1[j+1]:
            list1[j],list1[j+1]=list1[j+1],list1[j]
            print(list1)
