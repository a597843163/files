import redis

# 本地的host: localhost
# 本地的端口: 6379

# 1. 连接redis数据库
r = redis.StrictRedis(host='localhost', port=6379)

#r.lrange('maibake 0 0')
r.lpush('maibake', '林更新','王思聪')
value = r.lrange('maibake',0,-1)


# print(value.decode())


# value = r.rpop('python')

print(value)
