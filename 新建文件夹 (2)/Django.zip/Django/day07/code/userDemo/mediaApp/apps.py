from django.apps import AppConfig


class MediaappConfig(AppConfig):
    name = 'mediaApp'
