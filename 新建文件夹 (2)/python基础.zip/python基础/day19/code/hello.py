


age = 10
_age = 20
__age = 30


