from flask import Flask, render_template, current_app
from flask_mail import Mail,Message
from threading import Thread #导入线程模块
from app.extensions import mail

#线程执行干的活
def async_send_mail(app,msg):
    #程序上下文
    with app.app_context():
        mail.send(message=msg)

def send_mail(subject,to,html,**kwargs):
    #  #拿到真正实例化的app  并非是app的代理对象
    app = current_app._get_current_object()
    msg = Message(subject=subject,recipients=[to],sender=app.config['MAIL_USERNAME'])
    # 邮件内容
    msg.html = render_template('email/'+html+'.html',**kwargs)
    # 第一个参数为 让当前线程干活的函数  第二个为传参 需要元组形式
    send = Thread(target=async_send_mail,args=(app,msg))
    send.start() #开启线程

