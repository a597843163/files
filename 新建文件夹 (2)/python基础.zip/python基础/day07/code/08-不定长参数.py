


'''

    不定长参数： 可变参数

'''

def fn(*args):
    print(args)  # (1, 2, 3, 4, 5, 6)

fn(1, 2, 3, 4, 5, 6)

# 如果传入的是列表或元组，那么就要在list1前面加上*号
list1 = ["a", "b", "c"]
fn(*list1)  # ('a', 'b', 'c')

def fn1(name, *args):
    print(name)  # 1
    print(args)  # (2, 3, 4, 5, 6)

fn1(1, 2, 3, 4, 5, 6)


def fn2(name, *args, age):
    print(name)  # 1
    print(args)  # (2, 3, 4, 5, 6)
    print(age)  # 99

# 需要使用关键字参数给age赋值
fn2(1, 2, 3, 4, 5, 6, age=99)



# 计算传入任意个数的和
def sum(*args):
    # args= (1,2,3,4)
    s = 0
    for i in args:
        s += i
    return s

res = sum(1,2,3,4)
print(res)  # 10



# ** : 可以传入多个key-value形式的参数
def fn3(**kwargs):
    print(kwargs)  # {'name': '宝强', 'age': 33}

# fn3()  # {}
fn3(name="宝强", age=33)


def fn4(*args, **kwargs):
    print(args)   # (1, 2, 3)
    print(kwargs)  # {'name': '陈思诚', 'age': 37}

fn4(1, 2, 3, name="陈思诚",age=37)






