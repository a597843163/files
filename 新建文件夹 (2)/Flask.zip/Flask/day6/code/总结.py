str1 = '''
config为配置文件,对一些数据库，蓝本，bootstrap之类进行配置
extensions 为专门创建的实例化的文件，
__init__  为外部使用时所有配置,实例,蓝本进行初始化
'''

str2 = '''
 数据库配置
 1.配置数据库连接
 2.事务模式自动提交
 3.追踪关闭，否则耗费资源
 4.数据库实例化
 需要注意的是
    # sqlite的配置语句,base_dir一般默认为当前此文件夹的路径
    SQLALCHEMY_DATABASE_URI = 'sqlite:///'+os.path.join(base_dir,'blog-deve.sqlite')
    # 下面的为mysql的配置语句
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@127.0.0.1:3306/flask'
'''

str3 = '''
    其他必备配置
1.秘钥，给session和crsf提供加密
2.bootstrap设置为本地
3.debug 开启true 和false 两种模式 
4.testing 开启true 和false 两种测试环境

'''

str4 = '''
在配置完全以后，可进行实例化操作
外部导入配置：
app.config.from_object(路径)
如果实例化之前未添加app,可用obj.init_app(app)进行添加app
迁移实例化一般和database同时存在，且在db之后再实例化,因为migrate要传db的参数
'''