# 在初始化包文件中 导入各个模块的蓝本
from .posts import posts
from .user import user
from .main import main

# 定义蓝本的配置列表
default_blueprint = [
    (posts,'/posts'),
    (user,'/user'),
    (main,'/main')
]
# 统一注册蓝本的方法，循环注册
def config_blueprint(app):
    for blueprint,url_prefix in default_blueprint:
        app.register_blueprint(blueprint,url_prefix=url_prefix)


