import urllib.request
import ssl
ssl._create_default_https_context = ssl._create_unverified_context

# 创建handler对象
handler = urllib.request.HTTPHandler()

# 使用handler创建opener
opener = urllib.request.build_opener(handler)

# 创建request对象
request = urllib.request.Request(url='http://www.baidu.com/')
# 使用opener打开request
response = opener.open(request)
print(response.read().decode('utf-8'))