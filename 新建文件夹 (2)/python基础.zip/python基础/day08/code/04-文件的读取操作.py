


# 文件的读取
#   read() : 读取所有内容
#   read(5) : 读取5个字符
#   readline() : 读取一行
#   readlines() : 读取所有行


#
fp = open("情书.txt", "r", encoding="utf-8")

# 读取所有内容
# content = fp.read()
# print(type(content))  #  <class 'str'>

# 一次读取12个字符，定位符会往后移动到读取的位置
# content = fp.read(12)
# print(content)

# content = fp.read(12)
# print(content)

# 一行一行读取：默认读取\n，并转行
content = fp.readline()
print(content, end="")
content = fp.readline()
print(content, end="")


# # 读取所有行：不转行
# content = fp.readlines()
# print(type(content))    #  <class 'list'>
# ['kingofglory猥琐发育，别浪\n', '敌人还有5秒到达战场\n', '我拿buff\n', '技能不全，撤退\n', '集合，攻击敌方水晶\n', '稳住，我们能赢']

# for line in content:
#     print(line, end="")

fp.close()


'''
# # 二进制和字符串的转换
# fp = open("情书.txt", "rb")
#
# content = fp.read()
# print(content)
#
# # 把二进制转换成字符串
# str1 = content.decode(encoding="utf-8")
# print(str1)
#
# # 把字符串转换成二进制
# print(str1.encode(encoding="utf-8"))  # 一个中文3个字节
# print(str1.encode(encoding="gbk"))  # 一个中文2个字节
#
# fp.close()
'''


