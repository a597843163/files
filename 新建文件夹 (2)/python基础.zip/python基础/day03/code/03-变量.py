


# 变量： 可以改变的量 variable
# num: 变量名称
#  = ：赋值
# 100：存储在内存中的一个值
# 将数字100 赋值 给变量num
num = 100

# 表示赋值： =
# 表示等于： ==

# 同时声明变量/定义变量
# 赋值运算符=： 会先计算=右边的代码
num1 = num2 = 100
print(num1, num2)

# 同时定义多个变量，赋值不同的值
# a = 10
# b = 20
a, b = 10, 20
print(a, b)

# 交换两个变量的值
c = 30
d = 40

# temp = c
# c = d
# d = temp

c, d = d, c
print(c, d)


# 自加10, 会先运算=右边的num3+10=110，再赋值给左边的num3,num3=110
num3 = 100
num3 = num3 + 10
print(num3)



# 删除变量
# del 变量名称
num4 = 10
del num4  # 删除变量num4
# print(num4)  #报错


# 使用变量时，必须先定义变量
# print(num5)
# num5 = 20

# name 'num5' is not defined : 变量未定义



# python是一种动态数据类型的语言：弱类型
apple = 4  #4是整型，所以apple是整型
print(type(apple))  # <class 'int'>

apple = "8元/kg"  #"8元/kg"是字符串类型，所以又变成了字符串类型
print(type(apple))  # <class 'str'>

# 强类型
# c语言： int apple = 4
#            apple = "8元/kg" 报错
#


# 变量名称：规范
# 标识符命名规范
# 1，变量名称只能为数字，字母和下划线组成
# 2，不能以数字开头
# 3，不能使用关键字
# 4，区分大小写
# 5，见名思意


num12____ = 10
num__123 = 20
__num123 = 30
# 123_num = 40 # 不合法，报错
# num$123 = 1 # 不合法

# and = 10 # 不能使用关键字

# 见名思意
age = 20

# 区分大小写
AGE = 30
Age = 40
print(age, AGE, Age)  # 20 30 40

# 驼峰
# 变量名： 小驼峰  myComputerPrice
# 类名 ： 大驼峰  MyComputerPrice
myComputerPrice = 10000


# 代码的执行顺序： 自上而下

# 写代码的规范：
#     赋值符号=以及其他运算符(+ - * /等) 两边留空格
#     逗号后面一般留空格
#     if/for, 代码要缩进
#
# + - * /

