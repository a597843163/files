


# 迭代器和迭代器对象

from collections import Iterator  # 迭代器
from collections import Iterable  # 迭代器对象

# 迭代器对象
# 列表，元组，字符串，set集合, 字典 都是迭代器对象: 可以使用forin遍历的就是迭代器对象
# isinstance() : 用来判断是否是某个类的对象
print(isinstance([1,2], Iterable))  # True
print(isinstance((1,2), Iterable))   # True
print(isinstance("hello", Iterable))  # True
print(isinstance({1,2,3}, Iterable))  # True
print(isinstance({"name":"宝强"}, Iterable))  # True

# 迭代器
# 列表，元组，字符串，set集合, 字典 都不是迭代器
print(isinstance([1,2], Iterator))  # False
print(isinstance((1,2), Iterator))   # False
print(isinstance("hello", Iterator))  # False
print(isinstance({1,2,3}, Iterator))  # False
print(isinstance({"name":"宝强"}, Iterator))  # False

# 迭代器对象: 可以使用forin遍历的就是迭代器对象
# 迭代器： 可以使用forin遍历，且可以使用next()调用

# 生成器
generator = (i for i in range(1, 10))
print(isinstance(generator, Iterator))  # True
print(isinstance(generator, Iterable))  # True


# iter() : 把迭代器对象转换成迭代器
list1 = [1, 2, 3, 4, 5]
# next(list1)  # 报错, list1不是迭代器，不可以使用next()调用
res = iter(list1)
# print(res)
# print(next(res))  # 1
# print(next(res))  # 2
# print(next(res))  # 3

# 将迭代器转换成迭代器对象
list2 = list(res)
print(list2)  # [1, 2, 3, 4, 5]




















