

# 变量 ：可以改变的量 variable

num = 100



