from flask import Blueprint,render_template

main = Blueprint('main',__name__)

# 定制一个首页
@main.route('/')
def index():
    return render_template('main/index.html')