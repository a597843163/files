
import socket

# TCP客户端

# 1，创建客户端的socket
# 2，主动连接服务端
# 3，发送数据给服务端，接收服务端的数据


# 1，创建客户端的socket
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 2，主动连接服务端
clientSocket.connect(("10.36.137.101", 8888))
# 此时已经完成三次握手了

# 3，发送数据给服务端，接收服务端的数据
while True:

    # 发送数据给服务端
    sendData = input("客户端说：")
    clientSocket.send(sendData.encode("utf-8"))  # 传输二进制

    # 接收服务端发来的数据
    recvData = clientSocket.recv(1024)
    print("服务端说：", recvData.decode("utf-8"))







