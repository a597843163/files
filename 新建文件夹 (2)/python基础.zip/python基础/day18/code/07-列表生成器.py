


# 列表生成器
# list1 = [1,2,3,4,5]
#
# list2 = []
# for i in range(1, 101):
#     list2.append(i)
#
# list(range(1, 101))

list1 = [i for i in range(1, 101)]
# print(list1)

list2 = [i**2 for i in range(1, 101)]
# print(list2)

list3 = ["https://www.qiushibaike.com/text/page/" + str(i) + "/" for i in range(1, 5)]
print(list3)


list4 = [i for i in range(1, 10) if i%2==0]
print(list4)  # [2, 4, 6, 8]

# 1-99 中在20-50之间的偶数
list5 = [i for i in range(1, 100) if i%2==0 if i>=20 and i<=50]
print(list5)


# for嵌套
list6 = [i+j for i in ["a","b","c"] for j in ["x","y","z"]]
print(list6)
# ['ax', 'ay', 'az', 'bx', 'by', 'bz', 'cx', 'cy', 'cz']



