import os
import re

from django.shortcuts import render, redirect,reverse
from django.http import HttpResponse

from AXF import settings
from .models import *


# 首页
def home(request):
    # 轮播数据
    wheels = MainWheel.objects.all()
    # 顶部菜单数据
    navs = MainNav.objects.all()
    # 必购商品
    mustbuys = MainMustBuy.objects.all()
    # 便利店商品
    shops = MainShop.objects.all()
    shop0 = shops.first()
    shop1_2 = shops[1:3]
    shop3_6 = shops[3:7]
    shop7_10 = shops[7:11]
    # 主体数据
    mainshows =MainShow.objects.all()

    data = {
        'title': '首页',
        'wheels': wheels,
        'navs': navs,
        'mustbuys': mustbuys,
        'shop0':shop0,
        'shop1_2':shop1_2,
        'shop3_6':shop3_6,
        'shop7_10':shop7_10,
        'mainshows':mainshows,
    }
    return render(request, 'home/home.html', context=data)


# 闪购
def market(request):
    return redirect(reverse('axf:market_with_params',args=('104749','0','0')))

def market_with_params(request,typeid,cid,sort_id):
    # 主商品分类数据
    foodtypes = FoodType.objects.all()
    # 获取商品数据
    goods_list = Goods.objects.filter(categoryid=typeid)

    # 如果不是全部类型，则继续根据子分类cid进行筛选
    if cid != '0':
        goods_list = goods_list.filter(childcid=cid)

    # 子分类
    # 获取商品分类名字
    all_child_type = []
    current_types = foodtypes.filter(typeid=typeid)
    if current_types .exists():
        current_type = current_types.first()
        childtypenames = current_type.childtypenames
        child_type_list = childtypenames.split('#')
        for s in child_type_list:
            l = s.split(':')
            all_child_type.append(l)
    # 获取对应分类名字
    cid_name = ""
    for k in all_child_type:
        if k[1] == cid :
            cid_name = k[0]

    sort_name =""
    # 排序规则
    if sort_id == "0" :  # 综合排序
        sort_name = "综合排序"
    elif sort_id == "1":  # 销量排序
        goods_list = goods_list.order_by('-productnum')
        sort_name = "销量排序"
    elif sort_id == "2":  # 价格降序
        goods_list = goods_list.order_by('-price')
        sort_name = "价格降序"
    elif sort_id == "3": # 价格升序
        goods_list = goods_list.order_by('price')
        sort_name = "价格升序"

    print(sort_name)

    data = {
        'title': '闪购',
        'foodtypes':foodtypes,  # 所有分类数据
        'goods_list':goods_list,    # 当前分类下的所有商品
        'typeid':typeid, # 当前的类型id
        'all_child_type':all_child_type,    # 当前主分类下的子分类数据
        'cid':cid,  # 当前子分类下的id
        'sort_name':sort_name,  # 当前子分类下的排序名字
        'cid_name':cid_name,    # 当前子分类下的名字
    }
    return render(request, 'market/market.html', data)

# 我的
def mine(request):
    username = request.session.get('username','')
    # img_url = request.session.get('img_url','')
    data = {
        'title': '我的',
        'username':username,
        # 'img_url':img_url,
    }
    return render(request, 'mine/mine.html', data)

# 登出（删除session）
def logout(request):
    del request.session['username']
    # del request.session['img_url']
    return redirect(reverse('axf:mine'))

# 我的-注册
def register(request):
    # 点了提交 POST
    if request.method == 'POST':
        # 获取浏览器表单提交的数据
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        icon = request.FILES.get('icon')
        # 上传图片到本地路径
        file_path = os.path.join(settings.MEDIA_ROOT,icon.name)
        with open(file_path, 'ab') as fp:
            for part in icon.chunks():
                fp.write(part)

        # 判断是否合法  1.用户名已存在 2,邮箱已被占用 3,输入不合法
        # 获取数据库中的数据
        username_sql = User.objects.filter(username=username)
        email_sql = User.objects.filter(email=email)
        if username_sql.exists():
            return HttpResponse("用户名已存在，请重新输入")
        if email_sql.exists():
            return HttpResponse("邮箱已存在，请重新输入")
        res1 = re.findall('^[a-zA-Z_]\w{5,17}$',username)
        res2 = re.findall('^\w{8,}$',password)
        res3 = re.findall('^\w+@\w+\.\w+$', password)

        # 注册，
        try:
            user = User()
            user.username = username
            user.password = password
            user.email = email
            user.icon_name = icon.name
            user.save()
            # 注册成功 跳'我的'页面
            request.session['username'] = username
            # request.session['img_url'] = file_path
            return redirect(reverse('axf:mine'))
        except:
            return HttpResponse("注册失败,请重新注册")

    # GET
    else:
        return render(request, 'user/register.html')

# 登录
def login(request):
    # 点了提交 POST
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        try:
            username_sql = User.objects.get(username=username)
        except:
            return HttpResponse("账号或密码错误,请重新输入...")

        if username_sql.password == password:
            # file_path = os.path.join(settings.MEDIA_ROOT, username_sql.icon_name)
            # request.session['img_url'] = file_path
            request.session['username'] = username
            return redirect(reverse('axf:mine'))
        elif username_sql.password != password :
            return HttpResponse("账号或密码错误,请重新输入...")




    # 一开始的初始页面
    else:
        return render(request,'user/login.html')


# 购物车
def cart(request):
    data = {
        'title': '购物车',
    }
    return render(request, 'cart/cart.html', data)



