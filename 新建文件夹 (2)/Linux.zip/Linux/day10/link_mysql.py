# coding=utf-8
import pymysql

# 服务的端口是 3306
# 服务的host是 127.0.0.1
# 当前数据库账户是 root
# 当前的密码是     123

# 1. 通过代码连接数据库 pymsql.Connect
db = pymysql.Connect(host='127.0.0.1',port=3306, user='root', password='123' ,db='CodeLanguage', charset='utf8')
# 2.获取数据库操作游标 cursor
cursor = db.cursor(cursor=pymysql.cursors.DictCursor)
# 3.执行sql语句，先来个查询
sql_string = 'select * from Star,house where Star.house_id=house.id'

# 4.执行完sql语句，返回受影响的行数 ,使用excute 来执行sql_string
star_num = cursor.execute(sql_string)

# 5.打印数据库查询语句的内容的数量
print(star_num)

# 6.获取游标中所有数据行的内容
results = cursor.fetchall()

# 7.result 是一个python的列表 有13个数据的明星的名字打印出来
for star_data in results:
    print(star_data['star_name'],star_data['money'],star_data['address'])

# 8.关闭游标数据库连接
cursor.close()
# 9.关闭数据库连接
db.close()

try:
	cursor.execute(sql)
	# cursor.execute(sql)
	# cursor.execute(sql)
	# cursor.execute(sql)
	# 如果全部执行成功，提交事务
	db.commit()
except Exception as e:
	print(e)
	db.rollback()
finally:
	cursor.close()
	db.close()


# 1.要注意编码是,只要是开启了数据库连接,执行完成后必须要关闭数据库连接
# 2.在我们创建数据库的时候,加大数据库连接配置最大不能超过200
# 3.如果数据库连接过大,我们可以使用资源回收策略,超过一定时间不传输数据的连接自动关闭
# 4.日常操作中,减少直接对数据库的操作,譬如使用redis内存数据库减低数据库压力
# (一个数据库语句可以是一个数据库事务,如果直接每一次都做提交一条,
# 数据库连接数量会过大,使用内存数据库的的话可以把一些频繁查询的语句的查询的数据保存在redis内存数据库中,
# 下次执行同样的数据库语句时,我们可以让他自己从内存数据库中取出,而不需要从mysql数据库中查找.
# 这样做,会减少重复查询的问题)
# 5.如果确实需要有大量的数据连接,这样可以重新设计数据表,进行架构调整,分库(按功能)分表





