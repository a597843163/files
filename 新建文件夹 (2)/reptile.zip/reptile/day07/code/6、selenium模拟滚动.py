from selenium import webdriver
import time

driver = webdriver.Chrome()
# url = 'http://sc.chinaz.com/tupian/ribenmeinv.html'
url = 'https://movie.douban.com/'
driver.get(url)

driver.save_screenshot('douban1.png')

time.sleep(5)

# chrome浏览器
js = 'document.body.scrollTop=10000'
# firefox浏览器
# js = 'document.documentElement.scrollTop=10000'
driver.execute_script("window.scrollTo(0, document.body.scrollHeight)")
js_list = [
	# 移动到元素element对象的“顶端”与当前窗口的“顶部”对齐
	# ("arguments[0].scrollIntoView();", element),
	# ("arguments[0].scrollIntoView(true);", element),

	# 移动到元素element对象的“底端”与当前窗口的“底部”对齐
	# ("arguments[0].scrollIntoView(false);", element),

	# 移动到页面最底部
	("window.scrollTo(0, document.body.scrollHeight)"),

	# 移动到指定的坐标(相对当前的坐标移动)
	("window.scrollBy(0, 700)"),
	# Thread.sleep(3000),
	# 结合上面的scrollBy语句，相当于移动到700+800=1600像素位置
	("window.scrollBy(0, 800)"),

	# 移动到窗口绝对位置坐标，如下移动到纵坐标1600像素位置
	("window.scrollTo(0, 1600)"),
	# Thread.sleep(3000),
	# 结合上面的scrollTo语句，仍然移动到纵坐标1200像素位置
	("window.scrollTo(0, 1200)")
]
driver.save_screenshot('douban2.png')
time.sleep(5)

with open('riben.html', 'w', encoding='utf-8') as fp:
	fp.write(driver.page_source)

driver.quit()