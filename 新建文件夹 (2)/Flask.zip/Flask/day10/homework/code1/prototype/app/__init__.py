from flask import Flask
from .views import user
from .config import Config
from .extensions import config_extensions

# 注册蓝本
def create_app():
    app=Flask(__name__)
    app.register_blueprint(user, url_prefix='/user')  # 注册蓝本
    app.config.from_object(Config)  # 加载配置
    config_extensions(app)
    return app



