
import re
from urllib import request
# 作业2: 爬取糗事百科文本页的所有段子,结果如 : xx说: xxxx
#   设置代理： User-Agent
# https://www.qiushibaike.com/text/page/1/

# ("<div class="author clearfix">(.*?)<span class="stats-vote"><i class="number">" , re.S)

htmlStr = "https://www.qiushibaike.com/text/page/1/"
#  请求对象
Myrequest = request.Request(htmlStr,headers={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36"})
# 得到响应，得到字符串
response = request.urlopen(Myrequest)
htmlStr = response.read().decode("utf-8")

# 大筛选
regCom = re.compile('<div class="author clearfix">(.*?)<span class="stats-vote"><i class="number">', re.S)
itemList = regCom.findall(htmlStr)

for item in itemList:
    nameCom = re.compile('<h2>(.*)</h2>', re.S)
    name = nameCom.findall(item)[0]  # "甜甜妞"

    contentCom = re.compile('<span>(.*)</span>', re.S)
    content = contentCom.findall(item)[0]
    print(name,content)

