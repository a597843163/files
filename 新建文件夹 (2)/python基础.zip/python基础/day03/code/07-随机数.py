
# 导入一个随机数random模块
import random


# random.choice()
names = ["宝强", "PGone", "宋喆"]

# 随机从names中获取一个元素
name = random.choice(names)
print(name)

# range(100) : 表示0-99的整数， 不包括100
# range(10) : 表示0-9的整数，不包括10
n = random.choice(range(10))
print(n)

# range(5, 11) :表示5-10的整数, [5, 11)
n = random.choice(range(5, 11))
print(n)


# random.randrange()
# 参数1： 表示起始的数
# 参数2： 表示结束的数
# 参数3： 表示的步数，每次递增的数，
# 如(5, 10, 2) 从5开始每次递增2，一直到10为止（不包括10）,也就是从5,7,9中随机取一个数
n = random.randrange(5, 10, 2) # [5, 10)
print(n)

b = random.randrange(1,10)


# random.random() : 获取一个[0,1)的随机数
n = random.random()
print(n)


# random.uniform() : 取1到2之间的随机数
n = random.uniform(1, 2)
print(n)


# random.shuffle() : 把列表中的元素乱序
list1 = [1, 2, 3, 4]
random.shuffle(list1)
print(list1)



