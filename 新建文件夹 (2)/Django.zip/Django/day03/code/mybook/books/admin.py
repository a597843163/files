from django.contrib import admin
from .models import Book

#
class BookAdmin(admin.ModelAdmin):

    # 列表页面
    list_display = ['title','publicatiom_date']  # 设置需要显示的字段
    search_fields = ["title"]   # 搜索框，设置要搜索的关键字段
    list_filter = ['publicatiom_date']  # 过滤器
    date_hierarchy = 'publicatiom_date'  # 水平方向的日期过滤器
    #ordering = ['title'] # 排序
    ordering = ['-title']  # 反向排序
    actions_on_top = False # 列表顶部的动作条
    actions_on_bottom = True   # 列表底部的动作条
    list_per_page = 3   # 每一页显示数量

    # 添加，修改界面
    # 显示编辑的项目和顺序
    # fields = ['title','publicatiom_date','authors','publisher']
    # exclude = ['authors']   # 排除编辑的项目
    # filter_vertical = ['authors']    # 多对多，垂直方向
    # filter_horizontal = ['authors'] # 多对多，水平方向显示控件
    # raw_id_fields = ['publisher']   # 1对多，直接显示id
    fieldsets = (
        ("标题",{"fields":['title','publicatiom_date']}),
        ("出版社",{"fields":['publisher']})
    )
    # fields 和fieldsets不要同时使用

admin.site.register(Book,BookAdmin)