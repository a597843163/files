
class Clip(object):
    def __init__(self,number):
        self.number = number  # 子弹数量

    # 获取子弹数量
    # def getNumber(self):
    #     return self.number





