from flask import Flask,render_template,flash,get_flashed_messages,redirect,url_for,request,send_from_directory
from flask_script import Manager
from flask_bootstrap import Bootstrap

from flask_wtf import FlaskForm #导入需要自定义表单类的基类
#导入表单字段
from wtforms import StringField,PasswordField,SubmitField
from wtforms.validators import DataRequired #导入验证器

from flask_moment import Moment #导入格式化时间的扩展库
from datetime import datetime,timedelta
import os,string,random



app = Flask(__name__)
app.config['SECRET_KEY'] = 'abcdef' #csrf加密字符串
bootstrap = Bootstrap(app)
moment = Moment(app)    # 格式化时间扩展库
#设置允许文件上传的类型
ALLOWED_EXTENSIONS = ['png','jpg','jpeg','gif']
app.config['MAX_CONTENT_LENGTH'] = 1024*1024*64 #回去自己算这是多大？
app.config['UPLOAD_FLODER'] = os.getcwd()  # 设置当前目录路径为上传图片路径
manager = Manager(app)

class LoginForm(FlaskForm):
    username = StringField('用户名',validators=[DataRequired(message='必填字段')])
    userpass = PasswordField('密码',validators=[DataRequired(message='密码必填')])
    submit = SubmitField('提交')


@app.route('/')
def index():
    current_time = datetime.utcnow()+timedelta(seconds=-3600)   # 设置current_time为前一个小时
    return render_template('index.html',current_time=current_time)

@app.route('/login/',methods=['GET','POST'])
def login():
    # 创建LoginForm类的对象
    form = LoginForm()
    if form.validate_on_submit():  # 在点击form表单提交时，method为POST和验证器通过时为true
        if form.username.data != 'zhangsan':
            flash('请输入正确的用户名')
        elif form.userpass.data != '123456':
            flash('密码不正确')
        else:
            flash('登录成功 欢迎{}'.format(form.username.data))
            return redirect(url_for('index')) #登录成功 跳转到首页
    return render_template('login.html',form=form)

#判断当前文件是否存在于ALLOWED_EXTENSIONS 列表中
def allowedFile(shuffix):
    extensions = shuffix.strip('.')
    return extensions in ALLOWED_EXTENSIONS

#生成随机的图片名称 数字+字母随机数
#shuffix 为图片的后缀
#length 为当前图片的名字的长度
def randomName(shuffix,length=32):
    # 生成A-Za-z0-9的字符串
    myStr = string.ascii_letters+'0123456789'
    # print(myStr)
    # 从mystr中取32位随机字符+后缀名作文图片新名字
    newName = ''.join(random.choices(myStr,k=length))+shuffix
    return newName

#自定义路由 获取图片的显示
@app.route('/get_url/<filename>')
def getUrl(filename):
    # 下载图片
    # 会返回一个图片路由
    print('geturl函数:',send_from_directory(app.config['UPLOAD_FLODER'],filename))
    return send_from_directory(app.config['UPLOAD_FLODER'],filename)

#文件上传的路由
@app.route('/upload/',methods=['GET','POST'])
def upload():
    # print(request.files)
    img_url = None
    if request.method == 'POST':
        file = request.files.get('file') #获取上传的文件
        shuffix = os.path.splitext(file.filename)[-1] #获取文件的后缀
        if allowedFile(shuffix):
            newName = randomName(shuffix) #生成随机图片名
            #拼凑出保存的路径
            newPath = os.path.join(app.config['UPLOAD_FLODER'],newName) #获取图片生成的新的图片名称
            print('保存的路径：',newPath)
            file.save(newPath) # 将html上传的图片进行保存
            img_url = url_for('getUrl',filename=newName) # 获取图片的地址
    return render_template('upload.html',img_url=img_url)

if __name__ == '__main__':
    manager.run()

"""
获取文件后缀的方式
1. '17.jpg'.split('.')[-1]
2. filetype()
3 17.jpg['17.jpg'.rfind('.'):]
4 os.path.splitext(17.jpg)

strip 同时去掉左右两边的空格
lstrip 去掉左边的空格
rstrip 去掉右边的空格
"""