# 析构函数： __del__()

class GirlFriend(object):

    # 构造函数 : 对象在创建的时候会自动调用
    def __init__(self, name, height, sex, age):
        self.name = name
        self.height = height
        self.sex = sex
        self.age = age

    # 析构函数 : 在对象销毁时会自动调用
    def __del__(self):
        print("对象被销毁了")


# 创建对象
girlFriend = GirlFriend("刘亦菲", 168, "女", 18)

# del : 删除对象， 删除对象时会释放内存，会立刻调用__del__函数
del girlFriend

print("hello 志玲")

