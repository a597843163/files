from django.shortcuts import render
from .models import Publisher

# Create your views here.

def index(request):
    pub_all = Publisher.objects.all()
    return render(request,'publishers/index.html',{'pub_all':pub_all})

def publisher(request,id1):
    pub = Publisher.objects.get(id = id1)
    return render(request,'publishers/detail.html',{'pub':pub})


