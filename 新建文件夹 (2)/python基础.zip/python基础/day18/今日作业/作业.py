

#
# 1,自己实现冒泡排序, 选择排序, 快速排序
list = [8, 9, 6, 7, 3, 5, 4, 2, 1]
# 冒泡排序： 左右两个对比
# 选择排序：第一个和后面几个对比
# 快速排序：从中间选择开始比，递归得结果
# 1 ,升序
for i in range(len(list)-1) :    #  第一轮
    for j in range(len(list)-1-i):
        if list[j]>list[j+1]:
            list[j],list[j+1] = list[j+1],list[j]

print(list)

# 2.选择排序
list = [8, 9, 6, 7, 3, 5, 4, 2, 1]
for i in range(len(list)-1):
    for j in range(i+1,len(list)):
        if list[i]>list[j]:
            list[i],list[j] = list[j],list[i]
print(list)

# 快速排序
def fn(list):
    if len(list)<=1:
        return list
    index = len(list)//2
    res = list.pop(index)
    list1 = []  # 大
    list2 = []  #  小
    for i in list:
        if i < res :
            list1.append(i)
        else:
            list2.append(i)

    return fn(list1)+[res]+fn(list2)


list = [8, 9, 6, 7, 3, 5, 4, 2, 1]
print(fn(list))



# 2,自己实现列表的去重, 不要用set(去掉列表中的重复元素，保持还是之前列表顺序)
list1 = [1,2,3,4,2,3,2,2,2,1,1,6,5,5,6]  # --> [1,2,3,4,6,5]

# 1
i = 0
while i < len(list1)-1:

    j = i+1
    while j < len(list1):

        if list1[i] == list1[j]:
            list1.pop(j)
        else:
            j += 1

    i += 1

print(list1)  # [1, 2, 3, 4, 6, 5]

# 2
list1 = [1,2,3,4,2,3,2,2,2,1,1,6,5,5,6]  # --> [1,2,3,4,6,5]
list2 = []
for i in list1:
    if i not in list2:
        list2.append(i)

print(list2)  # [1, 2, 3, 4, 6, 5]

# 3
list1 = [1,2,3,4,2,3,2,2,2,1,1,6,5,5,6]  # --> [1,2,3,4,6,5]
list2 = []
[list2.append(i) for i in list1 if i not in list2]
print(list2)  # [1, 2, 3, 4, 6, 5]


# 3,列出Python2和Python3的6点区别
# 1.不等于  Python2 <>
#           python3 !=
#  2. 加入as with关键字，还有True，False,None
# 3.加入nonlocal 语句
# 4.去除print语句，加入print()函数
# 5。去除raw_input语句   ，加入input()函数
# 6.super()不需要再传参数



# 4,使用高阶函数去除只包含字符串元素列表中的空白字符串, ""和"  "都是空白字符串
# filter
list2 = ["a", "b", "", "  ", " ", "c", "     ", "  d   "]

# 1
# def fn1(n):
#     if n.strip() != "":
#         return True

def fn1(n):
    return n.strip()

# 2
# isspace() : 字符串是否是空格字符串
def fn2(n):
    if n!="" and not n.isspace():
        return True

# 3
import re
def fn3(n):
    if n!="" and not re.search("^ +$", n):
        return True

# res = filter(fn3, list2)
# print(list(res))  # ['a', 'b', 'c', '  d   ']

# 4
# print(list(filter(lambda x:x.strip(), list2)))
# ['a', 'b', 'c', '  d   ']

#
# lambda x:x.strip()
# 相等于下面的函数
# def fn1(x):
#     return x.strip()
#








