

import re

# re.math()
# re.search()
# re.findall()

# 先将正则表达式编译成一个正则对象,然后再使用math,search,findall
reg = "^1[345789]\d{9}$"
com = re.compile(reg)

list1 = com.findall("13838384389")
print(list1)        # ['13838384389']







