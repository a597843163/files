
import os

# 递归来遍历目录
def getAllDirAndFile(sourcePath):

    # 如果目录不存在，则直接返回
    if not os.path.exists(sourcePath):
        return "目录不存在"

    # 如果存在
    fileNameList = os.listdir(sourcePath)

    # 遍历目录下的子目录和子文件
    for fileName in fileNameList:
        absPath = os.path.join(sourcePath, fileName)

        if os.path.isfile(absPath):  # 文件
            print("fileName: ", fileName)
        elif os.path.isdir(absPath):  # 目录
            print("dirName: ", fileName)

            # 递归遍历
            getAllDirAndFile(absPath)

if __name__ == "__main__":
    path = r"C:\wamp\www\day11\code\newdir"
    getAllDirAndFile(path)



