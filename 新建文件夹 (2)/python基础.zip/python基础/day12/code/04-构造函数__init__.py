
#  包中__init__.py 是一个python文件

# 构造函数: __init__()


# 类
class Person(object):

    # name = "金三胖"
    # age = 33

    # 构造函数__init__是在创建对象时自动调用，不需要我们手动调用
    #  如果不写__init__，默认也会有一个__init__方法，内部没有代码
    def __init__(self, name, age):
        #print("这是构造函数")

        # 成员属性/成员变量
        self.name = name
        self.age = age
        # 这里的self就是baoqiang对象
        #  print(id(self))

    def eat(self):
        print("是吃货", id(self))
    def sleep(self):
        print("爱睡觉")


# 创建对象（实例化）
# 实例：对象
# person1 = Person()
# print(person1.name, person1.age)
#
# person2 = Person()
# print(person2.name, person2.age)

# 初始化
baoqiang = Person("宝强", 33)  # name="宝强" age=33
# baoqiang.eat()      # 37660936
# print(id(baoqiang))  # 37660936
print(baoqiang.name, baoqiang.age)  # 宝强 33


marong = Person("马蓉", 32)
# baoqiang2.eat()      # 37661048
# print(id(baoqiang2))  # 37661048
print(marong.name, marong.age)  # 马蓉 32

# 创建的不同对象拥有自己独立的内存空间，不同对象的地址是不一样

# 修改属性值
baoqiang.name = "唐仁"
print(baoqiang.name)



