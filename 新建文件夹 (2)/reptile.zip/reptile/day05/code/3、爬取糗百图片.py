import urllib.request
import urllib.parse
import re


def handler_url(page, base_url):
    # 拼接url
    url = base_url + str(page) + '/'

    # 设置headers
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36'
    }
    request = urllib.request.Request(url=url, headers=headers)

    response = urllib.request.urlopen(request)
    return response.read().decode('utf-8')


def search_img(html):
    # 使用正则搜寻html页面中的符合要求的img的地址。
    pattern = re.compile(r'<div class="thumb">.*?<img src="(.*?)" alt=.*?/>.*?</div>', re.S)
    img_list = pattern.findall(html)
    return img_list


def download_img(img_url):
    # 处理img_url
    img_url = 'https:' + img_url
    filename = img_url.split('/')[-1]
    filename = './qiubai/' + filename
    urllib.request.urlretrieve(img_url, filename=filename)


def main():
    base_url = 'https://www.qiushibaike.com/pic/page/'

    start_page = int(input('请输入您要爬取的起始页：'))
    end_page = int(input('请输入您要爬取的结束页：'))

    for page in range(start_page, end_page + 1):
        # 处理url
        html = handler_url(page, base_url)

        # 正则搜索
        img_list = search_img(html)
        print(img_list)
        # 执行下载
        print('开始下载')
        for img_url in img_list:
            # 对每一个img地址都进行下载
            download_img(img_url)
        print('结束下载')


if __name__ == '__main__':
    main()