from django.db import models

# Create your models here.

class UserType(models.Model):
    caption = models.CharField(max_length=30)

    def __str__(self):
        return self.caption

def fn():
    return 2

class UserInfo(models.Model):
    name = models.CharField(max_length=30)
    age = models.PositiveIntegerField()
    user_type = models.ForeignKey('UserType',related_name='info')
    # user_type = models.ForeignKey(UserType,on_delete=models.CASCADE)    # 默认值，表示级联删除
    # user_type = models.ForeignKey(UserType,on_delete=models.PROTECT)    # 保护模式，阻止级联删除
    # user_type = models.ForeignKey(UserType,on_delete=models.SET_NULL,null=True)    # 不会删除级联数据，但是会设置为null
    # user_type = models.ForeignKey(UserType,on_delete=models.SET_DEFAULT,default=1)    # 不会删除级联数据，但是会设置为默认值default
    # user_type = models.ForeignKey(UserType,on_delete=models.DO_NOTHING)    # 不会删除级联数据，什么都不做


    def __str__(self):
        return self.name


