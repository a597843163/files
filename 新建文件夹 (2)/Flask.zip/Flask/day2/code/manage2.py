from flask_script import Manager
from flask import Flask, session, redirect, url_for, request, render_template, render_template_string

app = Flask(__name__)
manager = Manager(app)

@app.route('/')
def index():
    # return '首页'
    # 渲染模板
    return  render_template('index.html',title = '变量首页',var={'num':-20,'bool':False,'str':'abcd','list':['a','b','c','d'],'html':'<b>加粗</b>','dict':{'name': "zhangsan", 'age':18}})
    # return render_template_string('<span style="color:red;font-size:20px ">首页在这</span>')

if __name__ ==  '__main__':
    manager.run()




