
from enum import Enum ,unique


@unique
class Color(Enum):
    red = 1
    red_alias = 2

print(Color['red_alias'])
print(Color(1))
red_member = Color.red

print(red_member.name)
print(red_member.value)

class Color(Enum):
    red = 1
    orange = 2
    yellow = 3
    green = 4
    blue = 5
    indigo = 6
    purple = 7
    red_alias = 1

print(Color)         #   <class '__main__.Color'>   <enum 'Color'>
                    #  <class 'type'>           <class 'enum.EnumMeta'>
print(type(Color))
for color in Color.__members__.items():
    print(color)







