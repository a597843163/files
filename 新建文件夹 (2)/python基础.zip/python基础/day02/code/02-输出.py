


print("hello")
print("world")

# 逗号可以连接多个输出，逗号会被解析成空格
# + 加号用来连接两个字符串，也可以作为数字相加
print("宝强", "马蓉")
print("奥巴马", 57)
print("金正恩" + "奥巴马")
print(1 + 1)

