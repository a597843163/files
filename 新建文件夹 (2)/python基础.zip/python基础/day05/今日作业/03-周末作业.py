
''''''

# 1. 输出10行内容，每行的内容都是“*****”。
for i in range(1,11):
    print("*****")
print()
# 2. 输出10行内容，每行的内容都不一样，第1行一个星号，第2行2个星号，依此类推第10行10个星号。
for i in range(1,11):
    for j in range(1,i+1):
        print("*",end="")
    print()

# 3. 输出9行内容，第1行输出1，第2行输出12，第3行输出123，以此类推，第9行输出123456789。
j =0
for i in range(1,10):
        j = j*10 +i
        print(j)

# 4. 计算10个99相加后的值并输出。
sum = 0
for i in range(1,11):
    sum += 99
print(sum)

# 5. 计算从1加到100的值并输出。
sum = 0
for i in range(1,101):
    sum += i
print(sum)

# 6. 计算10的阶乘（1x2x3x4x5x6x7x8x9x10）
sum = 1
for i in range(1,11):
    sum *= i
print(sum)

# 7. 计算2的20次方。不允许用**和pow()
print(pow(2,20))
a = 1
for i in range(1,21):
    a *= 2
print(a)

# 8. 计算从1到1000以内所有奇数的和并输出。
sum = 0
for i in range(1,1001):
    if i % 2 != 0:
        sum += i
print(sum)

# 9. 计算从1到1000以内所有能被3或者17整除的数的和并输出
sum = 0
for i in range(1,1001):
    if i % 3 ==0 or i % 17 ==0 :
        sum += i
print(sum)


# 10. 计算从1到1000以内所有能同时被3，5和7整除的数的和并输出
sum = 0
for i in range(1,1001):
    if i % 3 ==0 and i % 5 ==0 and i % 7 ==0 :
        sum += i
print(sum)



# 11. 计算1到100以内能被7或者3整除但不能同时被这两者整除的数的个数。
sum = 0
for i in range(1,101):
    if (i % 3 ==0 or i % 7 ==0) and i % 21 != 0 :   # (i %3 ==0 and i % 7 != 0) or (i % 3 != 0 and i % 7 == 0)
        sum += 1                # (i % 3 ==0 or i % 7 ==0) and i % 21 != 0 :
print(sum)


# 12. 计算1到100以内能被7整除但不是偶数的数的个数。

sum = 0
for i in range(1,101):
    if i %7 ==0 and i % 2 !=0:
        sum += 1
print(sum)



print()
# 13. 计算从1到100临近两个整数的合并依次输出。比如第一次输出3(1+2)，第二次输出5(2+3)，最后一次输出199(99+100)。
for i in range(1,100):
    sum = 2*i +1
    print(sum)
'''
# 14. 给定一个不大于9的数n，打印nn乘法表
n = int(input("请输入一个数："))
for i in range(1,n+1):  # 行
    for j in range(1,i+1):
        print(str(j)+"*"+str(i)+"="+str(j*i),end ="\t")
    print()
'''
# 15. 给定一个n位（不超过10）的整数，将该数按位逆置，例如给定12345变成54321，12320变成2321.

n = int(input("请输入一个不超过10的整数:"))
list = str(n)
list1 = list[::-1]
n1 = int(list1)
print(n1)
'''
'''
# 16. 一球从100米高度自由落下，每次落地后反跳回原高度的一半，再落下。求它在第n次落地时，共经过多少米？
n = int(input("请输入一个第几次落地:"))
s = 100
sum = 100
if n > 1:
      for i in range(1,n):
          s =float( s / 2)
          sum = float(sum+ 2*s)
      print("请输入一个第%d次落地,一共经过%.3f米"%(n,sum))
else:
    print("请输入一个第%d次落地,一共经过%d米"%(n,sum))



# 17. 已知 abc+cba=1333, 其中的a,b,c均为一位数，编写一个程序，求出a,b,c分别代表什么数字
'''
for a in range(0,10):
    for b in range (0,10):
        for c in range(0,10):
            if (a+c)*101+b*20 == 1333 :
                print(a,b,c)
                break
'''
