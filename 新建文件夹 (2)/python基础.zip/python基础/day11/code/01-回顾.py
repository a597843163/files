

'''

    模块： 一个.py文件对应一个模块
    导入模块： import 模块名称
              from 模块名 import 函数/变量
              from 模块名 import *
    包 ：可以包含多个模块
         文件夹中如果有__init__.py文件，则认为是包
    导入包中的模块：
          import 包名.模块名
          from 包名 import 模块名
          from 报名.模块名 import 函数/变量

    __name__ : 特殊的变量,会自动赋值
            if __name__ == "__main__":
                测试代码

    calendar模块：
        calendar(year,w=2,l=1,c=6)
            打印某一年的日历【c间隔距离; w每日宽度间隔; l是每星期行数 】
        isleap(year)   判断是否是闰年
        leapdays(y1, y2)  [y1, y2) 中间闰年的个数
        month(year,month,w=2,l=1)  打印指定月份的日历
        monthcalendar(year,month)
            返回一个整数的单层嵌套列表。每个子列表装载代表一个星期的整数。Year年month月外的日期都设为0;范围内的日子都由该月第几日表示，从1开始。
        monthrange(year,month)
            返回两个整数。第一个是该月的星期几的日期码，第二个是该月的日期码。日从0（星期一）到6（星期日）;月从1到12。

    datetime模块：
        dt_now = datetime.datetime.now()
                获取当前的日期对象，包含时间的
        dt_ziding = datetime.datetime()
                根据指定的日期、时间生成一个日期对象
        dt.strftime()  将日期对象转化为指定的格式
        dt.date()   获取日期对象中的日期
        dt.time()   获取日期对象中的时间
        dt.timestamp()  获取日期对象的时间戳
        dt.hour\minute\second  获取小时、分钟、秒
        datetime.datetime.fromtimestamp()
                根据一个时间戳，转化为指定的日期对象
        datetime.timedelta()
                生成一个差值对象，可以和日期对象直接进行相加减
                参数有，days,hours,minutes,seconds

    hashlib模块
        hash = hashlib.md5()
        hash.update('admin'.encode('utf-8'))
        tmp = hash.hexdigest()

    函数的递归：
        5！
        4! *5
        3! *4 *5
        2! *3 *4 *5
        1! *2 *3 *4 *5
        1 *2 *3 *4 *5
        -> f(n) = f(n-1)*n
        -> n=1, f(n)=1

        def fn(n):
            if n=1:
                return 1
            return fn(n-1)*n
        fn(n)


'''

# 入口
# main()




