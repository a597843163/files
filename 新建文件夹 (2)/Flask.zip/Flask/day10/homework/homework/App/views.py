import os

from django.shortcuts import render, redirect

from django.urls import reverse

from App.models import User
from homework import settings


def home(request):
    # {'username': username}
    username = request.session.get('username','')
    return render(request,'home.html',{'username':username})

def home_logined(request):
    username = request.session.get('username', '')
    return render(request,'home_logined.html',{'username':username})

def home_logined_collected(request):
    return render(request,'home_logined_collected.html')


# ----------登陆 ------------- #
def login(request):
    # 点了提交 POST
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # print('username',username)
        # print('password',password)
        # 先验证是否存在匹配的用户，然后再验证密码
        users = User.objects.filter(username=username)
        if users.exists():
            user = users.first()
            if user.password == password:
                # 登陆成功，保存session
                request.session['username'] = username
                return redirect(reverse('homework:home_logined'))
        else:
            return redirect(reverse('homework:login'))
    # 一开始的初始页面
    else:
        return render(request, 'login.html')

# 登出（删除session）
def logout(request):
    request.session.flush()  # 删除全部
    return redirect(reverse('homework:home'))


# ----------注册 ------------- #
def register(request):
    # 点了提交 POST
    if request.method == 'POST':
        # 获取浏览器表单提交的数据
        username = request.POST.get('username')
        password = request.POST.get('password')
        icon_name = request.FILES.get('icon')
        # print('username',username)
        # print('password', password)
        # print('icon_name', icon_name)
        # 上传图片到本地路径
        file_path = os.path.join(settings.MEDIA_ROOT,icon_name.name)
        with open(file_path, 'ab') as fp:
            for part in icon_name.chunks():
                fp.write(part)
        # 注册，
        try:
            user = User()
            user.username = username
            user.password = password
            user.icon_name = icon_name
            user.save()
            # 注册成功 跳'我的'页面,并自动登录
            request.session['username'] = username
            return redirect(reverse('homework:login'))
        except:
            return render(request, 'register.html')
    # GET
    else:
        return render(request, 'register.html')



# ----------修改信息 ------------- #
def userinfo_mod(request):
    username = request.session.get('username', '')
    u = User.objects.filter(username=username).first()
    file_path = os.path.join(settings.MEDIA_ROOT, u.icon_name)
    if request.method == 'POST':
        # 获取浏览器表单提交的数据
        email = request.POST.get('email')
        icon_name = request.FILES.get('icon')
        # print('email',email)
        # print('icon_name', icon_name)
        # 上传图片到本地路径
        file_path = os.path.join(settings.MEDIA_ROOT,icon_name.name)
        with open(file_path, 'ab') as fp:
            for part in icon_name.chunks():
                fp.write(part)
        try:
            u.email = email
            u.icon_name = icon_name
            u.save()
            # 修改成功 跳'我的'页面,并自动登录
            request.session['username'] = username
            return redirect(reverse('homework:home_logined'))
        except:
            return render(request, 'userinfo_mod.html')
    # GET
    else:
        return render(request, 'userinfo_mod.html', {'username': username, 'file_path': file_path})




