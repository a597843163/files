from flask import Blueprint, render_template, request, redirect, url_for

from app.models import User

user = Blueprint('user',__name__)

@user.route('/register/',methods=['GET','POST'])
def register():
    # 点了提交 POST
    if request.method == 'POST':
        # 获取浏览器表单提交的数据
        username = request.form.get('username')
        password = request.form.get('password')
        icon = request.files.get('icon')
        # print('username',username)
        # print('password', password)
        # print('icon', icon)
        # 上传图片到本地路径
        # file_path = os.path.join(settings.MEDIA_ROOT, icon_name.name)
        # with open(file_path, 'ab') as fp:
        #     for part in icon_name.chunks():
        #         fp.write(part)
        # 注册，
        # try:
        #     user = User()
        #     user.username = username
        #     user.password = password
        #     user.icon_name = icon_name
        #     user.save()
        #     # 注册成功 跳'我的'页面,并自动登录
        #     request.session['username'] = username
        #     return redirect(url_for('homework.login'))
        # except:
        #     return render_template('register.html')
    # GET
    else:
        return render_template('register.html')


@user.route('/login/')
def login():
    return render_template('login.html')

@user.route('/userinfo/')
def userinfo():
    return render_template('userinfo_mod.html')

@user.route('/home/')
def home():
    # return 'home页面'
    return render_template('home.html')

@user.route('/homelogin/')
def home_login():
    return render_template('home_logined.html')

