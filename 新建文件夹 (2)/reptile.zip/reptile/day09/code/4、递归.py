def fab(n):
    if n< 0:
        print('请输入大于0的整数')
    elif n == 1 or n == 2:
        return 1
    else:
        return fab(n-1) + fab(n-2)

print(fab(50))
