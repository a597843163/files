

'''

    文件的操作：
        1，打开文件
        2，操作文件(读/写, IO：in,out):
                读取（从文件中读取出内容）：r :read
                写入（把内容写入到文件中）: w :write
                追加（把内容追加到文件中）：a :append
        3, 关闭文件


    文件的打开
        open(文件的路径，打开模式，编码，error="ignore")

        编码：
            默认GBK编码， 一般都设置为utf-8编码

            ASCII码：英文，数字，字符， 一个字节，总共128

            中国： gb2312
            日本，韩国

            Unicode： 2个字节

            utf-8 : 以后都用这个编码


        打开模式：
            r  : 以只读的方式打开， 如果文件路径不存在，会出现异常
            rb : 以只读二进制的方式打开, ...
            r+ : 在r的基础上可以写的方式打开, ...
            rb+: 在rb的基础上可以写的方式打开, ...

            w  : 以只写的方式打开, 如果文件路径不存在，会先创建文件,
                        打开文件的时候会将定位符放在前面，写入时会覆盖原来的内容
            wb : 以只写二进制的方式打开, ...
            w+ : 在w的基础上可以读的方式打开, ...
            wb+: 在wb的基础上可以读的方式打开, ...

            a  : 以追加的方式打开, 如果文件不存在， 会创建文件
                        打开文件的时候会将定位符放在末尾，写入的时候不会覆盖原来的内容
            ab : 以追加二进制的方式打开, ...
            a+ : 在a的基础上可以读的方式打开, ..
            ab+: 在ab的基础上可以读的方式打开, ...

        r ： 只读（获取内容）, 如果文件不存在会报错
        w :  只写（会覆盖原来的内容）,如果文件不存在，会创建文件
        a :  追加（不会覆盖原来的内容）, 如果文件不存在，会创建文件


'''

# 1, 打开文件
# 默认是使用GBK编码, 我们需要设置为utf-8
# 默认的打开模式是：r
# fp = open("情书.txt", encoding="utf-8")
# fp = open("情书2.txt", encoding="utf-8")  # 报错,文件路径找不到 :FileNotFoundError: [Errno 2] No such file or directory: '情书2.txt'
# fp = open("情书.txt", "w", encoding="utf-8", errors="ignore")
# fp = open("情书2.txt", "w", encoding="utf-8", errors="ignore")  # 如果文件不存在，会创建文件
fp = open("情书.txt", "a", encoding="utf-8")
# fp = open("情书.txt", "r+", encoding="utf-8")

# 二进制
# 注意： 只要有b的 都不需要加编码encoding='utf-8'
# fp = open("情书.txt", "rb")   # 以只读的方式读取二进制
# fp = open("情书.txt", "wb")  # 以只写的方式写入二进制（覆盖）
# fp = open("情书.txt", "ab")   # 以追加的方式写入二进制


# 2, 读取内容/写入内容
# 读： read()
# content = fp.read()
# print(content)


# 写：write()
fp.write("hello")
# fp.write("2344".encode(encoding="utf-8"))  # 将字符串转换成二进制, 编码encode()， decode():解码


# 3, 关闭文件
fp.close()





