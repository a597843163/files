from flask_wtf import FlaskForm
from wtforms import TextAreaField,SubmitField
from wtforms.validators import DataRequired,Length

#发表博客的帖子
class PostsForm(FlaskForm):
    content = TextAreaField('发表帖子',validators=[DataRequired(message='请输入内容...'),Length(min=6,max=300,message="帖子的子树为6~300个字之间")],render_kw={'placeholder':'发表一下此刻的感想...','style':'resize:none;','rows':'5'})
    submit = SubmitField('发表')
