


# 登录功能
def login():
    print("登录")

# 注册功能
def register():
    print("注册")


username = "baoqiang"
password = "123456"

print("模块2")




print(__name__)

# 主要是在模块内部做测试，当直接运行当前的python文件则__name__是"__main__"
#                       如果是被其他文件当做模块导入，则__name__是当前模块名称
if __name__ == "__main__":
    print("当前模块-module2")


