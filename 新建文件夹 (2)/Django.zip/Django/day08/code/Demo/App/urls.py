from django.conf.urls import url

from .views import *

urlpatterns = [
    url(r'^index/$',index,name='index'),
    url(r'^goods/$', goods, name='goods'),
    url(r'^get_goods/$', get_goods, name='get_goods'),
    url(r'^hello/$', hello, name='hello'),
    url(r'^getverifycode', get_verify_code, name='get_verify_code'),
    url(r'^userlogin/$', user_login, name='user_login'),
    url(r'^dologin/$', do_login, name='do_login'),
]



