# model

from sqlalchemy import create_engine

# 数据库的配置
USER_NAME = 'root'
PASSWORD = 'root'
HOST = '127.0.0.1'
PORT = 3306
DATABASE = 'flask'
DB_URL = 'mysql+pymysql://{}:{}@{}:{}/{}'.format(USER_NAME,PASSWORD,HOST,PORT,DATABASE)

print(DB_URL)

# 创建操作数据库的引擎
db = create_engine(DB_URL)

# 连接数据库
with db.connect() as con :
    # print(con)
    # con.execute('create table user(id int unsigned primary key auto_increment,username varchar(20))')
    # con.execute('insert into user values(null,"zhangsan")')
    # con.execute(sql语句)
    pass
