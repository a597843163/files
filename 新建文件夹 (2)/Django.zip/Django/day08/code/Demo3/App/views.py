from django.core.cache import cache
from django.http import HttpResponse
from django.shortcuts import render
import time

from django.template import loader
from django.views.decorators.cache import cache_page
from App.models import User

# 使用缓存,缓存失效
@cache_page(60)
def index(request):

    # 模拟耗时操作(操作数据库会比较耗时)
    time.sleep(10)

    return render(request,'index.html')

# 使用原生/底层  缓存
# @cache_page(10)
def get_user_list(request):

    # 先获取缓存中的数据
    # 如果缓存中有数据，则直接使用
    user_cache = cache.get("user")
    if user_cache:
        result = user_cache
    # 如果没有缓存，则从数据库中获取数据
    else:
        # 操作数据库，获取所有数据
        user_list = User.objects.all()
        time.sleep(5)
        data = {
            'users':user_list,
        }
        # 将从数据库获取的数据进行缓存，方便下次使用
        template = loader.get_template('userlist.html')
        result = template.render(data)  # 用数据data渲染模板

        # 进行缓存
        cache.set('user',result,10)
    return HttpResponse(result)





