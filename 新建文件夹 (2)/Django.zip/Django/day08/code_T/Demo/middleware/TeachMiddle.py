from django.http import HttpResponse
from django.shortcuts import redirect
from django.utils.deprecation import MiddlewareMixin


# 自定义的中间件
class HelloMiddleware(MiddlewareMixin):
    def process_request(self, request):
        print("请求的路径: ", request.path)
        print('访问者的地址：', request.META['REMOTE_ADDR'])

        ip = request.META['REMOTE_ADDR']
        # if ip == '10.36.137.237':
        #     return HttpResponse('本网站不欢迎你！')

        if request.path == '/app/getgoods/':
            username = request.POST.get('username')
            if username == '习大大':
                return HttpResponse('恭喜您，获得满1000减1000的优惠券！')
            if ip == '10.36.138.1':
                return HttpResponse("优惠券已抢完")
            if username == '凤姐':
                return HttpResponse('优惠券已抢完')
            if not username:
                return HttpResponse("请输入合法的用户名")

    # 如果出现异常，会捕获到
    def process_exception(self, request, exception):
        print('exception:', str(exception))
        return redirect('/app/index/')
