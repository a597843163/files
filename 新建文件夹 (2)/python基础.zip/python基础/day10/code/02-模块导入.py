
# 模块： 一个py文件就是一个模块，模块名称遵守命名规范（英文）
# 标准模块，第三方模块, 自定义模块

# 导入模块
# import 模块
# 可以同时导入多个模块， 也可以导入多次（最终也只会导入一次）
import time, os
import os
import time

# import 模块1,模块2,...
# 一般把模块的导入放在文件开头

# 调用模块
# 模块名.函数()  或 模块名.变量
time.time()



# 导入模块2: 其实是把文件module2.py执行了
import module2

# 调用模块2中的函数或变量
module2.login()
module2.register()
print(module2.username)
print(module2.password)

# login() # 报错





