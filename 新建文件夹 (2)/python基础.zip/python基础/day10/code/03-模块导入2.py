

# 模糊导入
# * 表示通配符，不推荐
# from module2 import *
# 这种方式导入后， 调用方式和下面一样

# 精确导入
# from module2 import login
from module2 import login, username


# 调用
# 调用方式: 函数名() 或 变量
login()
# module2.login()  # 报错
# register()  # 报错， 没有导入
print(username)
# print(password)  # 报错


from random import randrange
print(randrange(1, 100))


# 别名
# 给模块起别名
import random as rd
print(rd.random())
# print(random.random()) # 报错 原来的名字不能使用

# 给函数起别名
from random import randrange as rr
print(rr(1, 10))
print(randrange(1, 10))



