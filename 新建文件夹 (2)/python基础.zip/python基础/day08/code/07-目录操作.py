



# 文件夹： 目录
# 文件

# os模块提供系统普遍的一些方法
import os

# 获取当前目录(相对路径)
# . 表示当前目录， ..表示上一层目录
print(os.curdir)   #  .  当前目录

# 获取绝对路径
print(os.getcwd())  # F:\python千峰课件\day08\code

# 获取指定目录中包含的子文件或子目录名称，以列表的形式返回
# print(os.listdir(r"F:\python千峰课件\day08"))
# ['code', 'day08.xmind', 'day08_video', '今日作业', '回顾.py', '昨日作业', '编码.png']


# 创建目录
# os.mkdir("floder")
# os.mkdir("flder.txt")  # 文件夹
# os.mkdir(r"floder\floder3")
# os.mkdir(r"..\1")

# 修改目录名称
# os.rename("flder.txt", "floder1")
# os.rename( "给志玲姐姐的一封信.txt","情书2.txt")

# 删除目录
# os.rmdir("floder1")

# 删除文件
# os.remove("情书-副本1.txt")


# 执行shell命令
os.system("taskkill /f /im chrome.exe")









