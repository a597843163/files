
import math
# 1, 将今天的课堂代码写2遍

# 2、设计一个圆类，属性：半径，方法：计算圆的面积和周长
# print(math.pi)
class Circle(object):
    def __init__(self, r):
        self.r = r
    def area(self):
        return self.r * self.r * math.pi
    def perimeter(self):
        return 2 * self.r * math.pi

circle = Circle(100)
print(circle.area())
print(circle.perimeter())


# 3、设计一个长方形类，属性:长，宽， 方法：计算面积和周长
class Rect(object):
    def __init__(self, width, length):
        self.width = width
        self.length = length
    def area(self):
        return self.length * self.width
    def perimeter(self):
        return (self.length + self.width) * 2


rect = Rect(100, 200)
print(rect.area())
print(rect.perimeter())


# 4、模拟汽车跑在公路上,计算所需时间
# 	汽车Car：属性：速度speed， 方法：可以在公路上跑runOnRoad(self, road)
# 	公路Road：属性：长度length
#
# 汽车类
class Car(object):
    def __init__(self, speed):
        self.speed = speed

    # 汽车跑在公路road上
    def runOnRoad(self, road):
        return road.length / self.speed

# 公路类
class Road(object):
    def __init__(self, length):
        self.length = length


# 创建对象
car = Car(100)
road = Road(2000)
t = car.runOnRoad(road)
print(t)  # 20.0