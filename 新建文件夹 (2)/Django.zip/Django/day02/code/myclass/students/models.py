from django.db import models
from grades.models import Grade


class Student(models.Model):
    # 属性
    name = models.CharField(max_length=20)
    gender = models.BooleanField(default=True)
    age = models.IntegerField()
    info = models.CharField(max_length=40)
    is_delete = models.BooleanField(default=False)
    # 外键
    grade = models.ForeignKey(Grade)

    def __str__(self):
        return self.name

