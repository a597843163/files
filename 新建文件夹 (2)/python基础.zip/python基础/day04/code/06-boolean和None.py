


# boolean 布尔类型
#      两个值： True表示真， False表示假
#
if True:
    print("True")

print(int(True))  # 1
print(int(False))  # 0

# 假： 0, "", None, []
# 真： 除了假的就是真的


# None : 空  , 特殊类型，只有一个值：None(特殊值)，
#       一般不直接使用，作为判断是否是None，如果是就不能进行后面的操作
print(None)  # None

num1 = 0
n = None
print(num1 + 1)
# print(n + 1)  # 报错
print(type(n))  # <class 'NoneType'>
















