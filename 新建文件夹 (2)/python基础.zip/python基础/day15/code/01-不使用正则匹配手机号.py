

#
# 手机号
#   123456  不是
#   12345678901 不是
#   19911112222
# 规则：长度11位, 每位都是数字
#       第1位是1
#       第2位是3,4,5,7,8,9
#       第3位是0-9
#       后8位是0-9


def fn(phone):
    if len(phone) != 11:
        return False
    for i in range(len(phone)):
        if i == 0 and phone[i] != '1':
            return False
        if i == 1 and phone[i] not in ['3','4','5','7','8','9']:
            return False
        if not (phone[i] >= '0' and phone[i] <= '9'):
            return False

    return True

print(fn("13911112222"))






