from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
# 实例化的文件




db = SQLAlchemy()
migrate = Migrate(db=db)

# 实例化的函数
def config_extensions(app):
    db.init_app(app)
    migrate.init_app(app)