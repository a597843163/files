from flask import Flask
from flask_script import Manager
from app import create_app
from flask_migrate import MigrateCommand

# 获取在app__init__.py 中创建的flask对象
app = create_app('default')
manager = Manager(app)

# 添加迁移命令
manager.add_command('db',MigrateCommand)

if __name__ == '__main__':
    manager.run()


