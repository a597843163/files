from flask import Blueprint, render_template, request, redirect, url_for, current_app
from app.models import Posts,User
from app.forms import PostsForm
# from app.extensions import cache
main = Blueprint('main',__name__)
#定制首页
@main.route('/')
def index():
    return redirect(url_for('main.show',page=1))

# @cache.cached(timeout=3600) # timeout 为过期时间
@main.route('/show/<int:page>')
# @cache.memoize(timeout=3600,key_prefix='index') #添加缓存的装饰器  timeout 为 过期时间 此缓存是可以通过传递 不同的参数 进行缓存
def show(page):
    print('我是缓存的视图函数-------------')
    # 分页对象
    pagination = Posts.query.filter(Posts.pid == 0).order_by(Posts.timestamp.desc()).paginate(page, current_app.config[
        'PAGE_NUM'], False)
    # 获取当前页面的所有数据
    data = pagination.items
    return render_template('main/index.html', data=data, pagination=pagination,def_name='main.show')

