from  selenium import webdriver
import time

from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome(executable_path=r'C:\Program Files\Python36\chromedriver.exe')

driver.get('https://www.baidu.com/')

time.sleep(2)
# 获取百度输入框
driver.find_element_by_id('kw').send_keys('美女')

send_keys_list = [
    Keys.BACK_SPACE,  # 删除键
    Keys.SPACE,  # 空格键
    Keys.TAB,  # 制表键
    Keys.ESCAPE,  # 回退键
    Keys.ENTER,  # 回车键
    Keys.CONTROL + 'a',  # 全选
    Keys.CONTROL + 'c',  # 复制
    Keys.CONTROL + 'x',  # 剪切
    Keys.CONTROL + 'v',  # 粘贴
    Keys.F1,            # F1
]

# 键盘操作
# for key in send_keys_list:
#     time.sleep(5)
#     driver.find_element_by_id('kw').send_keys(key)
#     time.sleep(3)
#     driver.find_element_by_id('kw').send_keys('美女')

# time.sleep(2)
# # 点击百度一下
# driver.find_element_by_id('su').click()
#
# time.sleep(2)
# # 后退
# driver.back()
#
# time.sleep(2)
#
# driver.forward()
#
# time.sleep(3)
# driver.quit()
