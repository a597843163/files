from .config import Config
from .extensions import config_extensions
from flask import Flask
from .views import config_blueprint


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)  # 导入配置
    config_extensions(app)  #第三方扩展库实例化
    config_blueprint(app)  # 蓝图注册
    return app

# from flask import Flask
# from app.config import Config
# from app.extensions import config_extensions
# from app.views import config_blueprint
#
#
# def create_app(CONFIG_NAME):
#     app = Flask(__name__)
#     app.config.from_object(Config)  # 从外部导入配置，为app初始化配置测试环境
#     config_extensions(app)   # 第三方扩展库的实例化
#     config_blueprint(app)   # 蓝本视图的注册
#     return app
#



