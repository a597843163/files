from flask import Blueprint,render_template,request
from app.models import Posts,User
from app.forms import PostsForm
main = Blueprint('main',__name__)
#定制首页
@main.route('/')
def index():
    page = int(request.args.get('page',1))
    #分页对象
    pagination = Posts.query.filter(Posts.pid==0).order_by(Posts.timestamp.desc()).paginate(page,5,False)
    #获取当前页面的所有数据
    data = pagination.items
    return render_template('main/index.html',data=data,pagination=pagination,def_name='main.index')

