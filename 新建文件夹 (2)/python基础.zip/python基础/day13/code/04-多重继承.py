

# 多重继承

# 父类
# Ipod
class Ipod(object):
    def __init__(self, color):
        self.color = color
    def listenMusic(self):
        print("听音乐")
    def playLOL(self):
        print("玩LOL")

# 子类
# Ipad:
#   属性： color, size
#   方法： 听音乐, 看电影
class Ipad(Ipod):
    def __init__(self, color, size):
        super().__init__(color)
        self.size = size
    def watchMoive(self):
        print("看电影")


# 孙子类
# Iphone
class Iphone(Ipad):
    def __init__(self, color, size, price):
        super().__init__(color, size)
        self.price = price
    def call(self):
        print("打电话")


#
iphone8 = Iphone("亮黑色", 4.7, 5000)
print(iphone8.color, iphone8.size, iphone8.price)
iphone8.listenMusic()
iphone8.watchMoive()
iphone8.call()
iphone8.playLOL()



# 继承： 可以复用代码， 利于后期维护   




