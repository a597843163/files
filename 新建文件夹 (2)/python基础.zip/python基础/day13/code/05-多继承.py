


# 单继承： 只继承一个父类
# 多继承： 可以同时继承多个父类

# 父亲： 姓名，年龄 ； 赚钱
# 母亲： 性别，颜值 ； 购物
# 儿子： 姓名，年龄， 性别，颜值, 女朋友； 赚钱，购物, 泡妞

# 父类1
class Father(object):
    def __init__(self, name, age):
        self.name = name
        self.age = age
        print("Father-init")

    def makeMoney(self):
        print("可以赚钱")

# 父类2
class Mother(object):
    def __init__(self, sex, faceValue):
        self.sex = sex
        self.faceValue = faceValue
        print("Mother-init")

    def shopping(self):
        print("会购物")

# 子类
# Son 依次继承 Father和Mother
class Son(Father, Mother):
    def __init__(self, name, age, sex, faceValue, girlFriend):
        # super(Son, self).__init__(name, age)  # 继承Father
        # super(Father, self).__init__(sex, faceValue)  # 继承Mother

        Father.__init__(self, name, age)  # 继承Father
        Mother.__init__(self, sex, faceValue)  # 继承Mother

        self.girlFriend = girlFriend

    def chasingGirl(self):
        print("泡妞")

# 多继承： 按照继承父类的顺序依次去继承，内部有mro算法


# 创建对象
son = Son("周杰伦", 39, "男", 100, "昆凌")
print(son.name, son.age, son.sex, son.faceValue, son.girlFriend)
son.makeMoney()
son.shopping()
son.chasingGirl()

