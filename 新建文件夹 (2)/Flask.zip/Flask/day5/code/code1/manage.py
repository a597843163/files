from flask import Flask
from flask_script import Manager
from flask_mail import Mail,Message
import os

app = Flask(__name__)
# smtp为发送邮件协议+邮箱后缀
app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER','smtp.163.com')
# username 为用户名
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME','a5978431633@163.com')
# password 为授权码
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD','a123456')

mail = Mail(app)
manager = Manager(app)

@app.route('/')
def index():
    # 1.主题   2.发送给谁 3.谁发送的
    msg = Message(subject='学校通知下午不上课',recipients=['597843163@qq.com'],sender=app.config['MAIL_USERNAME'])
    # 4.设置发送内容
    msg.html = '<h1>今天是一个号节日 愚人节</h1>'
    # 5. 操作发送
    mail.send(message=msg)
    return '邮件发送'

if __name__ == '__main__':
    manager.run()