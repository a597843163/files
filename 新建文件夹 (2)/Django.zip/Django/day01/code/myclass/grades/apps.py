from django.apps import AppConfig


class GradesConfig(AppConfig):
    name = 'grades'
