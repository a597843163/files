
# 导入socket模块
import socket

# TCP协议： 基于socket

# TCP服务端

# 1，先创建服务端socket
# 2, 绑定ip和端口
# 3，设置最大监听数（最大连接数）
# 4, 等待客户端来连接

# 5，接收客户端的数据，给客户端发送数据


# 1，先创建服务端socket
# AF_INET: ipv4, AP_INET6: ipv6
# SOCK_STREAM : 数据流， 表示使用TCP协议
# SOCK_DGRAM: 报文, 表示使用UDP协议
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 2, 绑定ip和端口
# ip地址 表示 哪台计算机
# port端口号 表示 该计算机的哪个程序
serverSocket.bind(("10.36.137.101", 8888))

# 3，设置最大监听数（最大连接数）
serverSocket.listen(5)

print("服务器端已经启动了!")

# 4, 等待客户端来连接
# accept() : 等待接收客户端来连接， 会阻塞线程
clientSocket, address = serverSocket.accept()
# print(clientSocket)  # 客户端的socket对象
# print(address)  # 客户端的地址（ip和端口）
# 此时已经完成三次握手了

# 5，接收客户端的数据，给客户端发送数据
while True:
    print("可以接收客户端的数据了")

    # 接收客户端发过来的数据
    recvData = clientSocket.recv(1024)
    print("客户端说：", recvData.decode("utf-8"))

    # 发送数据给客户端
    sendData = input("我说：")
    clientSocket.send(sendData.encode("utf-8"))

# 关闭连接
clientSocket.close()






