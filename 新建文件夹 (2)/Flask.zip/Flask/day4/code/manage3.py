from flask import Flask,render_template,request,flash,get_flashed_messages
from flask_script import Manager
from flask_bootstrap import Bootstrap
from flask_uploads import UploadSet,IMAGES,configure_uploads,patch_request_class
import string, random,os
from flask_wtf import FlaskForm
from flask_wtf.file import FileField,FileRequired,FileAllowed  # 文件的验证器
from wtforms import SubmitField

from PIL import Image #导入图片处理模块
app = Flask(__name__)
bootstrap = Bootstrap(app)
# 配置上传文件路径以及大小限制和加密csrf
app.config['MAX_CONTENT_LENGTH'] = 1024*1024*64
app.config['UPLOADED_PHOTOS_DEST'] = os.getcwd()+'/static/upload'
app.config['SECRET_KEY'] = 'abcdef'   # 当有bootstrap快速渲染时form表单method为post需要配置加密方式
# 实例化对象
file = UploadSet('photos',IMAGES)
# 把app设置的config导入到file中
configure_uploads(app,file)
patch_request_class(app,size=None) #设置size=None则可自定义设置大小，将第三方上传大小设置为 app.config['MAX_CONTENT_LENGTH']的大小
# patch_request_class(app) #将第三方上传大小设置为 patch_request_class函数自定义的大小
manager = Manager(app)

# 为快速设置表单创建类
class fileUpload(FlaskForm):
    file = FileField('头像上传',validators=[FileRequired(message='您还没有选择文件'),FileAllowed(file,message='只允许上传图片')])
    submit = SubmitField('开始上传')

# 为图片生成随机名字，参数1为图片的后缀
def randomName(shuffix,length=32):
    myStr = string.ascii_letters+'0123456789'
    # print(myStr)
    newName = ''.join(random.choices(myStr,k=length))+shuffix
    return newName

@app.route('/upload/',methods=['GET','POST'])
def upload():
    form = fileUpload()
    img_url = None
    if form.validate_on_submit():
        print('请求过来了')
        # 1. 获取文件名字 并拿到文件扩展名
        # form.file.data是表单提交过来的文件   加上.filename则是文件的名字
        shuffix = os.path.splitext(form.file.data.filename)[-1]
        #2. 生成文件的随机名称
        newName = randomName(shuffix)
        #3. 保存上传文件   file.save要传入的是文件  ,保存的名字为新生成的名字
        # file.save(app.config['UPLOADED_PHOTOS_DEST'],newName)
        file.save(form.file.data,name=newName)
        #4. 生成文件缩略图
        # 打开的是原始文件(路径)
        img = Image.open(os.path.join(app.config['UPLOADED_PHOTOS_DEST'],newName))
        # 设置缩略图大小
        img.thumbnail((300,300))
        img.save(os.path.join(app.config['UPLOADED_PHOTOS_DEST'],'s_'+newName))
        #5. 获取图片url 传递并显示
        img_url = file.url(newName)
    return render_template('wtform.html',form=form,img_url=img_url)

if __name__ == '__main__':
    manager.run()


"""
取值表单
form.字段.data
request.form.get('字段名')
#表单有个问题   当上传文件的大小超出了 你给定的大小 请求失败  自己解决
"""


