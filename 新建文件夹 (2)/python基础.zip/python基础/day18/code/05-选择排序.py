



# 选择排序

'''
    升序
            [8, 9, 7, 6, 4, 5, 2, 1, 3]
    第一趟   [1,   9, 8, 7, 6, 5, 4, 2, 3]  i=0
    第二趟   [1, 2,   9, 8, 7, 6, 5, 4, 3]  i=1
    第三趟   [1, 2, 3,   9, 8, 7, 6, 5, 4]  i=2
    第四趟   [1, 2, 3, 4,   9, 8, 7, 6, 5]  i=3
    第五趟   [1, 2, 3, 4, 5,   9, 8, 7, 6]  i=4
    第六趟   [1, 2, 3, 4, 5, 6,   9, 8, 7]  i=5
    第七趟   [1, 2, 3, 4, 5, 6, 7,   9, 8]  i=6
    第八趟   [1, 2, 3, 4, 5, 6, 7, 8,   9]  i=7

'''

list = [8, 9, 7, 6, 4, 5, 2, 1, 3]

for i in range(len(list)-1):  # 趟数
    for j in range(i+1, len(list)):  # 遍历每一趟剩下后面的数（除了剩下数中的第一个）
        if list[i] > list[j]:
            list[i], list[j] = list[j], list[i]
print(list)


list = [8, 9, 7, 6, 4, 5, 2, 1, 3]
for i in range(len(list)-1):  # 趟数
    index = i  # index表示最小数的下标
    for j in range(i+1, len(list)):  # 遍历每一趟剩下后面的数（除了剩下数中的第一个）
        if list[j] < list[index]:
            index = j
    list[index], list[i] = list[i], list[index]

print(list)







