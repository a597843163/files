

'''
    数据类型：
        number: 数字类型，整数int,浮点数float(小数)
        string: 字符串类型，如："宝强"
        boolean : 布尔类型，只有两个值：True, False
        tuple: 元组
        list: 列表
        None: 空值
        dict: 字典
        set: 集合

        byte: 字节
'''

# type() : 用来获取变量的数据类型

# number
# 把数字10赋值给变量num
num = 10
print(num)
print(type(num))  # <class 'int'>

# string
str = "宝强"
print(type(str))  # <class 'str'>

# boolean
b = True
print(type(b))  # <class 'bool'>

# tuple
t = (1, 2, 3, 4)
print(type(t))  # <class 'tuple'>

# list
l = [1,2,3,4]
print(type(l))  # <class 'list'>

# None
n = None
print(type(n))  # <class 'NoneType'>

# dict
d = {"name": "贾乃亮", "age": 33}
print(type(d))  # <class 'dict'>

# set
s = {"贾乃亮", "宝强", "马蓉"}
print(type(s))  # <class 'set'>


# byte
b = b'12fg'
print(type(b))  # <class 'bytes'>
