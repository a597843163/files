

# 值类型的传递
def fn1(n):
    n += 1
    print("n =", n)  # 11

n = 10
fn1(n)
print("n =", n)  # 10


# 引用类型传值
#list
def fn2(list1):
    list1[0] = 5
    print("list1 =", list1)  # list1 = [5, 2, 0]

list2 = [1, 2, 0]
fn2(list2)
# fn2(list2.copy())
print("list2 =", list2)  # list2 = [5, 2, 0]


