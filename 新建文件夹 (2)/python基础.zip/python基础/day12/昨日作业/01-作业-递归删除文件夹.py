''''''

# 递归删除文件夹(可能包含子文件或子文件夹)
# 提示：要先将文件夹中的所有子文件删除再删除本文件夹
# remove()
# rmdir()

import os

def delDir(dirPath):

    if not os.path.exists(dirPath):
        return "目录不存在"

    # 遍历子目录，并删除
    fileNameList = os.listdir(dirPath)
    for fileName in fileNameList:
        absPath = os.path.join(dirPath, fileName)

        if os.path.isfile(absPath):  # 文件
            os.remove(absPath)
        elif os.path.isdir(absPath):  # 目录
            delDir(absPath)  # 递归

    # 删除当前目录
    os.rmdir(dirPath)

if __name__ == "__main__":
    path = r"C:\wamp\www\day12\昨日作业\newdir"
    delDir(path)




