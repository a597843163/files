

'''
    返回值： return
        1, 如果不写return，默认返回None
        2， 只写return，不写返回值，立刻终止函数（退出函数）
        3， 写return 值， 立刻终止函数，并返回值
'''

# 函数的定义
def sum(a, b):
    s = a + b
    print("return之前的语句")
    return s  # 将s的值返回
    print("return之后的语句")

    # for i in range(5):
    #     if i == 2:
    #         return 2  # 终止函数，循环也会立刻终止
    #     print("i =", i)

# 函数调用
# print( sum(1, 2) )
res = sum(3, 4)  # res 等于 sum函数调用完成后的return值
print(res)

# continue: 用于循环， 用来终止当次循环，继续下一次循环
# break: 用于循环，用来终止循环
# return: 用于函数, 用来终止函数，且可以返回值

# res = list.pop(2)


# return多个值
def fn(a, b):
    return a*a, b*b

res = fn(2, 3)
print(res)  # (4, 9)
print(type(res))  # <class 'tuple'>

m, n = fn(5, 6)
print(m, n)  # 25 36



# 参数类型检测: isinstance()
def fn2(n):
    if isinstance(n, (int)):
        print(n, "是int")
    if isinstance(n, (int, str, bool, list, dict)):
        print(n, "是int, str, bool, list, dict其中的一种")

fn2([1,2])


