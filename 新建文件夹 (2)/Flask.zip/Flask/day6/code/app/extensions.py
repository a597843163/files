# 导入模块
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate


bootstrap = Bootstrap()
db = SQLAlchemy()
migrate = Migrate(db=db)

# 创建一个 统一管理第三方模块初始化的函数
def config_extensions(app):
    bootstrap.init_app(app)
    db.init_app(app)
    migrate.init_app(app)
