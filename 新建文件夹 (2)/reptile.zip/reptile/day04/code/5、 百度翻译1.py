import urllib.request
import urllib.parse


url = 'http://fanyi.baidu.com/sug'

word = input('请输入您要查找的英文单词：')
# 构造post请求的data。,只要post请求的参数，要urlencode后再encode
data = {
    'kw': word,
}

data = urllib.parse.urlencode(data).encode('utf-8')

response = urllib.request.urlopen(url=url, data=data)

print(response.read().decode('utf-8'))