

# 1.简述普通参数、关键字参数、默认参数、可变长参数的区别
# 普通参数： 使用最多，参数数量要一致，需要按照顺序传参
# 关键字参数： 可以根据形参名传值，不需要按照顺序传参
# 默认参数：形参有默认值，可以不对默认参数传值，如果传递了值给默认参数，则会优先使用传递过去的值
# 可变长参数: *args: 可以接受不定长度的参数序列（元组），一般使用在参数数量不固定的情况下
#           **kwargs: 可以接受不定长的参数序列（字典），一般使用在参数数量不固定的情况下


# 2.写函数，计算传入字符串中单个【数字】、【字母】、【空格] 以及 【其他】的个数
def myCount(str1):
    count1 = 0  #数字个数
    count2 = 0  #字母个数
    count3 = 0  #空格个数
    count4 = 0  #其他字符的个数
    for i in str1:
        if i>='0' and i<='9':
            count1 += 1
        elif i>='A' and i<='Z' or i>='a' and i<='z':
            count2 += 1
        elif i == ' ':
            count3 += 1
        else:
            count4 += 1
    print(count1, count2, count3, count4)
myCount("hello123 5&^&")


# 3.写函数，判断用户传入的参数（字符串、列表、元组）长度是否大于5
def fn1(args):
    if len(args) > 5:
        return True
    return False
print(fn1("ddddd"))
print(fn1([1,2,3,4,5,6]))
print(fn1((1,2,3,4,5,6)))


# 4.写函数，检查用户传入的对象（字符串、列表、元组）的每一个元素是否含有空内容。
def fn2(args):
    for i in args:
        if i=="" or i==" " or i==None:
            return True

    return False

print(fn2([1,"", 2, 3]))


# 5.写一个函数，识别字符串是否符合python语法的变量名
# 数字，字母， 下划线， 不能以数字开头数字
import keyword
# print(keyword.kwlist)

def fn3(str1):
    if str1 in keyword.kwlist:
        return False

    if str1[0]>='0' and str1[0]<='9':
        return False

    for i in str1:
        if (i>='0' and i<='9') or (i>='a' and i<='z') or (i>='A' and i<='Z') or i=="_":
            pass
        else:
            return False

    return True

print(fn3("f_34fdf_"))


# 6.定义一个函数，输入不定个数的数字，返回所有数字的和
def mySum(*args):
    sum = 0
    for i in args:
        sum += i
    return sum
print(mySum(1,2,3,4))


# 7, 写一个函数计算1到n的和, 并返回结果打印出来;(n为函数参数)
def mySum2(n):
    sum = 0
    for i in range(1, n+1):
        sum += i
    return sum
print(mySum2(4))


# 8, 写一个函数计算n的阶乘,并返回结果打印出来
def fn4(n):
    s = 1
    for i in range(1, n+1):
        s *= i
    return s
print(fn4(4))


# 9, 写一个函数计算两个数的最小公倍数; 并返回结果打印出来
# 9,6 最小公倍数是：18
def fn5(m, n):
    max1 = max(m, n)
    for i in range(max1, m*n + 1):
        if i%m==0 and i%n==0:
            return i
print(fn5(9, 6))


# 10, 写一个函数判断一个年份是不是闰年
def fn6(year):
    if year%4==0 and year%100!=0  or year%400==0:
        return True
    return False
print(fn6(2018))


# 11, 写一个函数判断一个数是不是素数 (又称质数,除了1和本身以外不再有其他数整除)
def fn7(n):
    for i in range(2, n):
        if n%i == 0:
            return False
    return True
print(fn7(33))


# 12, 年月日分别为自定义函数的参数，判断某一个日期是否为合法的日期;
# 	    如: 2018年12月33日不是合法的日期
# 	        2018年11月13日是合法的日期

def fn8(year, month, day):

    # 判断year
    if year < 0:
        return False

    # 判断month
    if month<1 or month>12:
        return False

    # 判断day
    days = 31  # 默认当前月份的总天数是31
    if month == 2:
        if fn6(year):  # 是闰年
            days = 29
        else:   # 平年
            days = 28
    elif month==4 or month==6 or month==9 or month==11:
        days = 30

    if day<=0 or day>days:
        return False

    return True

print(fn8(2016, 2, 30))

