$(function () {

    // 顶部轮播
    initTopSwiper();

    // 必购商品轮播
    initMustbuySwiper();

});


// 顶部轮播
function initTopSwiper() {
    new Swiper('#topSwiper', {
        loop: true,
        pagination: '.swiper-pagination'
    });
}

// 必购商品轮播
function initMustbuySwiper() {
    new Swiper('#swiperMenu', {
        slidesPerView: 3
    });
}

