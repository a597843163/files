from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

# MTV
# M（数据）:Model模型 ,models.py 中写
# T(界面): Template模板，html+模板语法
# V（逻辑）:View ，在views.py中写逻辑处理代码，一般写的是函数

# 控制器

# 定义视图函数
def index(request):
    return HttpResponse("hello django")