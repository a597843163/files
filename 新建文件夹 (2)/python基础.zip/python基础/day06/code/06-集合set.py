
'''
    集合set: 和字典dict类似，但是只保存key，不保存值value
            无序，不存在相同的数据

'''


# 创建set
set1 = set()
print(set1)  # set()
print(type(set1))  # <class 'set'>

# set1 = {1: 2}
set1 = {1, 2}
print(set1)  # {1, 2}
print(type(set1))  # <class 'set'>

# 无序，数据唯一
set1 = {11, 22, 22, 11, 33}
print(set1)  # {33, 11, 22}


# 创建set集合时，可以将列表list，元组tuple，字典dict，字符串string转换成集合
# list
list1 = [4, 5, 6]
set1 = set(list1)
print(set1)  # {4, 5, 6}
print(type(set1))  # <class 'set'>

list2 = list(set1)
print(list2)  # [4, 5, 6]
print(type(list2))  # <class 'list'>

# 9, 列表去重, 将下面的列表中重复的元素去除
#   list1 = [1,2,3,5,4,4,4,5,5,3,2,1]
list1 = [1,2,3,5,4,4,4,5,5,3,2,1]
print(list(set(list1)))  # [1, 2, 3, 4, 5]


# tuple
tuple1 = (1, 2, 3)
set2 = set(tuple1)
print(set2)  # {1, 2, 3}

print(tuple(set2))  # (1, 2, 3)


# dict: 会取出字典的key
dict1 = {"a": 11, "b": 22, "c": 33}
set2 = set(dict1)
print(set2)  # {'a', 'c', 'b'}
# print(dict(set2))  #报错


# string
str1 = "hola"
set2 = set(str1)
print(set2)  # {'o', 'l', 'h', 'a'}

str2 = str(set2)
print(str2)  # "{'a', 'o', 'l', 'h'}"
print(type(str2))  # <class 'str'>

#int()
#float()
#str()
#tuple()
#list()
#set()




# set集合的操作
set1 = {11, 22, 33, 44}

# 查
print(len(set1))  # 4

for i in set1:
    print(i)  # 值

for i, n in enumerate(set1):
    print(i, n)  # 下标， 值


# 增
# add() ： 添加一个元素
set1.add(55)
print(set1)  # {33, 11, 44, 22, 55}

# update() : 添加多个元素
set1.update([66, 77])
# set1.update((66, 77))
# set1.update("hello")  # 把字符串中的每个字符拆分开再加入
print(set1)  # {33, 66, 11, 44, 77, 22, 55}


# 删除
# pop() : 随机删除一个
set1 = {11, 22, 33, 44}
set1.pop()
print(set1)  #{11, 44, 22}

# remove() : 删除指定的元素, 如果要删除的元素不存在，则会报错
set1 = {11, 22, 33, 44}
set1.remove(33)
# set1.remove(55)  # 报错
print(set1)  # {11, 44, 22}

# discard(): 删除指定的元素，如果不存在也不会报错
set1.discard(100)
print(set1)  # {11, 44, 22}


# clear() : 清空集合
set1.clear()
print(set1)  # set()


# 集合
set1 = {11, 22, 33, 44}
set2 = {33, 44, 55, 66}

# 包含
print(set1 >= set2)  # True, 表示set1包含了set2中所有的元素
print(set1 <= set2)  # False, 表示set2不包含set1中所有的元素
 
# 交集
print(set1 & set2)  # {33, 44}

# 并集
print(set1 | set2)  # {66, 11, 22, 33, 44, 55}

# 差集
print(set1 - set2)  # {11, 22}

# 对称差集
print(set1 ^ set2)  # {66, 11, 22, 55}







