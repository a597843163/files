

from urllib import request

# 参数1： 需要下载的url
# 参数2： 需要写入的文件路径
request.urlretrieve("http://www.baidu.com", r"html/baidu2.html")
request.urlcleanup()  # 清除缓存


# 下载图片
request.urlretrieve("https://www.baidu.com/img/bd_logo1.png", r"img/baidu.png")
request.urlcleanup()  # 清除缓存








