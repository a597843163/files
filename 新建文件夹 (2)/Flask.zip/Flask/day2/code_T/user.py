from flask import Blueprint,redirect,url_for,request,abort

#实例化蓝本
# Blueprint('user',__name__) 中的user为当前蓝本的名称 在跳转的时候 需要指定是哪个蓝本的视图函数或者路由 那么当前的user就是起到这样的作用
user = Blueprint('user',__name__)


@user.route('/login/')
def login():
    return '登录处理'

@user.route('/register/')
def register():
    # return '注册处理'
    return redirect("/test/") #跳转到manage.py的test路由

@user.before_app_request
def before_request():
    if request.method == 'GET' and request.path == '/form/':
        abort(404)
    print(request.path)
    # print('before_request')