

'''
    list列表： 可以一次存储多个值
        list1 = [1,2,3]

    车的品牌：
        car1 = "Benz"
        car2 = "BMW"
        car3 = "volvo"
        ...
    如果有30个品牌要存储

    使用列表list：可以使用一个变量同时存多个值

'''

# 创建列表
# 元素：列表中的每个值就叫元素
list1 = [1, 2, 3]
print(list1)
print(type(list1))   # <class 'list'>

# 可以存放不同类型的数据
list2 = [1, "奥巴马", True]
print(list2)  # [1, '奥巴马', True]

# C语言 ： 强类型
# Python语言 ：弱类型



# 获取列表中的元素
list1 = ["金刚狼", "美国队长", "绿巨人", "钢铁侠"]
# 乔布斯：创建了苹果公司，iphone， 库克
# 马斯克：xSpace, 特斯拉，超级高铁1200km/h, 发射12000颗互联网卫星，去火星
# 陌陌，探探， 快播（王欣）

print(list1[0])  #"金刚狼"
print(list1[1])  #"美国队长"
print(list1[2])  #"绿巨人"
print(list1[3])  #"钢铁侠"
# print(list1[4])  # 报错，列表的下标越界
print(list1[-1])  #"钢铁侠", 表示倒数第1个

# len() : 获取列表的长度（列表中元素的个数）
print(len(list1))  # 4

# 最后一个元素
print(list1[len(list1)-1])


# 遍历列表，使用while
list1 = ["金刚狼", "美国队长", "绿巨人", "钢铁侠"]
i = 0
while i < len(list1):
    # print(i)  # 0,1,2,3
    print(list1[i])
    i += 1


# --  求平均年龄
ages = [20,30,40,10,50]
sum = 0
i = 0
while i < len(ages):
    sum += ages[i]
    i += 1
avgAge = sum/len(ages)
print("平均年龄：", avgAge)  # 平均年龄： 30.0

# 注意：只要用到列表list， 就要想到使用下标




# 列表的常用操作
#  + : 拼接列表
list1 = [1, 2, 3]
list2 = [4, 5, 6]
list3 = list1 + list2
print(list3)  # [1, 2, 3, 4, 5, 6]

# * : 重复
list4 = list1 * 3
print(list4)  # [1, 2, 3, 1, 2, 3, 1, 2, 3]

# in : 判断某元素是否在列表中
if 2 in list1:
    print("2 在列表list1中")  # 2 在列表list1中


# [:] : 截取列表
list5 = [1, 2, 3, 4, 5, 6, 7, 8]
print(list5[:])  # [1, 2, 3, 4, 5, 6, 7, 8]
print(list5[3:])  # [4, 5, 6, 7, 8]
print(list5[:4])  # [1, 2, 3, 4], （不包括下标4）
print(list5[2:5])  # [3, 4, 5]
print(list5[::2])  # [1, 3, 5, 7], 2表示步长
print(list5[::-1])  # [8, 7, 6, 5, 4, 3, 2, 1], 逆序


# 一维列表
list5 = [1, 2, 3, 4, 5, 6, 7, 8]

# 二维列表
list5 = [[1,2,3], [4,5,6], [7,8,9]]
print(list5[0][0])  # 1

# 星际穿越： 时间

# 循环嵌套来遍历
i = 0
while i < len(list5):

    # 里面的每个小列表
    list6 = list5[i]
    j = 0
    while j < len(list6):
        print(list6[j], end=" ")
        j += 1
    print()

    i += 1






