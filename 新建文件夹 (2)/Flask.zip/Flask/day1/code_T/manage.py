from flask import Flask,make_response,redirect,url_for,abort,current_app,request,session
import time
# 创建flask的应用
app = Flask(__name__)
app.secret_key = 'abcdef'

app.var = '我给app添加了一个对象属性'
#路由
@app.route('/')  #在请求当前路由的时候  如果当前路由需要/的时候 浏览器会自动将它补全
def index():
    print('<h1>Hello World</h1>')
    return 'FLask' #必须有相应给浏览器

@app.route('/test/') #路由地址和视图函数 是否同名都没关系
def test():
    # return redirect('/')
    # return redirect('/welcome/lisi') #带参的重定向
    #知道函数名 怎样反向构造出路由？
    # print(url_for('index'))
    # print(url_for('argtype',uid='abc'))
    # return redirect(url_for('argtype',uid='abc'))
    # print('上面代码正常执行')
    # abort(404) #当使用了abort  后面的代码不会再执行
    # abort(500) #当使用了abort  后面的代码不会再执行
    print(current_app.var) #可以拿到app的所有的配置信息  相当于app的一个分身
    return '这是一个测试的视图函数'


@app.errorhandler(404)
def serverError(e): #接收flask传递给我当前的错误信息
    # return '<h1>Not Found</h1>The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again'
    return e

#带参路由   http://127.0.0.1:5001/welcome/lisi
@app.route('/welcome/<name>')
def welcome(name):
    print(type(name)) #接收的参数 name都为字符串类型
    return '欢迎{}'.format(name)



#指定参数类型
#int
# @app.route('/argtype/<int:uid>')
# @app.route('/argtype/<float:uid>')
@app.route('/argtype/<path:uid>')
def argtype(uid):
    print(type(uid))
    print(uid)
    return '参数类型'



#这是多个参数的路由
# @app.route('/manyarg/<a>_<b>')
@app.route('/manyarg/<a>/<b>')
def manyarg(a,b):
    print(a,b)
    return '接收多个参数'


@app.route('/res/')
def res():
    # return 'page not found',404 #可以指定返回请求的状态码
    # response = make_response('通过make_response进行的响应')
    response = make_response('通过make_response进行的响应',404)
    print(response)
    return response




@app.route('/request/')
def req():
    #http://127.0.0.1:5001/request/?name=lisi&age=18
    print('请求的完整url',request.url)
    print('去掉get传参的路由',request.base_url)
    print(' 获取只有主机IP和端口号的url',request.host_url)
    print(' 获取路由地址',request.path)
    print(' 获取请求方法',request.method)
    print(' 获取通过get传递过来的参数',request.args)
    print(' 获取通过get传递过来的参数',request.args['name'])
    print(' 用于文件上传',request.files)
    print(' 获取请求过来的头信息',request.headers['User-Agent'])
    return 'request对象的使用'

@app.route('/getarg/')
def getarg():
    print('name的值为:',request.args.get('name'))
    print('age的值为',request.args.get('age','你是不是傻？有age吗'))
    print('age的值为',request.args.getlist('name'))
    return '获取get传参'

#设置cookie的路由
@app.route('/set_cookie/')
def set_cookie():
    response = make_response('设置cookie') #创建response对象
    response.set_cookie('name','zhangsan') #设置cookie 过期为 当前会话结束（关闭浏览器就清除）
    # 一小时后过期
    expires = time.time()+3600
    response.set_cookie('name','zhangsan',expires=expires)
    response.set_cookie('age','18',max_age=3600) #
    return response

@app.route('/get_cookie/')
def get_cookie():
    # return request.cookies.get('name','没有值')
    return request.cookies.get('age','没有值')


@app.route('/del_cookie/')
def del_cookie():
    response = make_response('删除cookie')
    response.delete_cookie('age') #删除key为age的cookie
    return response #自己研究 删除所有cookie



#session操作
#设置session

@app.route('/set_session/')
def set_session():
    session['uid'] = 1
    return 'session设置成功'

#获取session
@app.route('/get_session/')
def get_session():
    # return '获取session的值为{}'.format(session['uid'])
    # return '获取session的值为{}'.format(session['xxx']) #获取不存在的key keyError
    return '获取session的值为{}'.format(session.get('xxx'))

if __name__ == '__main__':
    # print(app)
    app.run(host='0.0.0.0',port=5001,debug=True,threaded=True) #将当前的flask运行起来



