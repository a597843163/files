


'''

    异常处理： 当执行代码遇到问题时，让程序越过错误继续向下执行

    try:
        可能出现异常的代码
    except 异常类型 as e:
        处理
    finally:
        代码

    try: 尝试执行代码，如果出现错误，则抛出异常
    except: 捕获异常
    finally: 不管有没有异常，都会执行，可以没有

'''

# ZeroDivisionError: division by zero
# print(5/0)

try:
    print(5/0)
except ZeroDivisionError as e:
    print("捕获到异常：除数为0")
except NameError as e:
    print("捕获到异常：未定义")

finally:
    print("finally")
print("end")








