


# 栈 ：一种数据结构

# 栈的特点：先进后出（先加入的数据，最后才能取出）
#          后进先出（后加入的数据，可以先取出）

# 使用列表来模拟栈结构
# append() : 在列表的末尾加入数据
# pop() : 在列表的末尾取出数据（删除数据）

# 定义一个空栈结构（空列表）
stack = []

# 入栈，压栈：在列表末尾加入数据
stack.append("A")
print(stack)

stack.append("B")
print(stack)

stack.append("C")
print(stack)


# 出栈 : 在列表的末尾取出数据
res = stack.pop()
print(stack)  # ['A', 'B']
print(res)  # C

res = stack.pop()
print(stack)  # ['A']
print(res)  # B


