from django.db import models

# Create your models here.

class Group(models.Model):
    name = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class User(models.Model):
    name = models.CharField(max_length=30)
    passwd = models.CharField(max_length=20)
    groups = models.ManyToManyField('Group')

    def __str__(self):
        return self.name