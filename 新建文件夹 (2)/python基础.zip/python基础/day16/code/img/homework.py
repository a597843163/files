from urllib import request
import re

url = "https://ubuntu.pkgs.org/16.04/ubuntu-main-amd64/"
response = request.urlopen(url)
str1 = response.read().decode("utf-8")

# 正则

reg1 = re.compile("packages_tree(.*)</ul>\\n</div>",re.S)
Lis1 = reg1.findall(str1)
# print(Lis1[0])
# try:
#     print(Lis1[1])
# except:
#     print("没有Lis1[1]")
# 从小范围中找span
#  链接正则
regUrl = re.compile('<a href="(.*)">',re.M)
#  名字正则
regName = re.compile('<a.*">(.*)</a>',re.M)
Url_list = regUrl.findall(Lis1[0])
Name_list = regName.findall(Lis1[0])
# print(Url_list)
# 得到 /16.04/ubuntu-main-amd64/a11y-profile-manager-doc_0.1.10-0ubuntu3_all.deb.html
# 需要
# https://ubuntu.pkgs.org/16.04/ubuntu-main-amd64/a11y-profile-manager-doc_0.1.10-0ubuntu3_all.deb.html
# print(Name_list)
# 遍历Url和Name
# for name in Name_list:






'''
<div class="packages_tree">
<ul>
<li>
<a href="/16.04/ubuntu-main-amd64/a11y-profile-manager-doc_0.1.10-0ubuntu3_all.deb.html">a11y-profile-manager-doc_0.1.10-0ubuntu3_all.deb</a><span>Accessibility Profile Manager - (Documentation</span>
</li>
<li>
<a href="/16.04/ubuntu-main-amd64/a11y-profile-manager-indicator_0.1.10-0ubuntu3_amd64.deb.html">a11y-profile-manager-indicator_0.1.10-0ubuntu3_amd64.deb</a><span>Accessibility Profile Manager - Unity desktop indicator</span>
</li>
<li>
<a href="/16.04/ubuntu-main-amd64/a11y-profile-manager_0.1.10-0ubuntu3_amd64.deb.html">a11y-profile-manager_0.1.10-0ubuntu3_amd64.deb</a><span>Accessibility Profile Manager - Command-line utility</span>
</li>
'''

# reg3 = ""