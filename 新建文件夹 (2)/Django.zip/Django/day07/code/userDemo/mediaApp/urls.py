from django.conf.urls import url
from .views import *


urlpatterns = [
    url(r'^index/$', index, name='index'),
    url(r'^fileupload/$', file_upload, name='file_upload'),
    url(r'^index3/$', index3, name='index3'),
    url(r'^fileupload2/$', file_upload2, name='file_upload2'),

    url(r'^index4/$', index4, name='index4'),
    url(r'^uploadicon/$', upload_icon, name='upload_icon'),

]





