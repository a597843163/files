# 创建一个队列。放10个数据，再创建一个线程。线程从队列中取数据，当队列为空时，退出线程。
import threading
import queue
import time


# 创建全局队列
q = queue.Queue(10)

# 设置一个线程退出标志
exit_flag = False


class MyThread(threading.Thread):
    def __init__(self, q, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.q = q

    def run(self):

        # 循环取数据
        while True:
            # 退出条件。
            time.sleep(1)
            if exit_flag:
                break
            # 取数据
            value = self.q.get(block=False)
            # 告诉q，取数据操作完。q的join方法
            self.q.task_done()
            print('%d数据被取出'%value)


def main():
    print('主线程开始')
    # 往队列中存放数据
    for i in range(10):
        q.put(i)

    # 创建线程
    t = MyThread(q)
    t.start()
    # 取数据
    # 在线程中取数据
    # 线程的join函数即线程锁。
    # t.join()
    # 使用队列锁, 当q为空时，才会继续执行。
    q.join()
    # 设置退出标志为True
    global exit_flag
    exit_flag = True
    print('主线程结束')


if __name__ == '__main__':
    main()