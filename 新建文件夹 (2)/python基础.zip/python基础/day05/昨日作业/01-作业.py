
''''''

# 1,成绩判定
# 	大于85 优秀
# 	大于等于75小于等于85 良好
# 	大于等于60小于75 及格
# 	小于60  不及格
'''
score = int(input("请输入您的成绩："))
if score > 85:
    print("优秀")
elif score >= 75:
    print("良好")
elif score >= 60:
    print("及格")
else:
    print("不及格")
'''

# 2,判断一个年份是闰年还是平年；
# （1.能被4整除而不能被100整除.（如2004年就是闰年,1800年不是.）
#   2.能被400整除.（如2000年是闰年））
'''
year = int(input("请输入一个年份："))
if (year%4==0 and year%100!=0) or year%400==0:
    print(year, "是闰年")
else:
    print(year, "是平年")
'''

# 3,输入一个月数，然后输出对应月份有多少天，将天数输出
# 比如：
# 输入 6 输出为30
# 输入 2 输出为28
'''
month = int(input("请输入一个月份："))
if month == 2:
    year = int(input("请输入一个年份："))
    if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
        print(29)
    else:
        print(28)
elif month==4 or month==6 or month==9 or month==11:
    print(30)
else:
    print(31)
'''

# 4.  开发一款软件，根据公式（身高-108）*2=标准体重，可以有10斤左右的浮动。
# 来观察测试者体重是否合适, 输入真实身高，真实体重
# if 真实体重 >= 标准体重-10 and 真实体重 <= 标准体重+10:
'''
height = int(input("请输入您的身高:"))
weight = int(input("请输入您的体重："))
standradWeight = (height - 108) * 2
if weight >= standradWeight-10 and weight <= standradWeight+10:
    print("体重合适")
else:
    print("体重不合适")
'''

# 5.输入某年某月某日，判断这一天是这一年的第几天？ (*****)
# year, month， day
#  2018，10,11
#  将31+28+..30 + day
#
#   days = day
#   if month > 1:
#       days += 31 (1月份总天数)
#   if month > 2:
#       days += 28 (2月份天数)
#   ...
'''
year = int(input("请输入年份："))
month = int(input("请输入月份："))
day = int(input("请输入天："))

days = day
if month > 1:
    days += 31
if month > 2:
    if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
        days += 29
    else:
        days += 28
if month > 3:
    days += 31
if month > 4:
    days += 30
if month > 5:
    days += 31
if month > 6:
    days += 30
if month > 7:
    days += 31
if month > 8:
    days += 31
if month > 9:
    days += 30
if month > 10:
    days += 31
if month > 11:
    days += 30
print("一年中的第",days,"天")
'''


# 6,输入一个时间，输出该时间的下一秒： (*****)
# 如：输入23:59:59， 输入：hour, min, sec
# 输出 0: 0: 0
hour = int(input("输入时:"))
min = int(input("输入分："))
sec = int(input("输入秒："))
sec += 1
if sec == 60:
    sec = 0
    min += 1
    if min == 60:
        min = 0
        hour += 1
        if hour == 24:
            hour = 0
print(hour, ":", min, ":", sec)



# 7, 已知有两个字符串str1 = ‘hello’ , str2 = ‘world’,将两个字符串组成一个;
str1 = "hello"
str2 = "world"
print(str1 + str2)

# 8, 已知字符串str = “I hate BeiJing!”,提取第3个字符到第6个字符hate
str = "I hate BeiJing!"
print(str[2:6])





