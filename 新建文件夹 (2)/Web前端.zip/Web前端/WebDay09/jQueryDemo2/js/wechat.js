// 设置一个变量记录一下当前页码
var currentPage = 0;
$(function(){
	// 1. 获取窗口的大小
	var w_width = window.innerWidth;
	var w_height = window.innerHeight;
	
	// 2. 设置容器的大小
	var container  =$("#container");
	container.width(w_width);
	container.height(4 * w_height);
	
	// 设置每一页的大小
	var divpage = $(".page");
	divpage.width(w_width);
	divpage.height(w_height);
	
	//设置第一页的效果
	// 背景有一个淡入的效果  人有一个飞入的效果
	$(".page1_building").fadeIn(1000, function(){
		//人飞进来
		$(".page1_person").animate({"left":"15%", "width":"70%"}, 1500);
	});
	
	//向上滑动翻页
	container.swipe({
		/*
		 * event -- 事件对象
		 * direction 滑动的方向
		 * distance 滑动的距离
		 * duration 持续时间
		 * fingerCount 你用几根手机滑动的
		 */
		swipe: function(event, direction, distance, duration, fingerCount){
			if(direction == "up"){
				currentPage++;
			}else if(direction == "down"){
				currentPage--;
			}
			// 临界值
			if(currentPage > 3){
				currentPage = 3;
			}
			
			if(currentPage < 0){
				currentPage = 0;
			}
			
			// 操作一个事件: 容器向上移动一个页面 距离上边的间隙为-(一个页的高度)
			// top ---> 容器得有有效的定位属性
			container.animate({"top":currentPage *(-w_height) + "px"}, 400, function(){
				// 第二页
				if(currentPage == 1){
					//背景图淡入
					$(".page2_back").fadeIn(1000, function(){
						// 文本1动画进入
						$(".page2_title1").animate({"width":"70%", "right":"0px"}, 1000, function(){
							// 文本1动画完成之后 文本2动画进入
							$(".page2_title2").animate({"width":"70%", "right":"0px"}, 1000);
						});
					});
				}
				
				// 第三页
				if(currentPage == 2){
					$(".page3_bus").animate({"left":"-100%"}, 2000);
					$(".page3_person").animate({"right":"50%"}, 2000);
				}
			});
			
		}
	});
	
});

// 点击灯触发的事件
function onlight(img){
	// 修改灯的图片
	img.src = "../../img/lightOn.png";
	
	//场景1 淡出  淡出成功之后 场景2淡入
	$(".page4_back1").fadeOut("slow");
	$(".page4_title1").fadeOut("slow");
	$(".page4_guide").fadeOut("slow", function(){
		// 场景二淡入
		$(".page4_back2").fadeIn(500, function(){
			$(".page4_title2").fadeIn(500);
		});
	});
	
}

