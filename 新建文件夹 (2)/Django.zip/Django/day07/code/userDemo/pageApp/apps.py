from django.apps import AppConfig


class PageappConfig(AppConfig):
    name = 'pageApp'
