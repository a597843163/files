import requests
from bs4 import BeautifulSoup
import urllib.parse
import json


# 封装的爬取腾讯招聘的类
class Tencent(object):
    def __init__(self, url, area, sortclass,gangwei, start_page, end_page):
        self.url = url
        self.area = area
        self.sortclass = sortclass
        self.gangwei = gangwei
        self.start_page = start_page
        self.end_page = end_page
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537'
        }

    # 将url生成请求对象的函数
    def handle_url(self, page):
        data = {
            'lid': self.area,
            'keywords': self.gangwei,
            'start': (page-1)*10,
            'tid' : self.sortclass
        }
        # 将参数编译成url可以识别的
        data = urllib.parse.urlencode(data)
        url = self.url + data
        return url

    # 处理下载请求的函数
    def download(self, url):
        r = requests.get(url=url,headers=self.headers)
        r.encoding = 'utf-8'
        data = r.text
        soup = BeautifulSoup(data, 'lxml')
        table = soup.select('table')[0]
        # 找出所有的tr
        tr_list = table.select('tr')

        for tr in tr_list[:len(tr_list)-1]:
            if tr.select('td > a'):
                zwmc = tr.select('td > a')[0].get_text()
            else:
                zwmc = tr.select('td')[0].get_text()
            zwlb = tr.select('td')[1].get_text()
            num = tr.select('td')[2].get_text()
            location = tr.select('td')[3].get_text()
            time = tr.select('td')[4].get_text()
            Str = zwmc + ',' + zwlb + ',' + num + ',' + location + ',' + time + ',\n'
            # 将保存的内容写入到文件中
            with open('txzp.xls', 'a', encoding='utf-8-sig') as fp:
                    fp.write(Str)

    # 对外提供的接口函数
    def start(self):
        for page in range(self.start_page, self.end_page + 1):
            request = self.handle_url(page)
            self.download(request)

# 主函数入口
def main():
    url = 'https://hr.tencent.com/position.php?'
    gangwei = input('请输入工作岗位:')
    print('全部:0,深圳:2218,北京:2156,上海:2175,广州:2196,成都:2268,昆明:2426,美国:33,中国香港:2459,长春:2418,')
    print('武汉:2355,海口:2280,合肥:2320,杭州:2252,荷兰:90,日本:59,天津:2225,南京:2228,中国台湾:2461,郑州:2346,')
    print('西安:2381,马来西亚:60,重庆:2226,泰国:45')
    area = input('请输入数字选择地点:')
    print('全部:0,技术类:87,产品/项目类:82,市场类:83,设计类:81,职能类:84,内容编辑类:85,客户服务类:86,')
    sortclass = input('请输入数字选择类别:')
    start_page = int(input('请输入起始页面:'))
    end_page = int(input('请输入结束页面:'))

    area_list = [0,2218,2156,2175,2196,2268,2426,33,2459,2418,
                 2355,2280,2320,2252,90,59,2225,2228,2461,2346,
                 2381,60,2226,45]
    sortclass_list = [0,87,82,83,81,84,85,86]
    if (int(area) in area_list) and (int(sortclass) in sortclass_list):
        # 创建对象，调用函数
        obj = Tencent(url, area, sortclass,gangwei, start_page, end_page)
        obj.start()
    else:
        print('请输入正确的类别...')

if __name__ == '__main__':
    main()

