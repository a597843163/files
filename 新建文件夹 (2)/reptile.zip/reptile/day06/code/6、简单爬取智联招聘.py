from bs4 import BeautifulSoup
import requests


url = 'http://sou.zhaopin.com/jobs/searchresult.ashx?jl=%E6%B7%B1%E5%9C%B3&kw=python&sm=0&sg=492ea9f658fc4b148522d926e6717ce9&p=1'


r = requests.get(url=url)

soup = BeautifulSoup(r.text, 'lxml')
# print(soup)

job_name = soup.select('td.zwmc')[0].select('a')[0].string
print(job_name)

company_name = soup.select('td.gsmc')[0].select('a')[0].string
print(company_name)

salary = soup.select('td.zwyx')[0].string
print(salary)

place = soup.select('td.gzdd')[0].string
print(place)