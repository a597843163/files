

#
# 题目： 邮编查询
# 	创建函数， 传入一个邮编，得到归属地
#
#   [433100,"湖南省湘西土家族苗族自治州"],


def fn(postcode):

    fp = open(r"C:\wamp\www\day11\昨日作业\youbian.txt", "r", encoding="utf-8")
    lineList = fp.readlines()
    fp.close()

    for lineStr in lineList:
        str1 = lineStr[0:-2]
        # print(str1)
        list1 = eval(str1)
        if list1[0] == postcode:
            return list1[1]

    return "没有该邮编地址"

print(fn(4403407))


