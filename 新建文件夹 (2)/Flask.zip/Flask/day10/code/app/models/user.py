from flask import current_app

from app.extensions import db, login_manager
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import TimedJSONWebSignatureSerializer as Serialize
from flask_login import UserMixin
from .posts import Posts

class User(UserMixin, db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(15), unique=True)
    password_hash = db.Column(db.String(128))
    age = db.Column(db.Integer)
    sex = db.Column(db.Boolean, default=True)
    email = db.Column(db.String(50))
    icon = db.Column(db.String(80), default='default.jpg')
    confirm = db.Column(db.Boolean, default=False)  # 激活的字段，默认false没激活
    # 参数1为模型名称
    # backref 反向引用的字段名 Post.quer.get(1).user
    # lazy 懒加载 在使用的时候返回的是查询对象
    posts = db.relationship('Posts', backref='user', lazy='dynamic')
    # 参数1 为模型名称
    # 参数2  secondary 在多对多关系模型中指定要选择的关联表名称
    # 参数3  设置反向引用字段  加载时机
    favorites = db.relationship('Posts', secondary='collections', backref=db.backref('users', lazy='dynamic'),
                                lazy='dynamic')

    # 密码的处理.将外面传过来的密码作一个加密，过滤，然后赋值给password_hash
    # 装饰器的作用：将方法变成属性，可以直接通过self.password=赋值
    @property
    def password(self):
        raise AttributeError('password属性不可读')

    @password.setter
    def password(self, password):
        # 将传进来的密码直接变成加密的 传给密码属性
        self.password_hash = generate_password_hash(password)

    # 验证密码
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)  # 函数,已经加密的密码,从外部传入的密码，返回Bool

    # 生成激活邮箱的token
    def generate_activate_token(self):
        s = Serialize(current_app.config['SECRET_KEY'])  # 传入加密方式,自定义的
        return s.dumps({'id': self.id})  # 传入需要加密的对象/值

    # 定义一个方法去验证 并实现激活的方法
    @staticmethod
    def check_token(token):
        s = Serialize(current_app.config['SECRET_KEY'])
        try:
            data = s.loads(token)  # 反向序列化出字典
        except:
            return False
        # 通过字典拿出要激活的用户对象
        u = User.query.get(data['id'])
        if not u:  # 判断用户是否存在
            return False
        if not u.confirm:  # 判断用户是否已经激活过 如果没有则激活
            u.confirm = True
            db.session.add(u)
        return True

    #判断收藏还是没收藏的方法
    def is_favorite(self,postsId):
        favorites = self.favorites.all() #拿到当前用户的所有收藏
        for p in favorites:
            if p.id == postsId:
                return True
        #lambda 表达式完成？
        return False

    # 添加收藏
    def add_favorite(self,postsId):
        fAdd = self.favorites.append(Posts.query.get(postsId))

    # 取消收藏
    def remove_favorite(self,postsId):
        fAdd = self.favorites.remove(Posts.query.get(postsId))

# 登录认证的回掉函数  必须存在  不在 直接运行就报错
@login_manager.user_loader
def user_loader(uid):
    return User.query.get(int(uid))
