from django.db import models

# 用户表
class User(models.Model):
    username = models.CharField(max_length=30,unique=True)
    password = models.CharField(max_length=50)
    icon_name = models.CharField(max_length=65)
    email = models.EmailField()