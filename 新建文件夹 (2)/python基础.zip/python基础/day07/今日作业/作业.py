
#
# 1.简述普通参数、关键字参数、默认参数、可变长参数的区别
# 普通参数：一般情况下使用最多，，参数数量要一致，需要按照顺序传参
# 关键字参数：用形参名称相对应来传值，不需要按顺序传参
#  默认参数：，形参有默认值，较灵活，可输入参数，也可不输入
#  可变长参数：*args：可以接受不定长度的参数序列（元组），用在参数数量不固定的情况下
#               *kwargs：可以接受不定长的序列（字典），用在参数数量不固定的情况下

# 2.写函数，计算传入字符串中单个【数字】、【字母】、【空格] 以及 【其他】的个数

def fn1(str1):
    n1 = 0  # 空格
    n2 = 0  # 字母
    n3 = 0  # 数字
    n4 = 0  #  其他
    for i in str1 :
        if i == " ":
            n1 += 1
        elif  "a"<= i <= "z" or "A"<= i <= "Z":
            n2 += 1
        elif "0" <= i <= "9":
            n3 += 1
        else:
            n4 += 1
    print(n1,n2,n3,n4)
fn1("廖先国大佬  /123 abc")
fn1("asdfhj, 444asd2//  ,猪")  #  3，9,4,5

# 3.写函数，判断用户传入的参数（字符串、列表、元组）长度是否大于5
def fn2 (a):
    if len(a) > 5 :
        print("传入参数大于5")
    else:
        print("传入参数小于5")
fn2([1,2,3,5,5,6])
fn2("asd呵呵呵")

# 4.写函数，检查用户传入的对象（字符串、列表、元组）的每一个元素是否含有空内容。
def fn3(a):
    for i in a:
        if i ==" " or i =="" or i ==None:
            print("含有空内容")
            break
    else:
        print("不含有空内容")
fn3("asd呵呵呵")
fn3("asd呵 呵呵")


# 5.写一个函数，识别字符串是否符合python语法的变量名
import keyword
print(keyword.kwlist)
def fn4(a):
    if a in keyword.kwlist:
        return False
    if a[0]>="0"and a[0]<="9":
        return False
    for i in a:
        if ("9" >=i >="0")or ("a"<= i <= "z")or("A"<= i <= "Z")or i == "_":
            pass
        else:
            return False
    return True
print(fn4("for"))
# 6.定义一个函数，输入不定个数的数字，返回所有数字的和
def fn5(*arg):
    sum = 0
    for i in arg:
        sum += i
    return sum
print(fn5(1,2,3,4,10,101))

# 7, 写一个函数计算1到n的和, 并返回结果打印出来;(n为函数参数)

def fn6(n):
    sum = 0
    for i in range(1,n+1):
        sum += i
    return sum
print(fn6(6))

# 8, 写一个函数计算n的阶乘,并返回结果打印出来
def fn7(n):
    a = 1
    for i in range(1,n+1) :
        a *= i
    return a
print(fn7(5))

# 9, 写一个函数计算两个数的最小公倍数; 并返回结果打印出来
def fn8(a,b):
    n1 = max(a,b)
    while n1 >1 :
        if n1%a ==0 and n1%b ==0:
            print(n1)
            break
        n1 -= 1
fn8(24,12)

#
# 10, 写一个函数判断一个年份是不是闰年

def fn9(n):
    if n % 4 == 0 and n%100 != 0 or n % 400 == 0:
        print(n,"是闰年")
    else:
        print(n, "不是闰年")
fn9(2003)

# 11, 写再一个函数判断一个数是不是素数 (又称质数,除了1和本身以外不有其他数整除)
def fn10(a):
    for i in range(2,a):
        if a % i == 0 :
            print("不是素数")
            break
    else :
        print("是素数")
fn10(5)
fn10(10)

# 12, 年月日分别为自定义函数的参数，判断某一个日期是否为合法的日期;
# 	    如: 2018年12月33日不是合法的日期
# 	        2018年11月13日是合法的日期
def fn11(a,b,c):
    list1 = [1,3,5,7,8,10,12]
    list2 = [4,6,9,11]
    if (a>1) and (a% 4 == 0 and a % 100 != 0 )or (a % 400 == 0):
        if b == 2 and 1<=c<=29:
            print("是合法的日期")
        elif b in list1 and 1<= c <= 31  :
            print("是合法的日期")
        elif b in list2 and 1<= c <= 30 :
            print("是合法的日期")
        else:
            print("不是合法的日期")
    else:
        if (a>1)and(b == 2) and (1 <= c <= 28):
            print("是合法的日期")
        elif b in list1 and 1 <= c <= 31:
            print("是合法的日期")
        elif b in list2 and 1 <= c <= 30:
            print("是合法的日期")
        else:
            print("不是合法的日期")
fn11(2018,9,31)
'''
def fn12(a,b,c):
        if a < 0 :
            return False
        if b<1 or b >12:
            return False
        days = 31
        if b ==2:
            if fn9(a):
                days =29
            else:
                days =28
        elif b == 4 or b ==6 or b ==9  or b == 11:
            days =30
        if c<=1and c>=days:
            return False
        return True
'''