
from urllib import request
import json
# 作业1 : 分页获取豆瓣的数据 json数据
# url = "https://movie.douban.com/j/chart/top_list?type=11&interval_id=100%3A90&action=&start="+ str(i * 20)+"&limit=20"

for i in range(1,20):
    url = "https://movie.douban.com/j/chart/top_list?type=11&interval_id=100%3A90&action=&start=" + str(
        i * 20) + "&limit=20"
    response = request.urlopen(url)
    str1 = response.read().decode("utf-8")  # 获取每一页的内容，得到json字符串
    dict1 = json.loads(str1)   # 把json字符串转换成json对象
    print(dict1)







