import re

str = ',039794795abcfjeiowf,0238403895gjoirlkdn  f2f23prhg9g83'

pattern = re.compile(r'\w+')

#1 使用match
m = pattern.match(str)
# print(m)
# # 取出匹配到的字符串
# print(m.group())
# # 范围
# print(m.span())
# # 起始索引
# print(m.start())
# print(m.end())

# 2. search
p = re.compile(r'\d+')
p = re.compile((r'\,(\d+)[a-z]+'))
result = p.search(str)
print(result)
print(result.group())


#. findall 找出所有， 返回列表
num_list = p.findall(str)
print(num_list)


# finditer 返回可迭代对象。
result = p.finditer(str)
print(result)
for item in result:
    print(item.group())


# split 根据正则中的字符来分割字符串
str = 'aa,bb,cc : :    b  e : t '
p = re.compile(r'[\,\s\:]')
sub_list = p.split(str)
print(sub_list)

# sub 替换
str = '123 Hello, 456 World'
p = re.compile(r'(\d+) (\w+)')
print(p.findall(str))
print(p.sub(r'\2 \1', str))
print(p.sub(r'\2 zhangsan', str))
def fun(item):
    return 'cool ' + item.group(2)
print(p.sub(fun, str))


# 匹配汉字
str = '你好everyone，你好我好 大家好，good'
p = re.compile(u'[\u4e00-\u9fa5]+')
print(p.findall(str))


# 贪婪模式和非贪婪模式
str = 'aa<div>test1</div>bb<div>test2</div>cc'

# 非贪婪模式
p  = re.compile(r'<div>(.*?)</div>')
print(p.findall(str))
print(p.search(str))

# 贪婪模式
p  = re.compile(r'<div>(.*)</div>')
print(p.findall(str))
print(p.search(str))

# ip地址 ，使用正则表达式如何匹配。

