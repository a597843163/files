''''''

import re

# re.match() : 匹配字符串是否以某个模式开头，如果匹配不成功则返回None
# 参数1: 正则表达式
# 参数2：需要匹配的字符串
# 参数3: 标记，re.I: ignore忽略大小写，
#             re.M: 换行模式，每换一行会重新匹配，
#             re.S: 使用.元字符可以匹配到换行
# res = re.match("www", "www.baidu.com")
# res = re.match("www", "awww.baidu.com")  # None
# res = re.match("www", "awww.baiduwww.com")  # None
# res = re.match("www", "WWW.baidu.com")  # None
res = re.match("www", "WWW.baidu.com", re.I)  # None
print(res)



# re.search() : 匹配字符串中是否包含某个模式指定的字符串,返回第一次匹配的
# res = re.search("www", "www.baidu.com")
# res = re.search("www", "ww.baidu.com")  # None
# res = re.search("www", "wwww.baidu.com")
# res = re.search("www", "www.baiduwww.com")
res = re.search("www", "awww.baiduwww.com")
print(res)



# re.findall() : 匹配字符串中所有的和某个模式匹配的字符串，并以列表的形式返回
# res = re.findall("www", "www.baidu.com")  # ['www']
# res = re.findall("www", "awww.baiduwww.com")  # ['www', 'www']
# res = re.findall("www", "awww.baiduWwW.com", re.I)  # ['www', 'WwW']
res = re.findall("www", "ww.baidu.com")  # []
print(res)












