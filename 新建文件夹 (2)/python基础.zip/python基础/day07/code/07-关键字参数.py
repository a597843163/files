

'''
    关键字参数
        使用形参名称来传值
'''

def fn(name, age, likes):
    print(name, age, likes)

fn("老王", 33, ["爬墙", "游泳"])
fn(name="老宋", age=35, likes=["马蓉"])
fn(age=35, name="老宋", likes=["马蓉"])
fn("张三", likes=["女"], age=22)
# fn(name="张三", age=22, [1,2])  # 报错

# 关键字参数： 需要写在参数列表的后面
#             关键字参数的名称是形参名称


# print("hello", end=" ")