

'''
字符集
gbk
gbk2312
unicode  支持各个国家的编码,不支持ASCII码
UTF-8  不同的国家语言,编程utf-8

'''
'''
数值类型
int
字节类型
bytes:
    字符串转字节   str.encode('utf-8')
    字节转字符串   byte.decode('utf-8')
'''

# 一个中文三个字节
s = '狄哥, 你好!'.encode()
print(s)
b1 = b'\xe7\x8b\x84'
print(b1.decode())

print(dir(list))
print(dir(isinstance))

d = {'name':'disen','age':20}
# 反转字典,字典生成式
print({value:key for key,value in d.items()})


# 迭代器不一定是迭代器对象
'''
iter()
或者重写__iter__函数
'''

# 判断d是否是可迭代对象
import collections
# 不是迭代器
print(isinstance(d,collections.Iterator))
# 是对象
print(isinstance(d,collections.Iterable))

# 拓展
#  bin()   转二进制
# 8进制
#  oct()
# 16进制
#  hex()

print()
