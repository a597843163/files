from django.db import models


class User(models.Model):
    name = models.CharField(max_length=40)
    age = models.IntegerField(default=1)

