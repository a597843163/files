class Person(object):

    def __init__(self, name, age):
        self.name = name
        self.age = age

    # __str__方法： 让print输出指定的内容
    #   调用print函数会自动调用__str__函数，
    # 如果不写__str__,则默认会返回类名和地址
    def __str__(self):
        # return "姓名：" + self.name +"，年龄：" + str(self.age)
        return "姓名：%s，年龄：%d" % (self.name, self.age)

# 创建对象
person1 = Person("小明", 11)
# print(person1)  # <__main__.Person object at 0x00000000021DA7F0>
# print(id(person1))
print(person1)
print(person1.name, person1.age)


