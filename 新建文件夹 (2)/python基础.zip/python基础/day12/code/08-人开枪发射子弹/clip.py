

#   弹夹：
#       属性：子弹数量
#       方法：获取子弹数量， 设置子弹数量

class Clip(object):
    def __init__(self):
        self.number = 0  # 子弹数量

    # 获取子弹数量
    def getNumber(self):
        return self.__number

    # 设置子弹数量
    def setNumber(self, number):
        self.__number = number



