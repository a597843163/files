from flask import Flask,jsonify,abort,request
from flask_script import Manager
#pip install flask-restful
from flask_restful import Api,Resource
from itsdangerous import TimedJSONWebSignatureSerializer as seralize

#导入用户验证的模块
from flask_httpauth import HTTPBasicAuth
#pip install flask-httpauth
#实例化用户验证
auth = HTTPBasicAuth()

app = Flask(__name__)
app.config['SECRET_KEY'] = 'zhangsan'
api = Api(app)
manager = Manager(app)

#验证用户的回调函数
@auth.verify_password
def verify_password(username_or_token,password):
    if username_or_token == 'zhangsan' and password == '123456':
        return True
    #验证token
    s = seralize(app.config['SECRET_KEY'])
    try:
        s.loads(username_or_token)
        return True
    except:
        return False


@auth.error_handler
def Unauthorized():
    return jsonify({'error':'Unauthorized Access'})


#创建你要操作的资源类  增删改查
class UserApi(Resource):
    #添加验证
    decorators = [auth.login_required]
    def get(self,uid):
        return {'user':'get'}

    def put(self,uid):
        return {'user':'put'}

    def delete(self,uid):
        return {'user':'delete'}

class UserlistApi(Resource):
    def get(self):
        return {'get':'getAll'}
    def post(self):
        return {'post':'post'}

api.add_resource(UserApi,'/users/<int:uid>','/u/<int:uid>')
api.add_resource(UserlistApi,'/users')

@app.route('/get_token')
@auth.login_required
def get_token():
    s = seralize(app.config['SECRET_KEY'])
    return s.dumps({'username':'zhangsan'})

@app.errorhandler(404)
def page_noe_found(e):
    return jsonify({'error':'page_not_found'}),404

if __name__ == '__main__':
    manager.run()

