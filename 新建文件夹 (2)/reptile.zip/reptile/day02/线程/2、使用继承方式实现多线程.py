from threading import Thread
import time


class MyThread(Thread):
    def __init__(self, id, *args, **kwargs):
        # 调用父类的init方法
        super().__init__(*args, **kwargs)
        self.id = id

    def run(self):
        print('子线程#%d开始执行' % (self.id))
        time.sleep(3)
        print('子线程#%d结束执行' % (self.id))


if __name__ == '__main__':
    print('主线程开始执行')
    mythread = MyThread(1)
    mythread.start()

    print('主线程结束执行')