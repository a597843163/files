from django.apps import AppConfig


class StaticappConfig(AppConfig):
    name = 'staticApp'
