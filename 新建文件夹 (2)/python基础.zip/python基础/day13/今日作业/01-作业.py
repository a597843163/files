
# 1、把今天的课堂代码写2遍

# 2、实现以下类的继承

# 父类：Cat
# 方法： eat; miaow
# 属性： fur
# 说明： eat吃各种东西
#
# 子类1： GarfieldCat
# 方法：eat; miaow; talk
# 属性：fur; glasses
# 说明：eat只吃肉
#
# 子类2： TomCat
# 方法：eat; miaow; catchMouse
# 属性：fur; friend
# 说明：eat只吃面包

class Cat(object):
    def __init__(self,fur):
        self.fur = fur

    def eat(self):
        print("吃各种东西")
    def miaow(self):
        print("会喵喵喵的叫~~~")

class GarfieldCat(Cat):
    def __init__(self,fur,glasses):
        Cat.__init__(self,fur)
        self.glasses = glasses

    def eat(self):
        print("只吃肉")
    def talk(self):
        print("会说话~~~")

class TomCat(Cat):
    def __init__(self,fur,friend):
        Cat.__init__(self,fur)
        self.friend = friend
    def eat(self):
        print("只吃面包")

    def catchMouse(self):
        print("会抓老鼠")

cat = Cat("毛")
print(cat.fur)
cat.eat()
cat.miaow()
print("----------------")
garfieldcat = GarfieldCat("粉红色毛","墨镜")
garfieldcat.eat()
garfieldcat.miaow()
garfieldcat.talk()
print(garfieldcat.fur,garfieldcat.glasses)
print("----------------")
tomcat = TomCat("紫色毛","杰利鼠")
tomcat.eat()
tomcat.miaow()
tomcat.catchMouse()
print(tomcat.fur,tomcat.friend)