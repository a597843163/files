


from urllib import request
#   用户代理  两种方式
#   1.Request
#   2.x.add_header()
# http请求的头部信息
headers = {
    "Accept" : "application/json, text/javascript, */*; q=0.01",
    "X-Requested-With" : "XMLHttpRequest",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
    "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8"
}

url = "http://www.baidu.com"
# 创建一个请求对象
# myRequest = request.Request(url, headers=headers)

# myRequest = request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36"})

myRequest = request.Request(url)
myRequest.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36")

# 火狐浏览器User-Agent: "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0"

# 发送请求
response = request.urlopen(myRequest)
htmlStr = response.read().decode("utf-8")
print(htmlStr)





