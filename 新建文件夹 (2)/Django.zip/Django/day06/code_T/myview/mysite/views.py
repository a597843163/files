from django.shortcuts import render, reverse
from django.http import HttpResponse, HttpResponseRedirect
from .models import User


# 首页
def index(request):
    old_username = request.COOKIES.get('username', "")
    u = User.objects.get(username=old_username)
    return render(request, 'mysite/index.html', {'old_username': old_username})


# 登录
def login(request):
    old_username = request.COOKIES.get('username', "")
    return render(request, 'mysite/login.html', {'old_username': old_username})


# 登录操作
def login_handle(request):
    # 登录
    # post请求
    errmsg = ""
    if request.method == 'POST':
        username1 = request.POST.get('username')
        password1 = request.POST.get('password')
        remember = request.POST.get('remember')
        # print(remember)  # on 或 None

        # 查询数据库User表中是否有匹配的用户名和密码
        res = User.objects.filter(username=username1, password=password1).exists()
        if res:
            response = HttpResponseRedirect(reverse('mysite:login'))
            # 如果勾选了‘记住用户名’，则添加cookie
            if remember:
                # max_age:为过期时间，这里表示10秒后会删除cookie
                # max_age=0：表示浏览器关闭时删除cookie
                # max_age=None: 表示永不过期
                # expires=datetime.datetime(2019, 10, 20)
                response.set_cookie("username", username1, max_age=10)
            return response

            # return HttpResponseRedirect(reverse('mysite:index'))  # 登录成功，返回到首页
        else:
            errmsg = "用户名或密码错误"
            return render(request, 'mysite/login.html', {'errmsg': errmsg})

    return HttpResponse(errmsg)


# 取消记住用户名，删除cookie
def logout(request):
    response = HttpResponseRedirect(reverse('mysite:login'))
    response.delete_cookie("username")
    return response



# 注册: 作业
#  obj, is_created = get_or_create()



