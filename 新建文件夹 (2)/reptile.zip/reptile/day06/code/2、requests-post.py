import requests


url = 'http://fanyi.baidu.com/sug'

data = {
    'kw': 'hello'
}

r = requests.post(url=url, data=data)

print(r.text)

# 把json数据编码
print(r.json())

