
# list 列表操作

#增
# append():追加一个元素
list1 = [1, 2, 3, 4, 5, 6, 7, 8]
list1.append(66)
print(list1)

# extend():追加多个元素
# list1.extend([77,88])
list1.append([77,88])
print(list1)

#  insert():插入元素
#  参数1：插入位置\下标
#  参数2:插入值
list1.insert(5,10)
print(list1)

#  删除
# del list1  #清空了
# print(list1)

# pop():删除最后一个，且会返回元素的值
res = list1.pop()
print(res)
print(list1)

# remove () : 删除元素的值，第一次匹配的值
list2 = [1, 2, 3, 4, 5, 6, 7, 8, 3, 2, 1,1,1]
list2.remove(3)
print(list2)

# count():统计指定元素出现的次数
print(list2.count(1))

# 删除所有的1
for i in range(list2.count(1)):
    list2.remove(1)
print(list2)


#  clear():清空列表
list2.clear()
print(list2)

#  改
print(list1)
list1[5] = 11
print(list1)

#  index 查下标
print(list1.index(66))

print(max(list1))
print(min(list1))
#  排序 不改变原列表
list2 = sorted(list1)
print(list2)

list2 = sorted(list1,reverse=True)
print(list2)

#  会改变原列表
list1.sort()
print(list1)
list1.sort(reverse=True)
print(list2)

#  逆序
list1.reverse()
print(list1)


personDict = {"name":"老王", "age":20, "sex":"男"}
personDict["qq"] = "123456"
print(personDict)
personDict["qq"] = "987654312"
print(personDict)
#  删除
personDict.pop("sex")
#  遍历
print(personDict)
for key in personDict:
    print(key,personDict[key])
#  集合
set1 = {33, 11, 44, 22, 55}
set1.add(100)
print(set1)

set1.update((77,88))
print(set1)
set1.update([77,88])
print(set1)










