
from collections import Iterator    #   迭代器
from collections import Iterable    #   迭代器对象

print(isinstance([1,2],Iterable))  # True
# 只要可以用for in遍历的都是迭代器对象

print(isinstance([1,2],Iterator)) # False

# 生成器是迭代器
# 创建一个生成器
generator = (i for i in range(1,11))
print(isinstance(generator,Iterator))  #  True

# iter() : 把迭代器对象转换成迭代器
list1 = [1,2,3,4,5]
res = iter(list1)
print(next(res))

#  将迭代器转换成迭代器对象
list2 = list(res)
print(list2)

# 生成器
def fn1(n):
    yield n*n
    yield (n*n+1)
    yield (n*n+2)

generator1 = fn1(100)
print(next(generator1))
print(next(generator1))
print(next(generator1))


#   filter（） 过滤器
res = filter(lambda x:x%2==0 ,list(range(1,101)))
print(list(res))

#  map() :现有列表，计算返回新列表
map1 = map(lambda x:x**3 ,[1,2,4,5,6])
print(list(map1))

#  reduce() 把列表相邻两个相计算
from functools import reduce
res = reduce(lambda a,b : a*b,[3, 4, 8, 7, 5, 9, 6, 1, 2])
print(res)











