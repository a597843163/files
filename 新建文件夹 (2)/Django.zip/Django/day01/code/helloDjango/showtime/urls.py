from django.conf.urls import url
from .views import showTime,index2


urlpatterns = [
    url(r'^showtime/',showTime),
    url(r'^index2/',index2),
]
