import json

# 读取文件中json形式的字符串元素 转化成python类型
obj = json.load(open('../file/book.json', 'r', encoding='utf-8'))
print(type(obj), obj)    # 输出内容同下

# 将json格式字符串转化为对象
with open('../file/book.json', 'r', encoding='utf-8') as fp:
    json_string = fp.read()
obj = json.loads(json_string)
print(type(obj), obj)   # # 输出内容同上

# 实现python类型转化为json字符串，返回一个str对象 把一个Python对象编码转换成Json字符串
str = '''
{"has_more": false, "message": "success", "data": [{"single_mode": true, "abstract": "\u8c22\u8c22\u5927\u5bb6\u559c\u6b22\u6bcf\u65e5\u64b8"}]}
'''
obj = json.dumps(str, ensure_ascii=False)
print(type(obj), obj)   # 输出字符串   json格式的字符串

# 使用dump把字符串写入到文件中，将Python内置类型序列化为json对象后写入文件
dictStr = {"city": "北京", "name": "大刘",'info':'\u8c22\u8c22\u5927'}
json.dump(dictStr, open('dump.json', 'w', encoding='utf-8'), ensure_ascii=False)
