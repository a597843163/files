'''
fp1 = open("作业.txt","rb")

content = fp1.read()
str1 = content.decode(encoding="utf-8")
print(str1)

fp1.close()
'''
import os

#
# 1、自己实现splitext()
def fn1(str1):
    index = str1.rfind(".")
    str2 = str1[:index]
    str3 = str1[index:]
    return (str2,str3)
print(fn1("情书.txt"))
print(fn1("给志玲姐姐的一封信.py"))

# 2、自己实现 os.path.join()
def fn2(str1,str2):
    print(str1+'\\'+str2)
fn2(r"C:\wamp\www\day08\code","情书.txt")  # C:\wamp\www\day08\code\情书.txt

print('---------------------------------------------------')
# 3、写一个拷贝函数，传入文件名称，拷贝一个文件，考虑大文件的拷贝
def fn3(str1):
    # index = str1.rfind(".")                     # 找下标
    # str2 = str1[:index]+"-副本"+str1[index:]     #新名字
    str1_list = os.path.splitext(str1)      # 找下标
    str2 = "-副本".join(str1_list)    #新名字
    fp1 = open(str1,"rb")
    fp2 = open(str2,"wb")
    while True:
        contend = fp1.read(1024)
        if len(contend)==0:   #  写完了
            return
        fp2.write(contend)
    fp1.close()
    fp2.close()
fn3(r"F:\pythonStudy\python基础\day08\code\09-pickle模块-副本.py")
print('---------------------------------------------------')
# 4、复制day08\code目录下的所有文件到day08\code2中（只考虑一层）
# #  listdir()
# #  遍历

os.mkdir("F:\pythonStudy\python基础\day08\code2")     #  创建新文件夹code2
count=os.listdir("F:\python千峰课件\day08\code")  # 文件夹中的文件名
for i in count:                                        #   i是文件名
    x = "F:\python千峰课件\day08\code"+"\\"+i   # 定义 路径
    if os.path.isfile(x):        #  判断是否问文件
        index = i.rfind(".")      #  找下标，定义新文件名字
        i1 = i[:index]+"-副本"+i[index:]
        a ="F:\python千峰课件\day08\code2\\"+i1   #  新文件的路径
        fp1 = open(x, "rb")  # 开老的文件
        fp2=open(a,"wb")     #  开新的文件
        while True:         #  复制
            coutent = fp1.read(1024)
            if len(coutent) == 0:
                break
            fp2.write(coutent)
        fp1.close()    #关
        fp2.close()
    elif os.path.isdir(x):
        x = "F:\python千峰课件\day08\code2\\"+i+"-副本"
        os.mkdir(x)


'''
import os
os.mkdir("..\\code2")     #  创建新文件夹code2
count=os.listdir("..\\code")  # 文件夹中的文件名
for i in count:                                        #   i是文件名
    x = ".."+"\\code\\"+i   # 定义 路径
    if os.path.isfile(x):        #  判断是否问文件
        index = i.rfind(".")      #  找下标，定义新文件名字
        i1 = i[:index]+"-副本"+i[index:]
        a ="..\\code2\\"+i1   #  新文件的路径
        fp1 = open(x, "rb")  # 开老的文件
        fp2=open(a,"wb")     #  开新的文件
        while True:         #  复制
            coutent = fp1.read(1024)
            if len(coutent) == 0:
                break
            fp2.write(coutent)
        fp1.close()    #关
        fp2.close()
    elif os.path.isdir(x):
        x = "..\\code2\\"+i+"-副本"
        os.mkdir(x)
'''


