def run():
    data = 'data'
    r = yield data

    print(1,r,data)

    r = yield  data

    print(2, r, data)

    r = yield data

    print(3, r, data)

m = run()

print(type(m))

print(m.send(None))
print(m.send('abc'))
print(m.send('123'))
print(m.send('!@#$'))