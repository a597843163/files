from flask import Blueprint, redirect, url_for, request, abort

# 实例化蓝本
# Blueprint中user为当前蓝本的名称，在跳转的时候
user = Blueprint('user',__name__)

@user.route('/login/')
def login():
    return '登陆处理'

@user.route('/register/')
def register():
    return redirect('/test/')


@user.before_app_request
def before_request():
    if request.method == 'GET' and request.path == '/form/':
        abort(404)
    print(request.path)
    # print('before_request')

