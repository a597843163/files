'''
import time

from selenium import webdriver

url = 'http://www.365yg.com/a6562126117363253763/#mid=6586189617'

driver = webdriver.Chrome()

driver.implicitly_wait(10)

driver.get(url=url)

src = driver.find_element_by_xpath('//video[@class="vjs-tech"]/source')[0].get_attribute('src')

print(src)
time.sleep(10)
driver.quit()
'''
from selenium import webdriver
import requests
import json
import time

base_url = 'https://www.toutiao.com/'

path = r'F:\phantomjs-2.1.1-windows\bin\phantomjs.exe'
def download_video(title, video_page_url):
    driver = webdriver.PhantomJS(executable_path=path)
    driver.get(video_page_url)
    # 休眠，为了将所有的数据都加载出来
    time.sleep(3)

    video_url = driver.find_elements_by_xpath('//video[@class="vjs-tech"]/source')[0].get_attribute('src')

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36'}

    r = requests.get(video_url, headers=headers)

    with open('%s.mp4' % title, 'wb') as file:
        file.write(r.content)
    print('成功下载视频：%s' % (title))

def spider(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36',
        'Referer': 'https://www.ixigua.com/?utm_source=toutiao&utm_medium=video_channel'
                   ''}
    response = requests.get(url, headers=headers, verify=False)

    # 保存json数据
    with open('toutiao.json', mode='w', encoding='utf-8') as file:
        loads = json.loads(response.text)
        file.write(json.dumps(loads, ensure_ascii=False))

    j_data = json.loads(response.text)
    print('开始下载……')
    for video_info in j_data['data']:
        video_page_url = base_url + video_info['source_url']
        title = video_info['title']
        print(title, video_page_url)
        # 调用方法下载video
        download_video(title, video_page_url)
    print('下载结束…………')


if __name__ == '__main__':
    url = 'https://www.toutiao.com/'
    ajax_url = 'https://www.ixigua.com/api/pc/feed/?min_behot_time=0&category=video_new&' \
               'utm_source=toutiao&widen=1&tadrequire=true&as=A135FA25492F69B&cp=5A59DF86491B8E1&_signature=6j9f-hAasHEkVNkob36ofeo.X'
    spider(ajax_url)

