import threading,time

# 创建信号量
# sema = threading.Semaphore(4)

sema = threading.Semaphore(3)

# 定义线程执行的函数
def run(i):
    print('开始%s -- %d' % (threading.current_thread().name,i))
    # 获取信号量,信号减1
    # 为每一个线程加一个信号量,sema就需要减1
    sema.acquire()
    time.sleep(4)
    # 释放信号量,信号加1
    sema.release()
    print('结束%s -- %d' % (threading.current_thread().name,i))

if __name__ == '__main__':
    print('主线程开始')
    # 创建5个线程
    for i in range(5):
        threading.Thread(target=run,args=(i,)).start()

    print('主线程结束')

