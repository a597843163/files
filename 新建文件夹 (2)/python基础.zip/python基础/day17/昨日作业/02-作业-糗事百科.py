
import re
from urllib import request
import time

# 作业2: 爬取糗事百科文本页的所有段子,结果如 : xx说: xxxx
#   设置代理： User-Agent
# https://www.qiushibaike.com/text/page/1/

# ("<div class="author clearfix">(.*?)<span class="stats-vote"><i class="number">" , re.S)


def getData(url):

    # 先获取内容
    userAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36"
    myRequest = request.Request(url)
    myRequest.add_header("User-Agent", userAgent)
    response = request.urlopen(myRequest)
    htmlStr = response.read().decode("utf-8")
    # print(htmlStr)


    # 使用正则来匹配获取需要的数据
    #  "8google8 8google8"

    regCom = re.compile('<div class="author clearfix">(.*?)<span class="stats-vote"><i class="number">', re.S)
    itemList = regCom.findall(htmlStr)
    # print(len(itemList))

    list1 = []
    for item in itemList:
        nameCom = re.compile('<h2>(.*?)</h2>', re.S)
        name = nameCom.findall(item)[0].strip()  # "甜甜妞"
        # print(name)

        contentCom = re.compile('<span>(.*?)</span>', re.S)
        content = contentCom.findall(item)[0].strip()

        # 将name和content封装在字典dict1中
        dict1 = {"name1": name, "content": content}
        list1.append(dict1)

    return list1


if __name__ == "__main__":

    # 所有数据
    allData = []
    # [{name1:zh, content:22},{name1:zh, content:22},{name1:zh, content:22},{name1:zh, content:22},...]

    # 遍历每一页的数据
    for i in range(1, 4):
        url = "https://www.qiushibaike.com/text/page/" + str(i) + "/"
        list1 = getData(url)
        allData.extend(list1)

        time.sleep(0.5)


    # 遍历allData 把数据显示
    for dict1 in allData:
        print("%s 说： %s" % (dict1["name1"], dict1["content"]))




