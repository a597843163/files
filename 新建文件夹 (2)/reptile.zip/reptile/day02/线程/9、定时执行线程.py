import threading, time


def run():
    print('子线程%s开始执行' % (threading.current_thread().name,))

    time.sleep(2)
    print('子线程%s结束执行' % (threading.current_thread().name,))


if __name__ == '__main__':
    # 传入等多久秒开始执行线程
    threading.Timer(5, run).start()

