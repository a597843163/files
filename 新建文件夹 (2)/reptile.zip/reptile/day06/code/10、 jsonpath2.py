import jsonpath
import json

# 获取json格式的python对象
obj = json.load(open('./book.json', 'r', encoding='utf-8'))

authors = jsonpath.jsonpath(obj, '$..book[*].author')
print(authors)

authors = jsonpath.jsonpath(obj, '$..author')
print(authors)

prices = jsonpath.jsonpath(obj, '$.store..price')
print(prices)

# 取最后一本书
last_book = jsonpath.jsonpath(obj, '$..book[(@.length-1)]')
print(last_book)

last_book = jsonpath.jsonpath(obj, '$..book[:2]')
print(last_book)