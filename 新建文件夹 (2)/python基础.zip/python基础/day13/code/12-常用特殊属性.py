
class A(object):
    pass

class Person(A):

    def __init__(self, name, age, sex):
        self.name = name
        self.age = age
        self.sex = sex

    def hello(self):
        print("hello")


# 对象
p = Person("马蓉", 30, "女")
print(Person.__name__)  # Person 类名
# print(type(Person.__name__))  # <class 'str'>
print(Person.__bases__)  # 基类，父类

# 获取对象中所有属性，返回的是一个字典
print(p.__dict__)  # {'name': '马蓉', 'age': 30, 'sex': '女'}  字典
# print(type(p.__dict__))  # <class 'dict'>

print(p.__class__)  # <class '__main__.Person'>  类型
print(p.__module__)  # __main__ 模块






