

# 导入urllib
from urllib import request

# request: 从客户端向服务端发送请求（request）
# response: 从服务端发送给客户端的响应（response）
respons= request.urlopen("http://wwe w.baidu.com")
# print(response)

# 使用read()来读取服务器返回的响应数据（二进制）
# data = response.read()
# str = data.decode("utf-8")
# str = response.read().decode("utf-8")
# print(str)
# 获取指定长度的内容
# str = response.read(1024).decode("utf-8")
# print(str)

# readline(): 一行一行读取
# str = response.readline().decode("utf-8")
# str = response.readline().decode("utf-8")
# print(str)

# readlines() : 按行读取所有数据，返回一个列表
# dataList = response.readlines()
# print(dataList)

# 遍历每一行数据
# for line in dataList:
#     print(line.decode("utf-8"))


# 把获取到的数据存在本地
# with open(r"html\baidu.html", "wb") as fp:
#     fp.write(response.read())


# 响应信息
# print(response.info())

# http请求的状态码
statusCode = response.getcode()
print(statusCode)  # 200

if statusCode == 200:
    print("请求成功！")
else:
    print("请求失败! 失败原因:", statusCode)

# 200 : 变成成功
# 4XX : 客户端错误
# 5XX : 服务端错误

# 404 : Not Found, url不存在或无法访问
# 403 ：拒绝，禁止访问
# 500 : 服务器内部错误


# 获取url
myUrl = response.geturl()
print(myUrl)  # http://www.baidu.com

'''
response.read()
response.readlines()
response.info()
response.geturl()
response.getcode()
'''












