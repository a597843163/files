from threading import Thread
import time


# 定义全局变量
num = 100

def run(n):
    print('子线程开始执行')
    global num
    for i in range(1000000):
        # 100 = 100 + 6
        # 100 = 100 - 9
        # num = 91
        num = num + n
        num = num - n
    time.sleep(1)
    # print(num)
    print('子线程结束执行')


if __name__ == '__main__':
    print('主线程开始执行')
    t1 = Thread(target=run, args=(6,))
    t2 = Thread(target=run, args=(9,))
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    print('num=', num)

    print('主线程结束执行')