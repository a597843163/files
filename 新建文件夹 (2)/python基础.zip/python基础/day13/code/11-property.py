


class Person(object):

    def __init__(self, name, age):
        self.name = name
        self.__age = age

    # # get方法
    # def getAge(self):
    #     return self.__age
    # # set方法
    # def setAge(self, age):
    #     self.__age = age

    # @property下面的方法相当于getAge()， @age.setter下的方法相当于setAge()
    # 处理私有变量用这两装饰器
    #  可以让调用的时候更加方便：对象.属性, 比如：p.age
    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, age):
        self.__age = age


# 对象
p = Person("宝强", 33)
# print(p.getAge())  # 33
# p.setAge(22)
# print(p.getAge())  # 22

print(p.age)  # 33
p.age = 22
print(p.age)  # 22





