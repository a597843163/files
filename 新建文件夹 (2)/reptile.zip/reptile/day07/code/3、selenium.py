# 基本使用
from selenium import webdriver
import time

# driver =webdriver.PhantomJS(executable_path=r'F:\phantomjs-2.1.1-windows\bin\phantomjs.exe')

# chrome的无界面
# options = webdriver.ChromeOptions()
# options.add_argument('headless')

# driver = webdriver.Chrome(options)
driver = webdriver.Chrome()
# 访问百度
driver.get('https://www.baidu.com/')

time.sleep(3)
with open('source.html','w',encoding='utf-8') as fp:
    fp.write(driver.page_source)
    print(driver.current_url)
driver.save_screenshot('baidu.png')

driver.quit()