import threading
import time


# 创建一个事件
event = threading.Event()

def run():
    event.clear()
    print('start...')
    # 进入到等待事件的阻塞状态中
    event.wait()
    time.sleep(2)
    print('end...')

if __name__ == '__main__':
    print('主程序开始执行')
    t1 = threading.Thread(target=run)
    t1.start()
    time.sleep(2)
    # 发送事件
    print('sending event...')
    event.set()
    t2 = threading.Thread(target=run)
    t2.start()
    print('主程序执行结束')
