from django.shortcuts import render
from .models import Book

# Create your views here.

def book(request):
    return render(request,'books/index.html')

# 书籍列表
def book_list(request):
    # 获取所有书籍
    b_list = Book.objects.all()
    return render(request,'books/list.html',{'b_list':b_list})

def book_detail(request,id1):
    b_detail = Book.objects.get(id = id1)
    return render(request,'books/detail.html',{'b_detail':b_detail})