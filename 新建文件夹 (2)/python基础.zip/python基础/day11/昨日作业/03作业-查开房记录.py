



#
# 题目： 开房查询
# 	创建函数，传入一个名字，查找到这哥们所有的开房记录，
#           然后写入到以这哥们名字为名的txt文件中 如：张三.txt
#
# 周建华,320602196511302041,F,19651130,上海市普陀区石湾路7弄51号503室,200063,13817627228,021-52682026,021-52682947,hd6418@hotmail.com,

import pickle

def fn(name):

    # 先获取文件中的数据
    fp = open(r"C:\wamp\www\day11\昨日作业\kaifanglist.txt", "r", encoding="utf-8")
    lineList = fp.readlines()
    fp.close()

    # 遍历每一行数据，找到匹配name名字的数据
    kfList = []
    for lineStr in lineList:
        #if lineStr.startswith(name):
        list1 = lineStr.split(",")
        if list1[0] == name:
            kfList.append(lineStr)
    print(kfList)

    # pickle存储列表
    # fileName = name + ".txt"
    # fp2 = open(fileName, "ab")
    # pickle.dump(kfList, fp2)
    # fp2.close()

    # 存储字符串
    kfStr = "".join(kfList)
    fileName = name + ".txt"
    fp2 = open(fileName, "a", encoding="utf-8")
    fp2.write(kfStr)
    fp2.close()


fn("孙旸")

