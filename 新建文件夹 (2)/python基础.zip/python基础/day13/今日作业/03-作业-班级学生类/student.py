

# 	学生类：
# 		属性：姓名，年龄，性别，成绩，学号

class Student(object):
    def __init__(self,name,age,sex,sorce,student_id):
            self.name = name
            self.age  = age
            self.sex  = sex
            self.sorce= sorce
            self.student_id = student_id
            list1 = [name,]




