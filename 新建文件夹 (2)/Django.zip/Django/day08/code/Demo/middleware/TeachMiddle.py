from django.http import HttpResponse
from django.shortcuts import redirect
from django.utils.deprecation import MiddlewareMixin

# 自定义的中间件
class helloMiddleware(MiddlewareMixin):
    # 在执行视图前被调用
    def process_request(self,request):
        print("请求的路径", request.path)
        print("获取访问者的地址:",request.META['REMOTE_ADDR'])

        ip = request.META['REMOTE_ADDR']
        if ip == '10.36.137.44':
            return HttpResponse('本网站不欢迎你')

        if request.path == '/app/getgoods/':
            username = request.POST.get('username')
            if username == '习大大':
                return HttpResponse('恭喜您，抢到了满1000减999的优惠券')
            if ip == '10.36.137.44':
                return HttpResponse("优惠券已抢完")
            if username == '凤姐':
                return HttpResponse("优惠券已抢完")
            if not username:
                return HttpResponse("请输入合法的用户名")

    # 当视图抛出异常时调用
    def process_exception(self,request,exception):
        print('exception',str(exception))
        return redirect('/app/index/')
