


# 父类
class Father(object):

    def __init__(self, name):
        self.name = name

    def jump(self):
        print("我能跳3米")

# 子类
class Son(Father):
    def __init__(self, name, age):
        super().__init__(name)
        self.age = age

    # 方法重写： 让子类拥有和父类一样的方法, 对象会优先使用子类的方法
    def jump(self):
        print("老子能跳10米")

# 创建子类对象
son = Son("孙杨", 20)
son.jump()  # 老子能跳10米



