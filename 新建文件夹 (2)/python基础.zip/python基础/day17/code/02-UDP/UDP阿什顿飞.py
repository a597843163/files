

import socket


serverSocket = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

serverSocket.bind(("10.36.137.48",8524))

while True:
    print("等待客户端发送数据..")

    # 接受数据
    data ,address = serverSocket.recvfrom(1024)
    print(data.decode("utf-8"))
    print(address)







