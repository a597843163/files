


# 输入： input("请输入姓名：")
# 输出： print() 换行, print("宝强") print("宝强", 33) print("宝强"+"马蓉")
#   print("姓名:%s, 年龄:%d, 身高: %.2f" % (name, age, height))
''''''

# 数据类型： number, string, boolean, None, list, tuple, dict, set, byte

# 变量:
#   变量的定义： name = "张三"  (初始化)， 要先定义才能使用变量
#   变量的赋值： name = "李四"   a = b = 10,  a,b = 1,2
#   python是弱类型： 可以赋不同类型的值
#           name = "凤姐"
#           name = 3
#   变量名称的规则：
#           1，只能由数字，字母，下划线组成
#           2，不能以数字开头  #如：4day是错误的
#           3，不能使用关键字
#           4, 区分大小写：小驼峰原则  nameList
#           5，见名思意  如列表： ageList, ages， 字典:personDict
#   数值类型：
#         整数int, 浮点float
#
#       int() : 转换成整数
#           可以转换成整数: 整数12，小数12.3，整数字符串"123"
#           不可以转换成整数： 小数字符串"12.3"，非数字整数123abc
#       float(): 转换成小数
#           可以转换成小数: 整数12，小数12.3，整数字符串"123"， 小数字符串"12.3"
#           不可以转换成小数： 非数字整数123abc
#       str() : 转换成字符串
#           把整数或小数转换成字符串
#           print("芙蓉姐姐" + str(18))
#
#       max(): 求最大值
#       min(): 求最小值
#       round(): 四舍五入
#       abs(): 绝对值
#
#       math函数：
#       math.sqrt()
#       math.ceil()
#       math.floor()
#       math.sin()
#       math.cos()
#       math.tan()

#       随机数random:
#       random.choice() : 从一个列表（序列）中随机选择一个
#           random.choice(list)
#           random.choice(range(10))  # [0, 10)
#           random.choice(range(2,10))  # [2, 10)
#       random.randrange(1, 10, 2) # 在[1, 10),步长为2，取的随机数范围是1,3,5,7,9

#       random.random() : [0,1)范围内的随机数
#       random.uniform(1,2):  [1,2]范围内的随机数

#       random.shuffle() : 把列表随机排序（乱序）

#       运算符： 算术运算符: +, -, *, /, 取整//, 取模（求余数）%, 幂（次方）**
#       if分支:
#           if单分支:
#               if 条件:
#                   语句
#
#           if双分支
#               if 条件:
#                   语句
#               else:
#                   其他语句
#









