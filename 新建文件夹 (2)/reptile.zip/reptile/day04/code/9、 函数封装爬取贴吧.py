import urllib.request
import urllib.parse
import ssl
import os

# 解决ssl证书问题
ssl._create_default_https_context = ssl._create_unverified_context

def handle_url(base_url, page, tieba_name):
    # 生成url
    data = {
        'kw': tieba_name,
        'pn': (page -1) * 50,
    }
    data = urllib.parse.urlencode(data)
    url = base_url + data
    # 生成request对象
    request = urllib.request.Request(url=url)
    # 返回
    return request

def download(request, page, tieba_name):
    response = urllib.request.urlopen(request)
    # 拼保存的文件名
    filename = tieba_name + str(page) + '.html' # python1.html python2.html
    with open(os.path.join('./tieba', filename), 'w', encoding='utf-8') as fb:
        fb.write(response.read().decode('utf-8'))

def main():
    base_url = 'http://tieba.baidu.com/f?ie=utf-8&'
    tieba_name = input('请输入想爬取的贴吧名：')
    start_page = int(input('请输入起始页：'))
    end_page = int(input('请输入结束页：'))

    # 循环处理每一页
    for page in range(start_page, end_page+1):
        # 处理url
        request = handle_url(base_url, page, tieba_name)
        # 下载页面
        # 封装函数执行下载动作
        print('开始下载第%d页'%page)
        download(request, page, tieba_name)
        print('结束下载第%d页' % page)


if __name__ == '__main__':
    main()