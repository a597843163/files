# -*- coding: utf-8 -*-
import re

import scrapy
from movie.items import MovieItem
import os

class DyttSpider(scrapy.Spider):
    name = 'dytt'
    allowed_domains = ['www.ygdy8.net']
    start_urls = ['http://www.ygdy8.net/html/gndy/dyzz/index.html']

    def parse(self, response):
        table_list = response.xpath('//table[contains(@class, "tbspan")]')
        for table in table_list:
            title = table.xpath('.//a/text()').extract_first()
            brief = table.xpath('.//tr[last()]/td/text()').extract_first()
            link = "http://www.ygdy8.net" + table.xpath('.//a/@href').extract_first()
            item = MovieItem()
            item['title'] = title
            item['brief'] = brief
            item['link'] = link
            # 每一个link点进去，然后获取下载资源的url
            # 最大页码
            pattern = re.compile(r'共(\d+)页')
            max_page = int(pattern.findall(response.text)[0])
            # 这里面涉及到一个传递item的问题，我们要学习如何传参,加上一个meta参数，meta参数是一个字典，过去之后，通过字典的键获取其值
            yield scrapy.Request(url=link, callback=self.movie_url, meta={'item': item})

        for page in range(2, max_page+1):
            url = 'http://www.ygdy8.net/html/gndy/dyzz/list_23_%d.html' % page
            # 回调函数parse
            yield scrapy.Request(url, callback=self.parse)

    def movie_url(self,response):
        item = response.meta['item']
        movie_url = response.xpath('//td[@bgcolor="#fdfddf"]/a/text()').extract_first()
        if not movie_url:
            movie_url = response.xpath('//td[@bgcolor="#fdfddf"]/font/a/@href').extract_first()
            if not movie_url:
                movie_url = response.xpath('//td[@bgcolor="#fdfddf"]/span/a/@href').extract_first()
        item['movie_url'] = movie_url
        yield item