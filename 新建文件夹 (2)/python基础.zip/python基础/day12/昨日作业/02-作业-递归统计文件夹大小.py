''''''

#
# 统计文件夹大小 (os.path.getSize()：获取文件大小)
#
import os


def getDirSize(dirPath):

    if not os.path.exists(dirPath):
        return "目录不存在"

    size = 0
    fileNameList = os.listdir(dirPath)
    for fileName in fileNameList:
        absPath = os.path.join(dirPath, fileName)

        if os.path.isfile(absPath):  # 文件
            size += os.path.getsize(absPath)
        elif os.path.isdir(absPath):  # 目录
            size += getDirSize(absPath)  # 递归

    return size


if __name__ == "__main__":
    path = r"C:\wamp\www\day11_video"
    res = getDirSize(path)
    print(res)



