


class Person(object):

    # 类属性
    # 共享
    money = 10
    family = ["爸爸", "妈妈", "弟弟"]

    def __init__(self, name, age):
        # 对象属性 / 成员属性/成员变量
        self.name = name
        self.age = age

        # 如果存在相同名称的对象属性和类属性，那么会优先使用对象属性
        # self.money = 30

    def eat(self):
        print("吃货")


# 创建对象
p = Person("老王", 33)

# 对象属性
print(p.name, p.age)
# print(Person.name, Person.age)  # 报错

# 类属性  可以直接用类名来掉，对象属性需要有实例化之后才可以调用
print(p.money)  # 10
print(Person.money)  # 10


# 不同对象来修改对象属性
p1 = Person("特朗普", 60)
p2 = Person("金正恩", 30)
p1.age = 70
print(p1.age, p2.age)  # 70 30

# 修改类属性，则该类的所有对象访问该类属性的值都会改变
Person.money = 20
print(p1.money, p2.money)  # 20 20

Person.family.append("妹妹")
print(p1.family, p2.family)  # ['爸爸', '妈妈', '弟弟', '妹妹'] ['爸爸', '妈妈', '弟弟', '妹妹']










