


# 普通函数
# def fn1():
#     print("fn1函数")
#     return 100
#
# res = fn1()
# print(res)  # 100


# 函数嵌套, 外部函数fn2的返回值是内部函数fn3
def fn2(a):
    print("fn2函数, a=", a)
    def fn3(b):
        print("fn3函数, b=", b)
    return fn3

# f3 = fn2()  # f3 = fn3
# f3()  # 相当于fn3()
# fn2()()

# 传参
# fn2(10)(20)  # a=10, b=20


# 局部变量: 不会被污染（不会被外部修改），会被回收
def fn3():
    a = 10
    print("a=", a)

# fn3()
# print(a)  # 报错，a是局部变量,不可以被函数外部使用


# 全局变量:  会被污染（会被外部修改）, 不会被回收
b = 10
def fn4():
    global b
    b += 1
    print("b=", b)

# print(b)
# fn4()
# fn4()


# 闭包： 函数嵌套，内部函数使用外部函数的变量或参数，那么该变量或参数就不会被释放
# 特点： 外部函数的局部变量或参数不会被回收，不会被污染（不可以在外部修改）
def fn5():
    d = 10
    def fn6():
        nonlocal d
        d += 1
        print("d=", d)
    return fn6

f6 = fn5()  # f6 = fn6
f6()  # 11
f6()  # 12
f6()  # 13
# print(d)  # 报错


# 形成
def fx(a, b):
    def n(x):
        return a*x + b
    return n

f1 = fx(3, 4)  # f1 = n,  3x + 4
print(f1(5))   # 19, 3*5 + 4
print(f1(6))   # 22

f2 = fx(2, 3)  # 2x + 3
print(f2(9))  # 21





