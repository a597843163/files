
''''''

# 1. 输出10行内容，每行的内容都是“*****”。
for i in range(10):
    print("*****")

# 2. 输出10行内容，每行的内容都不一样，第1行一个星号，第2行2个星号，依此类推第10行10个星号。
for i in range(10):
    for j in range(i+1):
        print("*", end="")
    print()

# 3. 输出9行内容，第1行输出1，第2行输出12，第3行输出123，以此类推，第9行输出123456789。
for i in range(1, 10):
    for j in range(1, i+1):
        print(j, end="")
    print()
'''
1
12
123
1234
...
'''


# 4. 计算10个99相加后的值并输出。
sum = 0
for i in range(10):
    sum += 99
print(sum)

# 5. 计算从1加到100的值并输出。
sum = 0
for i in range(1, 101):
    sum += i
print(sum)

# 6. 计算10的阶乘（1x2x3x4x5x6x7x8x9x10）
s = 1
for i in range(1, 11):
    s *= i
print(s)

# 7. 计算2的20次方。不允许用**和pow()
# print(pow(2, 3))  # 8
s = 1
for i in range(20):
    s *= 2
print(s)

# 8. 计算从1到1000以内所有奇数的和并输出。
sum = 0
for i in range(1, 1001):
    if i%2 == 1:
        sum += i
print(sum)

# 9. 计算从1到1000以内所有能被3或者17整除的数的和并输出
sum = 0
for i in range(1, 1001):
    if i%3==0 or i%17==0:
        sum += i
print(sum)

# 10. 计算从1到1000以内所有能同时被3，5和7整除的数的和并输出
sum = 0
for i in range(1, 1001):
    if i%3==0 and i%5==0 and i%7==0:
        sum += i
print(sum)


# 11. 计算1到100以内能被7或者3整除但不能同时被这两者整除的数的个数。
count = 0
for i in range(1, 101):
    if i%7==0 and i%3!=0 or i%7!=0 and i%3==0:
    #if (i%7==0) ^ (i%3==0):  # ^ 相同为0， 不同为1
        count += 1
print(count)  # 39

# 12. 计算1到100以内能被7整除但不是偶数的数的个数。
count = 0
for i in range(1, 101):
    if i%7==0 and i%2!=0:
        count += 1
print(count)  # 7

# 13. 计算从1到100临近两个整数的合并依次输出。比如第一次输出3(1+2)，第二次输出5(2+3)，最后一次输出199(99+100)。
for i in range(1, 100):
    print(i + (i+1), "(%d+%d)"%(i,i+1), end=" ")
print()

# 14. 给定一个不大于9的数n，打印nn乘法表
n = 6
for i in range(1, n+1):
    for j in range(1, i+1):
        print(str(j) + "*" + str(i) + "=" + str(i*j), end="\t")
    print()

# 15. 给定一个n位（不超过10）的整数，将该数按位逆置，例如给定12345变成54321，12320变成2321.
n = 12320
str1 = str(n)
str2 = str1[::-1]
num = int(str2)
print(num)


# 16. 一球从100米高度自由落下，每次落地后反跳回原高度的一半，再落下。求它在第n次落地时，共经过多少米？
sum = 0
height = 100
n = 3
for i in range(1, n+1):
    if i == 1:
        sum += height
    else:
        sum += height * 2

    height /= 2

print(sum)

# 17. 已知 abc+cba=1333, 其中的a,b,c均为一位数，编写一个程序，求出a,b,c分别代表什么数字
for a in range(10):
    for b in range(10):
        for c in range(10):
            if a*100 + b*10 + c + c*100 + b*10 + a == 1333:
                print(a, b, c)

'''
4 1 9
5 1 8
6 1 7
7 1 6
8 1 5
9 1 4
'''




