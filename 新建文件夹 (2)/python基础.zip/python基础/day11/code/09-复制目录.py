
import os
#  1.遍历所有子目录和子文件
#  2.  如果在子目录，则创建相同名称的子目录
#      如果是子文件，则复制一个相同的子文件

#  复制目录
def copyDir(sourcePath,targetPath):
          if not os.path.exists(sourcePath):
              return "该目录不存在"
          if not os.path.exists(targetPath) :
              os.mkdir(targetPath)
          fileNameList = os.listdir(sourcePath)
          for fileName in fileNameList:
              sourceAbsPath = os.path.join(sourcePath,fileName)
              targetAbsPath = os.path.join(targetPath,fileName)
              if os.path.isfile(sourceAbsPath):
                  copyFile(sourceAbsPath,targetAbsPath)
              elif os.path.isdir(sourceAbsPath):
                  if not os.path.exists(targetAbsPath):
                        os.mkdir(targetAbsPath)
                  copyDir(sourceAbsPath,targetAbsPath)

#  复制文件
def copyFile(sourceFilePath,targetFilePath):
        sourceFp = open(sourceFilePath,"rb")
        targetFp = open(targetFilePath,"ab")

        while True:
            content = sourceFp.read(1024)
            if len(content) == 0 :
                break
            targetFp.write(content)
        sourceFp.close()
        targetFp.close()

if __name__ == "__main__":
    sPath = r"F:\python千峰课件\day10"
    tPath = r"F:\python千峰课件\day10副本"
    copyDir(sPath,tPath)








