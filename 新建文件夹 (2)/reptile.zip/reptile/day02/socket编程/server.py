import queue
import socket, threading


# 创建一个socket对象
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定ip和端口
server.bind(('10.36.137.63', 10201))

# 监听
server.listen(5)

# 创建一个事件
event1 = threading.Event()
event2 = threading.Event()


# 客户端1
def echo(id,client_socket,q):
    while True:
        # 拿到每一个线程对应发送的内容,进行线程通信
        data = client_socket.recv(1024)
        # 接受到的信息，加入到队列里面去
        q.put(data)
        event1.set()
        print('客户端说：', data.decode('utf-8'))
        event2.clear()
        event2.wait()
        value = q.get(timeout=5)
        client_socket.send(value)

# 客户端2
def send(id,client_socket,q):
    while True:
        event1.clear()
        event1.wait()
        value = q.get(timeout=5)
        client_socket.send(value)
        # 发送完之后，客户端2会发送信息过来，服务端需要接受
        data = client_socket.recv(1024)
        q.put(data)
        event2.set()

# 开始接收客户端的请求
clients = []
while True:
    client_socket, client_address = server.accept()
    clients.append(client_socket)
    print('服务器已经开启')
    q = queue.Queue()
    if len(clients) == 2:
        t1 = threading.Thread(target=echo, args=(1, clients[0], q))
        t2 = threading.Thread(target=send, args=(2, clients[1], q))
        t1.start()
        t2.start()




