from django.conf.urls import url
from .views import *

urlpatterns = [
    url(r'^home/$', home, name='home'),
    url(r'^home_logined/$', home_logined, name='home_logined'),
    url(r'^homeloginedcollected/$', home_logined_collected, name='home_logined_collected'),
    url(r'^login/$', login, name='login'),
    url(r'^register/$', register, name='register'),
    url(r'^userinfomod/$', userinfo_mod, name='userinfo_mod'),
    url(r'^logout/$', logout, name='logout'),

]