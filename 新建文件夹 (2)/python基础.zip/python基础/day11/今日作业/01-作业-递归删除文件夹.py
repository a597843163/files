''''''
import os
# 递归删除文件夹(可能包含子文件或子文件夹)
# 提示：要先将文件夹中的所有子文件删除再删除本文件夹
# remove()
# rmdir()
#
'''
def dedir(sourceDir):
    if not os.path.exists(sourceDir):
        return "该目录不存在"
    fileNameList = os.listdir(sourceDir)
    if len(fileNameList) == 0 :
        os.rmdir(sourceDir)
    for filename in fileNameList:    #  得到文件名字
        absPath = os.path.join(sourceDir,filename)   #得到文件路径
        if os.path.isfile(absPath):    #  是文件就删除
            os.remove(absPath)
        elif os.path.isdir(absPath):   #  是文件夹就递归
            dedir(absPath)
while True:
    if __name__ == "__main__":
        path = r"F:\python千峰课件\day10副本"
        if not os.path.exists(path):
            break
        dedir(path)
'''





def dedir(sourceDir):
    if not os.path.exists(sourceDir):
        return "该目录不存在"
    fileNameList = os.listdir(sourceDir)
    if len(fileNameList) == 0 :
        os.rmdir(sourceDir)
    for filename in fileNameList:    #  得到文件名字
        absPath = os.path.join(sourceDir,filename)   #得到文件路径
        if os.path.isfile(absPath):    #  是文件就删除
            os.remove(absPath)
        elif os.path.isdir(absPath):   #  是文件夹就递归
            dedir(absPath)
    else:
        dedir(sourceDir)

if __name__ == "__main__":
     path = r"F:\python千峰课件\day10副本"
     dedir(path)




