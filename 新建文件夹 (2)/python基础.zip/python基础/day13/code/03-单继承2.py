



# Ipod, Iphone

# Ipod :
#   属性：颜色，大小
#   方法：听音乐

# Iphone :
#   属性：颜色，大小，价格
#   方法：听音乐，看电影，打电话
#

# 私有属性和私有方法： 在类内部可以使用，在其他类中不可以使用（子类中也不可以使用）
#

# 父类
# Ipod
class Ipod(object):
    def __init__(self, color, size):
        self.color = color
        self.__size = size

    def listenMusic(self):
        print("听音乐")
        print(self.__size)
    def __getMyColor(self):  # 私有方法
        return self.color

# 子类
# Iphone
class Iphone(Ipod):
    def __init__(self, color, size, price):
        super().__init__(color, size)
        self.price = price

    def watchMoive(self):
        print("看电影")
    def call(self):
        print("打电话")
        print(self.color)  # 黑色
        # print(self.__size)   # 报错


# 创建子类对象
iphoneX = Iphone("黑色", 5.8, 7000)
print(iphoneX.color, iphoneX.price)
iphoneX.listenMusic()
iphoneX.watchMoive()
iphoneX.call()
# print(iphoneX.__size)  # 报错
# print(iphoneX._Ipod__size)  # 5.8， 不推荐
# print(iphoneX.__getMyColor())  # 报错




# 继承的过程： 从范围大的到范围小的，从一般到特殊
#       父类：  人  ，    动物（包含的是所有动物的共有属性）
#       子类： 男人 ，   狗，猫，鱼





