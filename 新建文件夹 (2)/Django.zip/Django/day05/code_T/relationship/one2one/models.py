from django.db import models


class IdCard(models.Model):
    num = models.IntegerField()

    def __str__(self):
        return str(self.num)


# 自己定制不同的Manager，每个Manager有自己的功能
# 修改默认的manager查询集
class FemalePersonManager(models.Manager):
    # 重写get_queryset()方法
    def get_queryset(self):
        return super().get_queryset().filter(name__endswith='1')


class ManPersonManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(name__endswith='2')

    def man_count(self):
        return self.all().count()


class Person(models.Model):
    name = models.CharField(max_length=30)
    idcard = models.OneToOneField(IdCard)

    # 把manager对象的名字改为obj，之前的objects不可以再使用
    # obj = models.Manager()

    female = FemalePersonManager()
    man = ManPersonManager()
    objects = models.Manager()

    
    def __str__(self):
        return self.name


