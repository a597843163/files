from flask_wtf import FlaskForm
from flask_wtf.file import FileRequired, FileAllowed
from wtforms import StringField, PasswordField, SubmitField, FileField
from wtforms.validators import DataRequired,Email,Length,EqualTo,ValidationError
from app.models import User #导入user模型类
from app.extensions import file

# 注册的表单
class Register(FlaskForm):
    '''
    用户名
    密码
    确认密码
    输入邮箱
    点击注册
    '''
    username = StringField('用户名',validators=[DataRequired('用户名不能为空'),Length(min=6,max=12,message='用户名长度为6-12位')])
    password = PasswordField('密码', validators=[DataRequired('密码不能为空'), Length(min=6, max=10, message='密码长度为6-10位')])
    confirm = PasswordField('确认密码', validators=[DataRequired('密码不能为空'),EqualTo('password',message='密码和确认密码不一致')])
    # 如果想让密码或者用户名输入最大长度，查询input属性
    email = StringField('邮箱',validators=[DataRequired(message='邮箱不能为空'),Email(message='请输入正确的邮箱')])
    submit = SubmitField('注册')

    # 自定义判断用户名和密码是否存在的验证器 如果存在，则提示用户已存在
    def validata_username(self,field):
        if User.query.filter(User.username==field.data).first():
            raise ValidationError("该用户已存在，请重新输入")

    def validata_email(self,field):
        if User.query.filter(User.email==field.data).first():
            raise ValidationError("该邮箱已被占用，请重新输入")

# 用户登陆的表单
class Login(FlaskForm):
    username = StringField('用户名',validators=[DataRequired(message='用户名不能为空')])
    password = PasswordField('密码', validators=[DataRequired(message='密码不能为空')])
    submit = SubmitField('登录')

# 修改密码的表单
class ChangePassword(FlaskForm):
    oldpassword = PasswordField('旧密码', validators=[DataRequired(message='密码不能为空')])
    newpassword = PasswordField('新密码', validators=[DataRequired(message='密码不能为空'),Length(min=6, max=10, message='密码长度为6-10位')])
    confirm = PasswordField('请确认新密码', validators=[DataRequired('密码不能为空'),EqualTo('newpassword',message='密码和确认密码不一致')])
    submit = SubmitField('修改密码')

# 修改邮箱的表单
class Changeemail(FlaskForm):
    password = PasswordField('请输入您的密码', validators=[DataRequired(message='密码不能为空')])
    new_email = StringField('请输入您的新邮箱',validators=[DataRequired(message='邮箱不能为空'),Email(message='请输入正确的邮箱')])
    submit = SubmitField('修改邮箱')

# 上传头像的表单
class UploadForm(FlaskForm):
    icon = FileField('修改头像',validators=[FileRequired('请选择文件..'),FileAllowed(file,message='只能上传图片')])
    submit = SubmitField('上传图片')



