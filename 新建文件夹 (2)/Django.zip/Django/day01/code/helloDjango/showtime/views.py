from django.shortcuts import render
from django.http import HttpResponse
import datetime
# Create your views here.

def showTime(request):
    return HttpResponse('当前时间是:%s' % datetime.datetime.now())

def index2(request):
    names = ["宝强","贾乃绿","马云","马化腾"]
    # 渲染页面(index.html)
    return render(request,'index.html',{'names':names})


