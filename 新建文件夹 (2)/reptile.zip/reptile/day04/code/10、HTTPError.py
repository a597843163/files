import urllib.request
import urllib.parse
from urllib.error import URLError, HTTPError
import ssl

ssl._create_default_https_context = ssl._create_unverified_context

url = 'https://blog.csdn.net/blogdevteam/article/details/8052903'

try:
    response = urllib.request.urlopen(url=url)
except HTTPError as e:
    print(100)
    print(e)
except URLError as e:
    print(200)
    print(e)

print(response.read().decode('utf-8'))


