from app.extensions import db
from datetime import datetime
class Posts(db.Model):
    __tablename__ = 'posts'
    id = db.Column(db.Integer,primary_key=True)
    content = db.Column(db.Text) #帖子和评论回复的字段
    pid = db.Column(db.Integer,default=0) #帖子的父id，如果是发帖子则为0
    path = db.Column(db.String(50),default='0,')
    timestamp = db.Column(db.DateTime,default=datetime.utcnow)#记录时间的
    #创建外键  关联的 user表的id
    uid = db.Column(db.Integer,db.ForeignKey('user.id'))
