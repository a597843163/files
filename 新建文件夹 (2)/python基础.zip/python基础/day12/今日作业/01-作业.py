
import math
# 1, 将今天的课堂代码写2遍

# 2、设计一个圆类，属性：半径，方法：计算圆的面积和周长
class Circular(object):
    def __init__(self,radius):
        self.radius = radius
        self.pi     = math.pi
    def meter(self):
        meter = self.pi*self.radius*2
        return meter
    def area(self):
         area = self.pi*self.radius**2
         return area

circular = Circular(4)
print(circular.meter())
print(circular.area())

# 3、设计一个长方形类，属性:长，宽， 方法：计算面积和周长
class LongShape(object):
    def __init__(self,long,wide):
        self.long = long
        self.wide = wide
    def meter(self):
        meter = (self.long + self.wide)*2
        return meter
    def area(self):
         area = self.long*self.wide
         return area

longshape = LongShape(10,10)
print(longshape.meter())
print(longshape.area())

# 4、模拟汽车跑在公路上,计算所需时间
# 	汽车Car：属性：速度speed， 方法：可以在公路上跑runOnRoad(self, road)
# 	公路Road：属性：长度length

class Rode(object):
    def __init__(self,lenth):
        self.lenth = lenth

    def lenth(self):
        return self.lenth

class Car(object):
    def __init__(self,speed,rode):
        self.rode  = rode
        self.speed = speed

    def runOnRoad(self):
        time = self.rode.lenth /self.speed
        return  time

# 创建对象
rode = Rode(10000)
car = Car(50,rode)

# 执行对象
print(car.runOnRoad())







