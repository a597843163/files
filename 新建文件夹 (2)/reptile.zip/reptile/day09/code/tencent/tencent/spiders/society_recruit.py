# -*- coding: utf-8 -*-
import scrapy
from tencent.items import TencentItem

class SocietyRecruitSpider(scrapy.Spider):
    name = 'society_recruit'
    allowed_domains = ['tencent.com']
    start_urls = ['https://hr.tencent.com/position.php?lid=2218']

    def parse(self, response):
        tr_list = response.xpath('//tr[@class="even"] | //tr[@class="odd"]')
        for tr in tr_list:
            job_name = tr.xpath('.//a/text()').extract_first()
            category = tr.xpath('./td[2]/text()').extract_first()
            number = tr.xpath('./td[3]/text()').extract_first()
            location = tr.xpath('./td[4]/text()').extract_first()
            publication_data = tr.xpath('./td[5]/text()').extract_first()
            item = TencentItem()
            item['job_name'] = job_name
            item['category'] = category
            item['number'] = number
            item['location'] = location
            item['publication_data'] = publication_data
            yield item

        # 爬多页
        for page in range(1,200):
            url = 'https://hr.tencent.com/position.php?keywords=&lid=2218&start=%d#a' % (page*10)
            # 返回一个回调函数
            yield  scrapy.Request(url,callback=self.parse)
