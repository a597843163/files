## 删除表所有的数据

1. delete from 表名 
2. truncate 表名

**区别:**

​	delete 删除表所有的数据  再次添加数据的时候  主键自增 会在原有的基础上 继续自增

​	truncate  会将cpszs 主键自增归位 也就是 再次添加数据 从1开始递增

### 修改表的自增的值

alter table 表名 auto_increment = 1 #再次从1 开始递增



### group by 分组

select sex,count(*) from user group by sex  #按照性别分组 并统计有多少人

select class,count(*) as person from user group by class; #统计 每个班级 有多少人

select class,sex,count(*) as person from user group by class,sex;  #统计每个班的男生和女生分别有多少人

##### having 相当于 where

select class,sex,count(*) as person from user group by class,sex having person>10; #查询 人数 在10个以上的男生或女生

 select class,count(*) as person from user group by class having person>50; #查询50人 以上的班级

select classid,sex,count(*) p from a group by classid,sex having classid in('python1708','python1707') and p>2;

select classid,count(*) as t from a group by classid having classid in('python1706','python1707') and t>1; #统计classid为 1706或者1707 的 人数大于1人的p

### like 模糊查询

##### '%字符%'  包含某个字符

##### ‘字符%’  以什么字符作为开头

##### '%字符' 以什么字符作为 结尾

select * from 表名 where 字段 like ‘%字符%’  #查询 某个字段中 包含 某个字符的所有数据

select name,age from user where name like '%王%' order by age desc limit 0,5;  #查询 姓名包含王字的年龄最大的5条数据

select * from user where name like '%王%'and age>18 order by id desc limit 5; #查询 姓名包含王字的姓名 并且年龄大于18 降序排列 取5条数据



### DELETE 删除 (如果没有where 默认删除所有数据)

delete from 表名 where 条件



### UPDATE 修改(如果没有条件 默认修改所有的数据)

update 表名 set 字段名=字段值,,,  where 条件



### DISTINCT 去除重复数据

select distinct 字段名 from 表名

select age from user group by age   #查询去除重复数据的年龄



### 多表联查

##### (1) 隐式内链接

​	select * from 表1,表2 where 表1.字段名 =  表2.字段名

​	select u.id,u.name,info.email,info.address from user u,userinfo info where u.id=info.uid 查询俩个表里的某些字段

##### (2) 显式内链接

​	select * from 表1 inner join 表2 on 表1.字段名 = 表2.字段名

​	

##### (3) left join 左链接

​	select * from userinfo u LEFT JOIN user info on u.uid=info.id

###### 	注意:

​		以左表位主表 右表为辅表  会把主表的数据全部查出来  辅表的数据有对应的就查出来 没有 就以null来补全

##### (4) right join 右链接

​	select * from userinfo u right JOIN user info on u.uid=info.id

​	注意:

​		以右表位主表 左表为辅表  会把主表的数据全部查出来  辅表的数据有对应的就查出来 没有 就以null来补全

### MySQL的聚合函数

1. count()  统计个数
2. max() 最大的
3. min() 最小的
4. sum() 求和
5. avg() 求平均数



### 数据库的导入导出

##### (1)导入

​	mysql -uroot -p 库名<demo.sql  

##### (2)导出

​	mysqldump -uroot -p 库名>demo.sql





### 以下作为了解

#### 修改密码

#### 方法1 用SET PASSWORD命令

set password for 用户名@loclhost = passworsd('新密码');

#### 方法2 用UPDATE直接编辑user表

1. 首先登录MySQL。
2. 连接权限数据库： use mysql; 。
3. 改密码：update user set password=password("shapolang") where user="root";（别忘了最后加分号） 
4. 刷新权限（必须步骤）：flush privileges;

重新登录，输入新密码shapolang就ok了；

##### (1) 使用 mysql库 

​	use mysql

##### (2) 查看当前数据库下有 哪些用户

​	select user from user

##### (3)创建用户

​	create user lisi identified by '123456';

##### (4) 修改用户名

​	rename user lisi to wangwu;

##### (5) 赋予权限

​	grant all on demo.* to wangwu;

​	all 所有的权限

​	select,update  赋予 查 和改的权限

##### (6)  回收权限

​	 revoke all on demo.* from wangwu;

##### (7) 删除用户

​	drop user wangwu

##### (8) 刷新

​	flush privileges

### 无限极分类

 select * from type order by concat(path,id); #concat 将字段 链接在一起

| id   | pid  | typename     | path   |
| ---- | ---- | ------------ | ------ |
| 1    | 0    | movie        | 0,     |
| 2    | 1    | japanmovie   | 0,1,   |
| 3    | 1    | 美国movie      | 0,1,   |
| 7    | 1    | Chinesemovie | 0,1    |
| 4    | 0    | 衣服           | 0,     |
| 5    | 4    | 内衣           | 0,4,   |
| 6    | 5    | 红豆           | 0,4,5, |

