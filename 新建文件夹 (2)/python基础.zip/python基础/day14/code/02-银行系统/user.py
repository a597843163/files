


#  用户
#  User
#    属性： 姓名，身份证号，手机号码，持有银行卡

class User(object):
    def __init__(self, name, idcard, phone, card):
        self.name = name
        self.idcard = idcard
        self.phone = phone
        self.card = card  # 银行卡对象

    def __str__(self):
        return "姓名:%s  身份证:%s  手机号:%s  银行卡号:%s" % (self.name, self.idcard, self.phone, self.card.cardId)







