''''''


#
# 题目：创建函数， 从文件guishudi.txt中获取数据，
#       输入完整手机号11位，匹配前7位，输出对应的地址和卡类型
#
# 60268|1340475|0431|吉林省长春市|吉林移动大众卡
#   手机号前7位 ：1340475
#

def fn(phoneStr):
    phoneStr = phoneStr[:7]
    # print(phoneStr)

    # 获取文件中的数据
    fp = open(r"C:\wamp\www\day11\昨日作业\guishudi.txt", "r", encoding="utf-8")
    lineList = fp.readlines()
    fp.close()

    # 遍历每一行数据,找到匹配的手机号
    for lineStr in lineList:
        list1 = lineStr.split("|")
        if list1[1] == phoneStr:
            return list1[3], list1[4]


print(fn("18601119999"))






