import time

from flask import Flask, make_response, redirect, url_for, abort, request, session,current_app

# 创建flask的应用
app = Flask(__name__)
app.var = '我给app对象添加了一个属性'
# 路由   @flask对象.route(/url地址/)
# 1. 无参数路由
@app.route('/test/')  # 在请求当前路由的时候，如果需要/的时候，浏览器自动补全
def index():
    # 必须要有响应给请求
    print(current_app.var)  # app的一个分身
    return '<h1>Hello World<h1>'

# 2. 带参数路由
# http://127.0.0.1:5001/welcome/lisi
@app.route('/welcome/<name>')
def welcome(name):  # 接收的参数都是string
    return '欢迎{}'.format(name)

# 3.指定参数类型
# 1.str (deafult)
# 2.int
# 3.float
# 4. path
# @app.route('/argtype/<int:uid>')
@app.route('/argtype/<path:uid>')
def argtype(uid):
    return '参数类型'

# 4.多个参数路由
@app.route('/manyarg/<a>/<b>/')
def manyarg(a,b):
    print(a,b)
    return '接收多个参数'


# 五、路由响应
# 响应404状态码
@app.route('/res/')
def res():
    # 可以指定返回的状态码
    # return 'page not found',404
    # 可以通过make_response构造响应
    response = make_response('通过make_response进行的响应',404)
    print(response)
    return response
# 请求是成功的，但是你可以指定返回的请求状态码

# 六、 redirect重定向
# redirect  无参数
@app.route('/redirect/')
def redir():
    return redirect('/test/')

# redirect+url_for  # 有参数知道函数名,跳转
@app.route('/redirect1/')
def redir1():
    return redirect(url_for('argtype',uid='abc'))


#   abort 抛出异常，相当于raise
@app.route('/res1/')
def res1():
    # 抛出404异常
    abort(404)
    # 后面代码不会执行
    response = make_response('通过make_response进行的响应',404)
    print(response)
    return response

# 捕获异常 ,出现异常的时候显示的页面
@app.errorhandler(404)
def serverError(e):
    return '捕获异常页面'

# request请求的属性
@app.route('/request/')
def req():
    #http://127.0.0.1:5001/request/?name=lisi&age=18
    print('请求的完整url',request.url)
    print('去掉get传参的路由',request.base_url)
    print(' 获取只有主机IP和端口号的url',request.host_url)
    print(' 获取路由地址',request.path)
    print(' 获取请求方法',request.method)
    print(' 获取通过get传递过来的参数',request.args)
    print(' 获取通过get传递过来的参数',request.args['name'])
    print(' 用于文件上传',request.files)
    print(' 获取请求过来的头信息',request.headers['User-Agent'])
    return 'request对象的使用'

@app.route('/getarg/')
def getarg():
    print('name的值为:',request.args.get('name'))
    print('age的值为',request.args.get('age','你是不是傻？有age吗'))
    print('age的值为',request.args.getlist('name'))
    return '获取get传参'


# 会话控制 cookie和session
# 设置cookie=  参数1,设置cookie的键 ，参数2，设置当前键的值
# 参数3，以秒为单位的过期时间，参数4，失效时间  如果没设置，默认关闭浏览器就清楚
# 参数5 cookie的有效路径

# cookie设置
@app.route('/set_cookie/')
def set_cookie():
    response = make_response('设置cookie')  # 创建response对象
    # 设置cookie
    expires = time.time()+10
    response.set_cookie('name',value='zhangsan',max_age=None,expires=expires,path='/')
    return response

# 获取cookie
@app.route('/get_cookie/')
def get_cookid():
    return request.cookies.get('name','没有值')

@app.route('/del_cookie/')
def del_cookie():
    response = make_response('删除cookie')
    response.delete_cookie('name')  # 删除key为name的cookie
    return response

# session操作
# 设置session
app = Flask(__name__)
# 先设置session加密方式
app.secret_key = 'ajhsd'
# 设置session
@app.route('/set_session/')
def set_session():
    session['uid'] = 1
    return 'session设置成功'

# 获取session
@app.route('/get_session/')
def get_session():
    print(session['uid'])  #  不存在报错
    print(session.get(['uid'])) # 不存在不报错

    return '获取session的值为{}'.format(session['uid'])





if __name__ == '__main__':
    print(app)
    # 将当前的flask运行服务器
    app.run(host='0.0.0.0',port='5001',debug=True,threaded=True) #(threaded线程开启)



