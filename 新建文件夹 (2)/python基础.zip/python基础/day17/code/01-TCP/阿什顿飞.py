

import socket

serverSockt = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

serverSockt.bind(("10.36.137.48",8553))

serverSockt.listen(5)

clientSocket,adress = serverSockt.accept()

while True:
    recvData = clientSocket.recv(1024)
    print("客户端说:",recvData.decode("utf-8"))

    sendData = input("我说:")
    clientSocket.send(sendData.encode("utf-8"))


serverSockt = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

serverSockt.connect(("10.36.137.48",8553))

while True:

    sendData = input("客户端说:")
    clientSocket.send(sendData.encode("utf-8"))

    recvData = clientSocket.recv(1024)




