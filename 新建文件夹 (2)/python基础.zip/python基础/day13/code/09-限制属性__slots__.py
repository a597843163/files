


class Person(object):

    # __slots__ 表示要限制的属性， 是一个特殊的值，会自动被使用
    __slots__ = ("name", "age", "sex", "aa", "qq")

    def __init__(self, name, age, sex):
        self.name = name
        self.age = age
        self.sex = sex
        # self.money = 10  # 报错 不允许使用的属性


p = Person("霍金", 76, "男")
print(p.name)
print(p.age)
print(p.sex)




