from django.test import TestCase

# Create your tests here.

# 测试代码