def a():
    pass

a(1)