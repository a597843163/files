

#  copy() : 复制

# 没有复制
list1 = [1, 2, 3]
list2 = list1
list2[0] = 99
print(list1)  # [99, 2, 3]
print(list2)  # [99, 2, 3]


# 复制
list1 = [1, 2, 3]
list2 = list1.copy()  # 浅复制
list2[0] = 99
print(list1)  # [1, 2, 3]
print(list2)  # [99, 2, 3]


list1 = [1, [2, 3], 4]
list2 = list1.copy()  # 浅复制
list2[1][0] = 99
print(list1)  # [1, [99, 3], 4]
print(list2)  # [1, [99, 3], 4]


import copy
list1 = [1, [2, 3], 4]
list2 = copy.deepcopy(list1)  # 深复制
list2[1][0] = 99
print(list1)  # [1, [2, 3], 4]
print(list2)  # [1, [99, 3], 4]


