from django.conf.urls import url
from .views import *

urlpatterns = [
    url(r'^index/(\d+)/$',index,name='index'),

]# 位置参数