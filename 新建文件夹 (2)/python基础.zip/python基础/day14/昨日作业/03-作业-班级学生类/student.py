

# 	学生类：
# 		属性：姓名，年龄，性别，成绩，学号


class Student(object):
    def __init__(self, name, age, sex, score, stuno):
        self.name = name
        self.age = age
        self.sex = sex
        self.score = score
        self.stuno = stuno

    def __str__(self):
        return "姓名:%s  年龄:%d  性别:%s  成绩:%d  学号:%d" % (self.name, self.age, self.sex, self.score, self.stuno)

