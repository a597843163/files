


'''
     时间： time,
        UTC: 国际标准时间，国际协调时间， 格林尼治时间（英国伦敦的一个郊区的地名）
            根据1970年1月1日0点0分0秒到指定时间的时间差（毫秒）
        时间戳： 指定的时间和1970年的时间相差的毫秒数
        DST(夏令时): 在夏季时间会提前一个小时

        中国时间： 东八区，比UTC国际时间快8小时


    时间的表现形式：

        时间戳： 指定的时间和1970年的时间相差的毫秒数
                如： 1520477192.808

        时间元组：
            # time.struct_time(tm_year=2018, tm_mon=3, tm_mday=8,
                                tm_hour=2, tm_min=53, tm_sec=25,
                                tm_wday=3, tm_yday=67, tm_isdst=0)
            tm_year: 年
            tm_mon： 月 1-12
            tm_mday：天 1-31
            tm_hour：时 0-23
            tm_min： 分 0-59
            tm_sec： 秒 0-59

            tm_wday： 一周中的第几天, 0-6,周一是0
            tm_yday： 一年中的第几天，1-366
            tm_isdst： 是否是夏令时

        时间字符串：
            %y 两位数的年份表示（00-99）
            %Y 四位数的年份表示（000-9999）
            %m 月份（01-12）
            %d 月内中的一天（0-31）
            %H 24小时制小时数（0-23）
            %I 12小时制小时数（01-12）
            %M 分钟数（00-59）
            %S 秒（00-59）

            %a 本地简化星期名称
            %A 本地完整星期名称
            %b 本地简化的月份名称
            %B 本地完整的月份名称
            %c 本地相应的日期表示和时间表示
            %j 年内的一天（001-366）
            %p 本地A.M.或P.M.的等价符
            %U 一年中的星期数（00-53）星期天为星期的开始
            %w 星期（0-6），星期天为星期的开始
            %W 一年中的星期数（00-53）星期一为星期的开始
            %x 本地相应的日期表示
            %X 本地相应的时间表示
            %Z 当前时区的名称
            %% %号本身


'''

import time

# time()获取当前时间的时间戳
t = time.time()
print(t)
# 时间戳
# 1520477192.808

# gmtime(): 将时间戳 转换成 时间元组 （UTC）
# t1 = time.gmtime()  # 当前时间的时间元组
t1 = time.gmtime(t)  # 获取指定时间戳的时间元组
print(t1)
print(t1[0])  # 2018 年
print(t1[1])  # 3   月
# time.struct_time(tm_year=2018, tm_mon=3, tm_mday=8, tm_hour=3, tm_min=6, tm_sec=12, tm_wday=3, tm_yday=67, tm_isdst=0)

# localtime(): 将时间戳 转换成 时间元组 （中国标准时间UTC+8）
# t2 = time.localtime()  # 当前时间的时间元组
t2 = time.localtime(t)  # 获取指定时间戳的时间元组
print(t2,"这个打印")
# time.struct_time(tm_year=2018, tm_mon=3, tm_mday=8, tm_hour=11, tm_min=6, tm_sec=12, tm_wday=3, tm_yday=67, tm_isdst=0)


# 昨天的时间
yesterday = time.time() - 60*60*24
print(yesterday)
print(time.localtime(yesterday))


# mktime() : 将时间元组 转换成 时间戳
t3 = time.localtime()
s = time.mktime(t3)
print(s)  # 1520478784.0




# strftime() ： 将时间元组 转换成 时间格式字符串
t4 = time.localtime()
# str1 = time.strftime("%Y-%m-%d %H:%M:%S", t4)  # 2018-03-08 11:20:45
# str1 = time.strftime("%Y-%m-%d", t4)   # 2018-03-08
str1 = time.strftime("%x %X", t4)   # 03/08/18 11:26:38
print(str1,'这个打印')
print(type(str1))   # <class 'str'>

year = time.strftime("%Y", t4)  # 2018
month = time.strftime("%m", t4)  # 03
day = time.strftime("%d", t4)  # 08
print(year, month, day)  # 2018 03 08
print(type(year))  # <class 'str'>

# 中文
# str1 = time.strftime("%Y年%m月%d日 %H时%M分%S秒")  # 报错
str1 = time.strftime("%Y{y}%m{m}%d{d}", t4).format(y="年", m="月", d="日")
print(str1)  # 2018年03月08日


# strptime() : 将时间格式的字符串 转换成 时间元组
t4 = time.strptime("2019-11-11 11:11:11", "%Y-%m-%d %H:%M:%S")
print(t4)
# time.struct_time(tm_year=2019, tm_mon=11, tm_mday=11, tm_hour=11, tm_min=11, tm_sec=11, tm_wday=0, tm_yday=315, tm_isdst=-1)

# 中文
# t4 = time.strptime("2011年11月11日", "%Y年%m月%d日")
t4 = time.strptime("2011年11月11日", "%Y{y}%m{m}%d{d}".format(y="年", m="月", d="日"))
print(t4)
# time.struct_time(tm_year=2011, tm_mon=11, tm_mday=11, tm_hour=0, tm_min=0, tm_sec=0, tm_wday=4, tm_yday=315, tm_isdst=-1)



# asctime() : 将 时间元组 转换成 时间字符串
t5 = time.localtime()
str2 = time.asctime(t5)
print(str2)  # 'Thu Mar  8 11:40:44 2018'

# ctime() : 将 时间戳 转换成 时间字符串
t6 = time.time()
str3 = time.ctime(t6)
print(str3)  # 'Thu Mar  8 11:42:40 2018'




