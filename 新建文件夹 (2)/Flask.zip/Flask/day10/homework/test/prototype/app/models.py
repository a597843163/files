from 机试.原型.manage import db


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(15), unique=True)
    password = db.Column(db.String(20))
    icon = db.Column(db.String(80), default='default.jpg')