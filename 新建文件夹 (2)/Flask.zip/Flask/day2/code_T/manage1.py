from flask import Flask,session,redirect,url_for,request,abort
from datetime import timedelta
from flask_script import Manager
app = Flask(__name__)
app.secret_key = 'abcdef'
manager = Manager(app)


@app.route('/')
def index():
    return redirect(url_for('user.login'))
@app.route('/test/')
def test():
    return 'test函数'

#设置session并设置过期时间
@app.route('/set_session/')
def set_session():
    session.permanent = True #设置session持久化
    app.permanent_session_lifetime = timedelta(minutes=5) #设置session的过期时间为5分钟    timedelta表示时间的差值
    session['key'] = 'value'
    return '设置了session的过期时间'

#删除session
@app.route('/del_session/')
def del_session():
    # session.pop('key') #删除某一个key的值
    # session.clear() #删除所有的session
    return '删除session键为key的值'

#获取session
@app.route('/get_session/')
def get_session():
    return '获取key的值为{}'.format(session.get('key'))



@app.route('/form/')
def form():
    return 'form表单'


from user import user
# app.register_blueprint(user) #注册蓝本
app.register_blueprint(user,url_prefix='/user') #注册蓝本 并添加当前蓝本的前缀


# @app.before_first_request
# def before_first_request():
#     print('before_first_request')
#
# @app.before_request
# def before_request():
#     if request.method == 'GET' and request.path == '/form/':
#         abort(404)
#     print(request.path)
#     # print('before_request')
#
# @app.after_request
# def after_request(response):
#     print('after_request')
#     return response
# @app.teardown_request
# def teardown_request(response):
#     print('teardown_request')


if __name__ == '__main__':
    # app.run()
    manager.run()

