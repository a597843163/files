# day06

### 爬取58同城租房数据



### requests

Requests 唯一的一个**非转基因**的 Python HTTP 库，人类可以安全享用。 

官方文档：http://cn.python-requests.org/zh_CN/latest/

安装：pip install requests -i https://pypi.douban.com/simple

常用方法：

**get（带参数）**

```python
import requests

url = 'https://www.baidu.com/'

r = requests.get(url=url)

print(r.text)
# 查看网页编码
print(r.encoding)
# 设置网页编码方式
r.encoding = 'utf-8'

# 重新查看网页
# print(r.text)

# 带参数的get请求 ，以baidu搜索为例
url= 'https://www.baidu.com/s'

# 要搜索的关键字，是一个字典。不需要跟以往一样把中文编码
data = {
    'wd': '日本'
}
# 还可以定制头部, 也是个字典
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36'
}

r = requests.get(url=url, params=data, headers=headers)
print(r.text)
```

**响应常见属性**

| r.text        | 响应字符串类型 |
| ------------- | -------------- |
| r.encoding    | 编码方式       |
| r.url         | 请求的url      |
| r.content     | 响应的字节类型 |
| r.status_code | 响应状态码     |
| r.headers     | 响应的头部信息 |

**post**请求

```python
import requests


url = 'http://fanyi.baidu.com/sug'

data = {
    'kw': 'hello'
}

r = requests.post(url=url, data=data)
# 响应的字符串方式
print(r.text)
# 自动 将返回的json解码。
print(r.json())
```

**使用代理**

```python
import requests


url= 'https://www.baidu.com/s'


data = {
    'wd': 'ip'
}

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36'
}
# 代理也是一个字典。
proxy = {
    'https': '114.237.147.155:9999'
}
# 只需要传入proxies参数即可。
r = requests.get(url=url, params=data, headers=headers, proxies=proxy)

with open('daili.html', 'w', encoding='utf-8') as fp:
    fp.write(r.text)
```

**会话**

requests中使用session跟踪会话，session会自动记录cookie，相当于urllib和cookiejar结合。

在requests中使用session跟踪会话非常简单：

```python
import requests

# session自动记录cookie
session = requests.Session()

login_url = 'https://passport.weibo.cn/sso/login'

data = {
    'username': '18676689715',
    'password': 'xuke666',
    'savestate': '1',
    'r': 'http://weibo.cn/',
    'ec': '0',
    'pagerefer': '',
    'entry': 'mweibo',
    'wentry': '',
    'loginfrom': '',
    'client_id': '',
    'code': '',
    'qq': '',
    'mainpageflag': '1',
    'hff': '',
    'hfp': '',
}
headers = {
    'Host': 'passport.weibo.cn',
    'Connection': 'keep-alive',
    'Origin': 'https://passport.weibo.cn',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': '*/*',
    'Referer': 'https://passport.weibo.cn/signin/login?entry=mweibo&r=http%3A%2F%2Fweibo.cn%2F&backTitle=%CE%A2%B2%A9&vt=',
    'Accept-Language': 'zh-CN,zh;q=0.9',
}

session.post(url=login_url, data=data, headers=headers)

headers = {
'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
}
url = 'https://weibo.cn/2952685222/info'
# 访问个人信息页面
r = session.get(url=url, headers=headers)

print(r.text)
```

