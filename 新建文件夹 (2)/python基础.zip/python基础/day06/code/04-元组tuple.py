
'''
    元组tuple: 有序的集合，跟list相似，区别在于元组不可以被修改
        特点： 跟列表类似
              不可变类型
              list使用[], tuple使用()

'''

# 创建元组
tuple1 = ()
print(tuple1)  # (), 空元组
print(type(tuple1))  # <class 'tuple'>

# 创建一个只有一个元素的元组
# (): 既可以表示元组，也可以表示运算符的括号
tuple1 = (1,)
print(tuple1)  # (1,)
print(type(tuple1))  # <class 'tuple'>

# 创建带有多个元素的元组
# tuple1 = (11, 22, 33, 44)
tuple1 = (11, 22, "33", True)   # 可以存放不同类型的元素
print(tuple1)  # (11, 22, '33', True)


# 查
print(tuple1[2])  # '33'
print(tuple1[-3])  # 22
# print(tuple1[100])  # 下标越界

# index()
tuple1 = (11, 22, 33, 22)
print(tuple1.index(22))   # 1


# 增，删，修改：不可以对元组这样操作
tuple1 = (11, 22, 33, 22)
# tuple1[2] = 44   # 报错

# 注意： 元组是不可变类型，如果元组中包含了可变类型，则该可变类型可以修改
tuple1 = (11, 22, [33, 44], 22)
print(tuple1[2][0])  # 33
tuple1[2][0] = 55
print(tuple1)  # (11, 22, [55, 44], 22)




# 元组的基本基本操作
tuple1 = ("肖央", "宝强", "刘昊然")
tuple2 = ("阿香", "阿娇", "阿Sa")
tuple3 = tuple1 + tuple2
print(tuple3)  # ('肖央', '宝强', '刘昊然', '阿香', '阿娇', '阿Sa')

# * ： 乘法
print(tuple1*2)  # ('肖央', '宝强', '刘昊然', '肖央', '宝强', '刘昊然')

list1 = [1, 2, 3]
list2 = list1*1
list2.reverse()
print(list1)  # [1, 2, 3]
print(list2)  # [3, 2, 1]


# [:] : 截取元组
tuple1 = (1, 2, 3, 4, 5, 6, 7, 8)
print(tuple1[:])  # (1, 2, 3, 4, 5, 6, 7, 8)
print(tuple1[2:5])  # (3, 4, 5)
print(tuple1[::-1])  # (8, 7, 6, 5, 4, 3, 2, 1) 逆序


# in
print(3 in tuple1)  # True


# max(), min()
print(max(tuple1))  # 8
print(min(tuple1))  # 1


# 排序
# 升序
tuple1 = (1, 4, 2, 3, 6, 5, 7, 9, 8)
print(sorted(tuple1))  # [1, 2, 3, 4, 5, 6, 7, 8, 9]

# 降序
print(sorted(tuple1, reverse=True))  # [9, 8, 7, 6, 5, 4, 3, 2, 1]


# 一维元组
tuple1 = (1, 2, 3)

# 二维元组
tuple2 = ((1, 2, 3), (4, 5, 6), (7, 8, 9))

# 三维元组
tuple3 = (((1, 2, 3), (4, 5, 6), (7, 8, 9)), ((1, 2, 3), (4, 5, 6), (7, 8, 9)))


# 遍历元组
tuple1 = (11, 22, 33, 44, 55)
for i in tuple1:
    print(i)  # 值

for i in range(len(tuple1)):
    print(i, tuple1[i])  # 下标

# enumerate 枚举
for i, n in enumerate(tuple1):
    print(i, n)  # 下标， 值
