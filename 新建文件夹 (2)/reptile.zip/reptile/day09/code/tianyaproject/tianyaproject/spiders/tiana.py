# -*- coding: utf-8 -*-
import scrapy
import re
from tianyaproject.items import TianyaprojectItem


class TianySpider(scrapy.Spider):
    name = 'tiana'
    allowed_domains = ['bbs.tianya.cn']
    start_urls = ['http://bbs.tianya.cn/post-140-393977-1.shtml']

    def parse(self, response):
        # jly368@yahoo.com
        pattern = re.compile(r'[A-Z0-9][\w\-\.]+@[A-Z0-9]+\.[A-Z]{2,5}', re.I)
        email_list = pattern.findall(response.text)
        # emails = []
        for email in email_list:
            item = TianyaprojectItem()
            item['email']  = email
            # emails.append(item)
            yield  item


