fp = open("kaifanglist.txt","r",encoding="utf-8")
str1=fp.read()

#
# 题目： 开房查询
# 	创建函数，传入一个名字，查找到这哥们所有的开房记录，然后写入到以这哥们名字为名的txt文件中 如：张三.txt
#
#   名字分开  ，  信息分开
# # def fn(a):
# print(str1.count("孙旸"))      #判断出现次数，如果为1正常存，如果不为1，则value要加起来

# dict1 = {}
# list1 = str1.splitlines()
# for i in list1:
#     list2 = i.split(",")      #  以逗号拆分每一行
#     j = list2[0]       #      字典中的key就是j
#     list3 = list2[1:]
#     str2 = ",".join(list3)   #  得到key对应的value
#     dict1[j] = str2        # 存入字典
# print(dict1)

def fn(n) :
    str4 = n
    str2 = str1.splitlines()
    for i in str2:
        str3 = i.replace(",","[",1)
        list1 = str3.split("[")
        if n == list1[0]:
            str4 = str4 +"\n"+ list1[1]
    x = n + ".txt"
    fp = open(x, "w", encoding="utf-8")
    fp.write(str4)
    fp.close
fn("孙志涛")
fn("孙旸")
fp.close()