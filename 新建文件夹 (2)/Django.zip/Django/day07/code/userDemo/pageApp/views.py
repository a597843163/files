from django.shortcuts import render
from App.models import User
from django.core.paginator import Paginator


def index(request, page_num):
    # 获取所有数据
    user_list = User.objects.all()

    # paginator
    paginator = Paginator(user_list, 4)
    # print(paginator.count)  # 15, 表示数据总数量
    # print(paginator.num_pages)  # 5， 表示总共多少页
    # print(paginator.page_range)  # range(1, 6)， 表示[1,5]，页码的范围

    # page: 表示某一页的对象
    page = paginator.page(page_num)
    # object_list = page.object_list
    # number = page.number
    # print(object_list)  # 当前页的所有数据
    # print(number)  # 当前页的页码
    # print(page.has_next())  # True
    # print(page.has_previous())  # True
    # print(page.has_other_pages())  # True
    # print(page.next_page_number())  # 4
    # print(page.previous_page_number())  # 2
    # print(len(page))  # 3

    data = {
        'users': page.object_list,
        'page_range': paginator.page_range,
        'page': page,
    }

    return render(request, 'pageApp/index.html', data)

