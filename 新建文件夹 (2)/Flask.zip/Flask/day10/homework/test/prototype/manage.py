from flask import Flask, render_template
from flask_script import Manager
from app import register_blueprint


app = Flask(__name__)
register_blueprint(app)
manager = Manager(app)


if __name__ == '__main__':
    manager.run()

