from django.shortcuts import render
from .models import Author

# Create your views here.

def index(request):
    au_all = Author.objects.all()
    return render(request,'authors/index.html',{'au_all':au_all})

def authors(request,id1):
    au = Author.objects.get(id = id1)
    return render(request,'authors/detail.html',{'au' : au })


