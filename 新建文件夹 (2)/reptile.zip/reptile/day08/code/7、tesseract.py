import pytesseract
from PIL import Image
from  time import sleep

# image = Image.open('./en.png')
# image = Image.open('./QQ.png')
image = Image.open('../img/captcha.jpg')


# 对图片做一个灰度处理
image = image.convert('L')

data = image.load()

w, h = image.size

for i in range(w):
    for j in range(h):
        if data[i, j] > 50:
            data[i, j] = 255
        else:
            # 设成全黑
            data[i, j] = 0

sleep(5)
# image.show()

image.save('../img/self.jpg')


result = pytesseract.image_to_string(image)

print(result)


