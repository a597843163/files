


# 列表生成器
list1 = [i for i in range(1, 11)]
print(list1)  # [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# 生成器
#   将列表生成器的[]改成()即可
#  创建生成器不会一次性占用很多内存
generator = (i for i in range(1, 4))
print(generator)  # <generator object <genexpr> at 0x0000000001DF3E08>
print(type(generator))  # <class 'generator'>

# next() : 下一个， 不断获取下一个元素
#       如果超出范围，则会报错
# print(next(generator))  # 1
# print(next(generator))  # 2
# print(next(generator))  # 3
# print(next(generator))  # 报错

# forin循环遍历
for i in generator:
    print(i)



# 生成器函数: 包含yield的函数
def fn1(n):
    print("A")
    yield n+1
    print("B")
    yield n+2
    print("C")
    yield n+3

# 生成器函数在调用时不会执行代码，而是返回一个生成器对象
generator2 = fn1(10)
print(generator2)  # <generator object fn1 at 0x0000000001DE3F68>

# 每次调用next会返回yield后面的值
print(next(generator2))  # 11
print(next(generator2))  # 12
print(next(generator2))  # 13
# print(next(generator2))  # 报错


def fn2():
    for i in range(1, 101):
        yield i

generator3 = fn2()
print(next(generator3))  # 1
print(next(generator3))  # 2
print(next(generator3))  # 3









