# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import json
# from scrapy.utils. import
from scrapy.utils.project import get_project_settings
import pymysql


class DushuPipeline(object):
    def __init__(self):
        self.fp = open('./novel.txt', 'w', encoding='utf-8')

    def process_item(self, item, spider):
        self.fp.write(json.dumps(dict(item), ensure_ascii=False) + '\n')
        return item

    def close_spider(self, spider):
        self.fp.close()

class DushuMySqlPipeline(object):
    def __init__(self):
        settings = get_project_settings()
        self.host = settings.get('DB_HOST')
        self.port = settings.get('DB_PORT')
        self.user = settings.get('DB_USER')
        self.password = settings.get('DB_PASSWORD')
        self.db = settings.get('DB_DB')
        self.charset = settings.get('DB_CHARSET')
        self.conn = pymysql.connect(host=self.host, port=self.port, user=self.user, password=self.password, db=self.db, charset=self.charset)
        self.cursor = self.conn.cursor()

    def process_item(self, item, spider):
        sql = 'insert into novels(name, author, brief) values("%s", "%s", "%s")' % (item['name'], item['author'], item['brief'])
        self.cursor.execute(sql)
        self.conn.commit()
        return item

    def close_spider(self, spider):
        self.cursor.close()
        self.conn.close()