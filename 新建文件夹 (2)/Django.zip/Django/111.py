import re
text = 'ababababab'
print(re.findall('(?:ab.+?)',text))
