


# 类方法
# 静态方法

class Pig(object):

    data = "哈哈"

    def __init__(self, name):
        self.name = name

    # 成员方法
    def eat(self):
        print("我是吃货")


    # 类方法， 可以访问类属性,可以用类名.属性或者方法直接调用，且方法内部可以调用类属性，如Pig.data写成cls.data即可
    @classmethod
    def gong(cls):
        print("我喜欢拱白菜!")
        # print(self.name)  # 报错
        # print(cls)
        print(cls.data)  # 可以访问类属性

    # 静态方法， 不可以访问类属性 可以用类名.属性或者方法直接调用，不需要实例化对象即可调用
    @staticmethod
    def sleep():
        print("我爱睡觉")

# 对象
pig = Pig("八戒")

# 调用成员方法
pig.eat()
# Pig.eat()  # 报错

# 调用类方法
pig.gong()
Pig.gong()

# 调用静态方法
pig.sleep()
Pig.sleep()



