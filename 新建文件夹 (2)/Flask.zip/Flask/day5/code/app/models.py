from ext import db

# 添加1
# 添加多条
# 修改
# 删除
class NewModel():
    # 重新定义提交方法
    @staticmethod
    def save(self):
        try:
            db.session.add(self)
            db.session.commit()
            return True
        except:
            db.session.rollback()
            return False

    # 重新定义 add_all 方法
    @staticmethod
    def save_all(dataList):
        try:
            db.session.add_all(dataList)
            db.session.commit()
            return True
        except:
            db.session.rollback()
            return False

    @staticmethod
    # 自定义删除方法
    def delte(self):
        try:
            db.session.delete(self)
            db.session.commit()
            return True
        except:
            db.session.rollback()
            return False

class Stu(db.Model,NewModel):
    __tablename__ = 'stu'
    id = db.Column(db.Integer,primary_key=True)
    name = db.Column(db.String(20))
    sex = db.Column(db.Boolean,default=True)
    age = db.Column(db.Integer)
    info = db.Column(db.String(50))
    hobby = db.Column(db.String(30),default='study')

    def __init__(self,name,sex,age,info):
        self.name = name
        self.sex = sex
        self.age = age
        self.info = info
