import os

# 定义一个所有开发环境都需要使用的配置的基类
class Config:
    # 秘钥
    SECRET_KEY = 'abcsdw'
    # 加载本地的bootstrap
    BOOTSTRAP_SERVE_LOCAL = True
    # 配置sqlalchemy,为了让事务自动提交
    SQLALCHEMY_COMMIT_ON_TEARDOWN = True
    # 配置是否追踪,False
    SQLALCHEMY_TRACK_MODIFICATIONS = False

# 配置当前的绝对路径
# F:\pythonStudy\Flask\day6\code\app
base_dir = os.path.abspath(os.path.dirname(__file__))
print(base_dir)

# 开发环境的配置
class DevelopmentConfig(Config):
    # 配置数据库链接
    SQLALCHEMY_DATABASE_URI = 'sqlite:///'+os.path.join(base_dir,'blog-deve.sqlite')
    #   下面的为mysql的配置
    #  SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@127.0.0.1:3306/flask'
    DEBUG = True

# 测试环境
class TestingConfig(Config):
    SQLALCHEMY_DATABASE_URI = 'sqlite:///'+os.path.join(base_dir,'blog-text.sqlite')
    TESTING = True
    DEBUG = False

# 生成环境
class ProductionConfig(Config):
    SQLALCHEMY_DATABASE_URI = 'sqlite:///'+os.path.join(base_dir,'blog.sqlite')
    TESTING = False
    DEBUG = False

config = {
    'development':DevelopmentConfig,
    'testing':TestingConfig,
    'production':ProductionConfig,
    # 默认环境
    'default':DevelopmentConfig
}

