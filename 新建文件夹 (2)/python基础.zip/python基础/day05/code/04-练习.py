

# 1,打印100以内7的倍数
i = 1
while i <= 100:
    if i%7 == 0:
        print("7的倍数：", i)
    i += 1

# 2,打印100以内的奇数
i = 1
while i <= 100:
    if i%2:  # i%2 == 1
        print("奇数：", i)
    i += 1


# 3,打印100以内所有偶数的和
sum = 0
i = 1
while i <= 100:
    if i%2 == 0:
        sum += i
    i += 1

print(sum)  # 2550