import  re

# 拆分
str1 = "xidada dangxuan      zhuxi"
list1 = str1.split(" ")
print(list1)

# 正则的拆分
str1 = "xidada dangxuan      zhuxi"
list1 = re.split(" +",str1)
print(list1)

str2 = "wang,qi,shan dang,xuan fu,zhu,xi"
list2 = re.split(",| ",str2)
print(list2)  # ['wang', 'qi', 'shan', 'dang', 'xuan', 'fu', 'zhu', 'xi']

#  替换
#  字符串中有replace
#   参数1: 旧字符串
#   参数2 ：新字符串
#   参数3 ：原字符串
#   返回值：新字符串

# subn(): 和sub()功能类似，返回值和sub有区别：
#           subn返回的是一个元组，元组中第一个元素是新字符串，第二个元素是替换的次数

str3 = "安倍晋三 是狗,安倍xx  是猪,安倍yy 是主播"
res =re.sub("安倍..{1,2}","奥巴马",str3)  # 奥巴马是狗,奥巴马 是猪,奥巴马是主播
# res =re.subn("安倍..{1,2}","奥巴马",str3) # ('奥巴马是狗,奥巴马 是猪,奥巴马是主播', 3)
print(res)








