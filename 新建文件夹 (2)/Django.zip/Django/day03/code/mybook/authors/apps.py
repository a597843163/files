from django.apps import AppConfig


class AuthorsConfig(AppConfig):
    name = 'authors'
