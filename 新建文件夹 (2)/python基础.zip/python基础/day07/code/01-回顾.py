


'''

    列表 list
        1, 创建列表： []
        2, 列表的简单操作: +, *, in
        3, 查： list1[index]
            list1 = [1,2,3,4,2,4,4,2,5]
            index(2, 3,6)
           截取： list1[1:5], list1[::-1]
        4, 增：append(), extend(), insert()
        5, 删：pop(), remove(), clear(), del list1
        6, 改： list1[2] = 11
        7, max(), min(), count(),
        sort(), sort(reverse=True),
        sorted(), sorted(reverse=True)

    元组 tuple
        1，创建元组： ()
        2, 元组的基本操作： +， *, in
        3, 查： tuple1[index]
            截取： tuple1[:]
        4, tuple1 = (1,2,[3,4]) ;  tuple1[2][0] = 33
        5, max(), min(), count(), sorted(), sorted(reverse=True)

    字典 dict
        1, 创建字典： {}, {key:value}, {"name": "宝强", "age":33}
        2, key： 1,唯一, 2,无序，3，不可变类型
        3，增、改：dict1["sex"] = "男"
        4, 查： dict1["sex"], dict1.get("sex")
        5, 删： pop(), clear(), popitem()

    集合 set
        1, 创建set: set(),  {1,2,3}
        2, set的特点：无序的，元素唯一
        3，增： add(), update()
        4, 删： pop(), remove(), discard(), clear()
        5, 包含: >=, <=
           交集：&
           并集：|
           差集：-
           对称差集： ^

'''












