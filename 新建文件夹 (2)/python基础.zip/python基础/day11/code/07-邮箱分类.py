
# 1, 先遍历所有文件
# 2, 打开文件
#   2.1，按行取每一个邮箱信息
#   2.2，按----进行拆分/分割，获取左边的邮箱名称
#   2.3，根据邮箱类型确定保存邮箱的文件名称
#   2.4，把每个邮箱追加到对应类型的文件中
#

# hui307cc@yahoo.com.cn----zhimakaimen
# 379522867@QQ.COM----2523538
# wenzhiqin@126.com----292929
# blue3721@hotmail.com----68865764
# liangzi532@sina.com----liang0914
# ryo1997@ms3.hinet.net----680719
# cyc365@sina.com----171108
# zsk2973@yahoo.com.cn----19870317
# zizi621@126.com----8662151512

import os

def getEmail(sourcePath):

    if not os.path.exists(sourcePath):
        return "目录不存在"

    fileNameList = os.listdir(sourcePath)
    for fileName in fileNameList:
        absPath = os.path.join(sourcePath, fileName)

        if os.path.isfile(absPath):  # 文件
            parseEmailByPath(absPath)
        elif os.path.isdir(absPath):  # 目录
            getEmail(absPath)  # 递归


# 根据文件的路径，处理邮箱数据
def parseEmailByPath(filePath):

    # 设置邮箱分类之后的存储路径
    targetPath = r"C:\wamp\www\day11\code\邮箱分类"

    # 打开文件, 获取内容
    with open(filePath, "r", encoding="utf-8") as fp:

        while True:

            # 每次读取一行
            lineStr = fp.readline()

            # 如果读完了，则退出循环
            if len(lineStr) == 0:
                break

            # hui307cc@yahoo.com.cn----zhimakaimen
            # 379522867@QQ.COM----2523538

            # 获取邮箱名称
            emailList = lineStr.split("----")
            emailStr = emailList[0]  # 'hui307cc@yahoo.com.cn'

            # 获取邮箱类型
            aIndex = emailStr.rfind("@")
            dotIndex = emailStr.rfind(".")
            type = emailStr[aIndex + 1:dotIndex]


            # 根据targetPath,在targetPath下创建type目录
            dirPath = os.path.join(targetPath, type)
            # print(dirPath)

            # 如果不存在该邮箱类型所对应的目录，则创建该目录
            if not os.path.exists(dirPath):
                os.makedirs(dirPath)  # 递归创建目录

            # 文件的路径
            emailFilePath = os.path.join(dirPath, type+".txt")
            #"C:\wamp\www\day11\code\邮箱分类\163\163.txt"
            with open(emailFilePath, "a", encoding="utf-8") as fp2:
                fp2.write(emailStr + "\n")


if __name__ == "__main__":
    path = r"C:\wamp\www\day11\code\newdir"
    getEmail(path)








