


# 包： package
#    其实就是一个文件夹，只是里面多了一个__init__.py
#       __init__.py 是让python编译器认为这个文件夹是包
#


#  包 中可以包含 模块

# 导入包中的模块
# 方式1：
# import 包名.模块名
# import packagetest.module5

# 使用
# 包名.模块名.函数名()
# packagetest.module5.login()


# 方式2：
# from 包名 import 模块名
# from packagetest import module5

# 使用
# 模块名.函数名()
# module5.login()


# 方式3：
# from 包名.模块名 import 函数名或变量
from packagetest.module5 import login

# 使用
login()









