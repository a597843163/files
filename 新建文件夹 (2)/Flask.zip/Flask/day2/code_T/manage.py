from flask import Flask,session,redirect,url_for,request,abort,render_template,render_template_string
from flask_script import Manager
app = Flask(__name__)
manager = Manager(app)

@app.route('/')
def index():
    # return '首页'
    # return render_template('index2.html', title='首页', var={'num':-20, 'bool':False,
    # 'str': 'abcd', 'list':['a', 'b', 'c'], 'html': '<b>加粗</b>',
    # 'dict':{'name': "zhangsan", 'age':18}})
    # return render_template_string('<span style="color:red;font-size:20px;">首页</span>') #直接渲染字符串响应给浏览器
    # return render_template('index.html')
    # return render_template('base.html')
    return render_template('child.html')

@app.route('/include/')
def include():
    return render_template('demo.html',name='xxx')
    # return render_template('public/nav.html')

if __name__ == '__main__':
    manager.run()