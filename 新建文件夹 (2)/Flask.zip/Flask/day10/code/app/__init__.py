from flask import Flask, render_template
from app.config import config
from app.extensions import config_extensions
from app.views import config_blueprint


def create_app(CONFIG_NAME):
    app = Flask(__name__)
    app.config.from_object(config[CONFIG_NAME])  # 从外部导入配置，为app初始化配置测试环境
    config_extensions(app)   # 第三方扩展库的实例化
    config_blueprint(app)   # 蓝本视图的注册
    error_config(app)
    return app

def error_config(app):
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('error/error.html')

    @app.errorhandler(500)
    def page_not_found(e):
        return render_template('error/error.html')
