


# 银行
# Bank
#   属性：用户账户的字典
#   方法：开户  查询  存款  取款  转账 改密 锁定 解锁 补卡 销户 退出

import random
import pickle
import os
from card import Card
from user import User


class Bank(object):

    # 构造函数
    def __init__(self):
        self.userDict = {}  # key:银行卡号， value:用户对象
        self.path = "users.txt"  # 用户文件目录
        self.__getAllUser()
        print(self.userDict)

    # 把原来的所有用户从文件中取出
    def __getAllUser(self):
        if os.path.exists(self.path):
            fp = open(self.path, "rb")
            self.userDict = pickle.load(fp)
            fp.close()

    # 把所有用户存入文件中
    def __saveAllUser(self):
        fp = open(self.path, "wb")
        pickle.dump(self.userDict, fp)
        fp.close()

#------------------------ 开户 -------------------------------#
    # 开户
    def createUser(self):

        # 创建卡对象
        # 创建用户对象

        usernameInput = input("请输入您的开户人姓名:")
        idcardInput = input("请输入您的身份证:")
        phoneInput = input("请输入您的手机号:")

        # 创建卡
        cardid = self.__createCardId()  # 创建一个随机的银行卡号(6位)
        passwd = self.__setPasswd()  # 设置密码
        if passwd == -1:  # 恶意用户
            print("三次输入都错误，创建用户失败！")
            return
        money = input("请输入您要存入的金额:")

        # 银行卡对象
        card = Card(cardid, passwd, float(money))
        print(card)

        # 用户对象
        user = User(usernameInput, idcardInput, phoneInput, card)
        print(user)

        # 将创建的用户和卡存入到字典userDict中
        self.userDict[cardid] = user
        print(self.userDict)

        # 本地保存
        self.__saveAllUser()


    # 创建银行卡id
    def __createCardId(self):

        while True:
            cardid = ""  # 6位随机银行卡号
            for i in range(6):
                cardid += str(random.randrange(0, 10))

            # 如果不存在相同的银行卡号，则返回
            if not cardid in self.userDict:
                return cardid

    # 设置密码
    def __setPasswd(self):

        # 允许用户输入最多3次
        for i in range(3):

            passwd1 = input("请输入您的密码:")
            again = input("请再次输入您的密码:")

            # 输入正确,则返回密码
            if passwd1 == again:
                return passwd1

            # 如果第3次输入也错误，则返回-1
            if i == 2:
                return -1

            print("您输入的密码不匹配，请重新输入")



# ------------------------ 查询 -------------------------------#
    # 查询
    def searchUser(self):
        pass
        # 输入银行卡号
        #     判断是否输入有误
        # 输入卡号对应的密码
        # 显示余额

        # 输入卡号
        cardId = input("请输入要查询的卡号:")
        if not cardId in self.userDict:
            print("卡号输入有误")
            return

        user = self.userDict[cardId]
        card = user.card  # 银行卡对象

        # 先判断该卡是否已锁住
        if card.isLock == True:
            print("该卡已锁住，请先解锁")
            return

        # 输入密码
        res = self.__checkPasswd(card)
        if res == False:  # 输入错误3次，把卡锁住
            print("输入密码错误3次，卡已锁住")
            card.isLock = True
            self.__saveAllUser()  # 重新保存到文件
            return

        # 显示余额
        print(card.money)

    # 检查密码是否正确
    def __checkPasswd(self, card):
        for i in range(3):
            passwd = input("请输入密码:")
            if passwd == card.passwd:   # 密码正确
                return True
            if i == 2:   # 密码输入错误3次
                return False
            print("密码输入有误，请重新输入")



# ------------------------ 存款 -------------------------------#
    # 存款
    def saveMoney(self):
        pass
        # 1，先输入要存款的卡号
        #   1.1 判断卡号是否存在，如果不存在则直接返回
        # 2，通过卡号得到用户对象user和卡对象card
        # 3, 判断该卡是否锁住, 如果锁住了则直接返回
        # 4, 输入密码 self.__checkPasswd()
        #   4.1 如果输入错误3次，则把卡锁住
        # 5, 输入要存入的钱，然后把 card.money+=存入的钱
        # 6, self.__saveAllUser()


        # 输入卡号
        cardId = input("请输入要查询的卡号:")
        if not cardId in self.userDict:
            print("卡号输入有误")
            return

        user = self.userDict[cardId]
        card = user.card  # 银行卡对象

        # 先判断该卡是否已锁住
        if card.isLock == True:
            print("该卡已锁住，请先解锁")
            return

        # 输入密码
        res = self.__checkPasswd(card)
        if res == False:  # 输入错误3次，把卡锁住
            print("输入密码错误3次，卡已锁住")
            card.isLock = True
            self.__saveAllUser()  # 重新保存到文件
            return

        # 输入要存入的钱
        money = input("请输入要存入的钱:")
        card.money += float(money)
        print("存款成功！目前余额: %.2f" % card.money)

        self.__saveAllUser()  # 重新保存到文件


# ------------------------ 取款 -------------------------------#
    # 取款
    def getMoney(self):
        pass

        # 输入卡号
        cardId = input("请输入要查询的卡号:")
        if not cardId in self.userDict:
            print("卡号输入有误")
            return

        user = self.userDict[cardId]
        card = user.card  # 银行卡对象

        # 先判断该卡是否已锁住
        if card.isLock == True:
            print("该卡已锁住，请先解锁")
            return

        # 输入密码
        res = self.__checkPasswd(card)
        if res == False:  # 输入错误3次，把卡锁住
            print("输入密码错误3次，卡已锁住")
            card.isLock = True
            self.__saveAllUser()  # 重新保存到文件
            return

        # 输入要取出的钱
        money = input("当前余额:%.2f, 请输入要取出的钱:"%card.money)
        res2 = card.money - float(money)
        if res2 < 0:
            print("操作失败，余额不足！")
            return

        card.money = res2
        print("取款成功！目前余额: %.2f" % card.money)

        self.__saveAllUser()  # 重新保存到文件

    # 转账
    def transferMoney(self):
        pass
        # 1，输入当前的卡号, 得到卡对象card1
        # 2, 输入要转入的卡号, 得到卡对象card2
        # 3, 输入要转账的钱m, card1.money-m, card2.money+m
        # 4, self.__saveAllUser()

        # 1，输入当前的卡号, 得到卡对象card1
        cardId1 = input("请输入当前卡号：")
        if not cardId1 in self.userDict:
            print("卡号不存在")
            return
        user1 = self.userDict[cardId1]
        card1 = user1.card

        # 2，输入要转入的卡号, 得到卡对象card2
        cardId2 = input("请输入要转入的卡号：")
        if not cardId2 in self.userDict:
            print("卡号不存在")
            return
        user2 = self.userDict[cardId2]
        card2 = user2.card

        # 先判断该卡是否已锁住
        if card1.isLock == True:
            print("该卡已锁住，请先解锁")
            return

        # 输入密码
        res = self.__checkPasswd(card1)
        if res == False:  # 输入错误3次，把卡锁住
            print("输入密码错误3次，卡已锁住")
            card1.isLock = True
            self.__saveAllUser()  # 重新保存到文件
            return

        # 输入要转的钱：
        money = input("当前余额:%.2f, 请输入要转账的金额：" % card1.money)
        res = card1.money - float(money)
        if res < 0:
            print("余额不足")
            return
        else:
            print("转账成功！当前余额：%.2f" % res)

        card1.money -= float(money)
        card2.money += float(money)
        self.__saveAllUser()  # 重新保存到文件


    # 改密
    def modifyPasswd(self):
        pass
        # 1，输入卡号，得到card对象
        # 2, 输入旧密码(要判断旧密码是否正确)
        # 3, 输入新密码, card.passwd = newPasswd
        # 4, self.__saveAllUser()

    # 锁定
    def lockCard(self):
        pass
        # 1, 输入卡号，得到card对象
        # 2，输入密码
        # 3，card.isLock = True
        # 4, self.__saveAllUser()

        # 输入卡号
        cardId = input("请输入要锁定的卡号:")
        if not cardId in self.userDict:
            print("卡号输入有误")
            return
        user = self.userDict[cardId]
        card = user.card  # 银行卡对象

        # 先判断该卡是否已锁住
        if card.isLock == True:
            print("该卡已锁住！无需再锁")
            return

        # 输入密码
        res = self.__checkPasswd(card)
        if res == False:  # 输入错误3次，把卡锁住
            print("输入密码错误3次，卡已锁住")
            card.isLock = True
            self.__saveAllUser()  # 重新保存到文件
            return

        card.isLock = True  # 锁住
        print("锁定成功！")
        self.__saveAllUser()  # 重新保存到文件

    # 解锁
    def unlockCard(self):
        pass
        # 1, 输入卡号，得到card对象
        # 2，输入密码
        # 3，card.isLock = False
        # 4, self.__saveAllUser()
        # 输入卡号
        cardId = input("请输入要锁定的卡号:")
        if not cardId in self.userDict:
            print("卡号输入有误")
            return
        user = self.userDict[cardId]
        card = user.card  # 银行卡对象

        # 输入密码
        res = self.__checkPasswd(card)
        if res == False:  # 输入错误3次，把卡锁住
            print("输入密码错误3次，卡已锁住")
            card.isLock = True
            self.__saveAllUser()  # 重新保存到文件
            return

        card.isLock = False  # 解锁
        print("解锁成功！")
        self.__saveAllUser()  # 重新保存到文件

    # 补卡
    def makeupCard(self):
        pass
        # 1, 输入身份证，得到user对象
        # 2，user.card = Card(cardId, passwd, money)
        # 3, self.__saveAllUser()

        # 输入身份证
        idcard = input("请输入您的身份证：")

        # 循环查找到指定的user对象
        user = None
        for key in self.userDict:
            if self.userDict[key].idcard == idcard:
                user = self.userDict[key]
                break
        # 0, "", None, False, []
        # if not user:
        if user == None:
            print("没有查找到对应身份证的用户")
            return

        # 换一张卡，创建一个新的卡对象
        # 创建卡
        newCardid = self.__createCardId()  # 创建一个随机的银行卡号(6位)
        print("正在创建新卡，当前卡的账号为:%s 请设置密码" % newCardid)
        passwd = self.__setPasswd()  # 设置密码
        if passwd == -1:  # 恶意用户
            print("三次输入都错误，创建用户失败！")
            return
        money = input("请输入您要存入的金额:")

        # 银行卡对象
        newCard = Card(newCardid, passwd, float(money))


        # 更新self.userDict
        print(self.userDict)
        print(user.card.cardId)
        del self.userDict[user.card.cardId]  # 删除原来保存在userDict中的卡号

        # 设置当前user.card = newCard
        user.card = newCard

        self.userDict[newCardid] = user  # 重新添加当前user

        print("补卡成功！")
        self.__saveAllUser()


    # 销户
    def delUser(self):
        pass
        # 1, 输入身份证，得到user对象, 得到卡号
        # 2, 根据卡号删除用户: del self.userDict[cardid]
        # 3, self.__saveAllUser()

        # 输入身份证
        idcard = input("请输入您的身份证：")

        # 循环查找到指定的user对象
        user = None
        for key in self.userDict:
            if self.userDict[key].idcard == idcard:
                user = self.userDict[key]
                break
        if user == None:
            print("没有查找到对应身份证的用户")
            return

        # 删除对应的用户
        print(user.card)
        del self.userDict[user.card.cardId]
        print("销户成功!")
        self.__saveAllUser()

