

'''

    文件操作
        1， 打开文件
            open("文件路径", "r", encoding="utf-8", error="ignore")
            路径： 相对路径， index.php
                  绝对路径： http://10.36.132.120/share/index.php
                            C:\wamp\www\day08\code\02-文件的打开操作.py
            打开模式：
                r （rb）：只读
                w （wb）: 写
                a （ab）: 写（追加）
                r+ ： 读写

        2， 操作文件
            读： read()
                read(1024)
                readline()
                readlines()
            写：
                write("hello")
                write("hello".encode(encoding="utf-8"))  # 将字符串转换成二进制
                decode(encoding="utf-8") : 将二进制转换成字符串

        3， 关闭文件
            close()


    目录操作：
        import os
        os.mkdir() 创建目录
        os.rmdir() 删除目录
        os.remove() 删除文件
        os.rename() 该目录名称
        os.getcwd() 获取当前文件所在的目录
        os.listdir() 获取目录下的所有文件名和目录名
        os.curdir() 当前相对目录， .
        os.system() 执行shell命令

        os.path.abspath() ：获取绝对路径
        os.path.split() : 将目录和文件拆分开
        os.path.splitext() : 将文件名和扩展名拆分
        os.path.join() : 将目录和文件拼接
        os.path.isdir() : 是否是目录
        os.path.isfile() : 是否是文件
        os.path.exists() : 是否存在文件或目录

    windows命令行中的命令:
    cd : 进入目录
        cd .. : 上一级目录
        cd Users: 进入Users目录
        cd C:\Users\ijeff\Desktop\aa: 进入指定的路径
    dir: 显示/查看当前目录下的所有文件或目录
    mkdir: 创建目录


    pickle模块：数据持久化（存到硬盘）
        序列化 ： 将Python对象（列表，元组，字典）保存到文件中, pickle.dump()
        反序列化：  将文件中数据 取出转换成Python对象（列表，元组，字典）, pickle.load()


    json：一种表示数据的方式
        json格式的对象（列表，字典）
        json格式的字符串（'[1,2,3]'）

        [1,2,3]
        {"name":"张三", "age":33, "sex":"man"}

        [
            {"name":"张三", "age":33, "sex":"man"},
            {"name":"张三", "age":33, "sex":"man"},
            {"name":"张三", "age":33, "sex":"man"},
            {"name":"张三", "age":33, "sex":"man"},
            ...
        ]


    json序列化: 将python对象（列表，字典） 转换成 json格式字符串
    json反序列化: 将json格式字符串 转换成 python对象（列表，字典）

'''














