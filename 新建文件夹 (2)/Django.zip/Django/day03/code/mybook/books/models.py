from django.db import models
from authors.models import Author
from publishers.models import Publisher
# Create your models here.

class Book(models.Model):
    title = models.CharField(max_length=100)
    authors = models.ManyToManyField(Author)
    publisher = models.ForeignKey(Publisher)
    publicatiom_date = models.DateField()

    def __str__(self):
        return self.title
