import os
import random
import string

from PIL import Image
from flask import Blueprint, render_template, flash, get_flashed_messages, url_for, redirect, current_app, request

# flask中已经封装session的部分函数，
from flask_login import login_user, logout_user, login_required, current_user

# 注册
user = Blueprint('user', __name__)

