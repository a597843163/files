

# 比较运算符
#   ==等于， !=不等于, >大于， >=大于或等于 ，<小于， <=小于或等于

# 数值比较
'''
print(1 == 1)  # True
print(1 != 1)  # False
print(3 > 4)  # False
print(3 >= 3)  # True
print(3 < 4)  # True
print(3 <= 4)  # True

print(3 == '3')  #False


# 字符串的比较
print("345" < "543")  # True
print("a" < "b")  # True
print("a" < 'A')  # False
print("abc" < "ba")  # True, 从左往右依次比较每个字符的大小，如果能够比较出大小，则直接返回结果

# 判断ch是否为字母
# and: 并且
# or : 或者
# ch>='a' and ch<='z' : 表示小写字母
# ch>='A' and ch<="Z" ： 表示大写字母
ch = 'd'
if (ch>='a' and ch<='z') or (ch>='A' and ch<="Z"):
    print("是字母")
else:
    print("不是字母")

# 字符串比较： 是按照ASCII码来进行比较的
# 0~9: 48~57
# A~Z: 65~90
# a~z: 97~122

'''

