def fab(m):
    curr, prev = 1, 0
    n = 0
    # 无限循环
    while n < m:
        # 返回当前的值
        yield curr
        prev, curr = curr, curr + prev
        n += 1

f = fab(100)
# print(next(f))

for i in f:
    print(i)
