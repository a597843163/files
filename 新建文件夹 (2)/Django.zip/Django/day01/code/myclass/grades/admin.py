from django.contrib import admin
from .models import Grade
# Register your models here.

# 注册Grade,显示在后台管理站点上
admin.site.register(Grade)