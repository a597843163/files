
# 装饰器
# 作用：可以在不修改原来函数的基础上增加了一些功能，且使用的还是原来的函数名

'''
    时间： 2018-3-22
    修改者: niejeff
    修改内容： ddd
    start
'''
def add():
    print("hello 猫神")

# end

#
def hello():

    # print("hello 猫神")
    # add()

    print("我觉得梦泪的名字很合适")
    print("适合做梦的时候流眼泪")


def hello2():
    print("hello 猫神")
    hello()

hello2()
print()



# 装饰器
# outer是装饰器
def outer(fn):
    def inner():

        # 在原来的功能之前添加代码
        print("我在大学的时候")

        fn()

        # 在原来的功能之后添加代码
        print("可惜不是你")

    return inner

# say是被装饰
def say():
    print("我喜欢小芳")

# say = inner
say = outer(say)

# 调用
say()  # inner()

print()

# 装饰器

def outer1(fn):
    def inner():
        print("我在小学的时候")
        fn()
    return inner

@outer1  # 相当于 say1 = outer1(say1)
def say1():
    print("我喜欢小丽")

# say1 = inner
# say1 = outer1(say1)

# 调用， 其实调用的是inner()
say1()

# 类方法
# @classmethod  # cls参数，可以调用其他类方法和类变量
# 静态方法  # 普通函数，只不过是写在类，不使用类中的其他属性和方法
# @staticmethod

print()


# 带参数的装饰器
# 装饰器
def outer2(fn):
    def inner(name, age):
        print("因为我人好，有魄力，比较二")
        fn(name, age)
    return inner

# 被装饰的函数
@outer2
def baby(name, age):
    print("姓名:%s,年龄:%d" % (name, age))
    print("小芳送了我一块手表")
    print("小芳晚上8点主动约我去看广场舞")
    print("然后引诱我")
    print("但是我，岿然不动")


# baby = outer2(baby)

# 调用, baby()相当于inner()
baby("张三", 33)




# 通用装饰器

def outer3(fn):   # fn=say3
    def inner(*args, **kwargs):
        # 在原来的功能之前添加代码
        res = fn(*args, **kwargs)
        # 在原来的功能之后添加代码
        return res

    return inner

@outer3
def say3(name, like, age):
    print("%s 喜欢 %s, 年龄：%d" % (name, like, age))
    return name + " 喜欢: " + like

# say3 = outer3(say3)

# 此时say3=inner
res = say3("科比", "篮球", 37)
print(res)






