# 导入模块
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_mail import Mail
# 处理登陆的第三方模块
from flask_login import LoginManager

bootstrap = Bootstrap()
db = SQLAlchemy()
migrate = Migrate(db=db)
mail = Mail()
login_manager = LoginManager()

# 创建一个 统一管理第三方模块初始化的函数
def config_extensions(app):
    bootstrap.init_app(app)
    db.init_app(app)
    migrate.init_app(app)
    mail.init_app(app)
    login_manager.init_app(app)
    # 指定登录的端点 ，让用户未登录状态跳这个路由
    login_manager.login_view = 'user.login'
    # 指定登录的提示信息
    login_manager.login_message='您还没有登录，请先登录再访问'
    # 设置session的保护级别
    # None没有的，basic基本的,
    # strong 强保护 只要当前服务登录出现任何问题或者异常 都会自动退出登录
    login_manager.session_protection = 'strong'

