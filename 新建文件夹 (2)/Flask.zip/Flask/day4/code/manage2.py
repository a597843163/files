from flask import Flask,render_template,request
from flask_script import Manager
from flask_bootstrap import Bootstrap
from flask_uploads import UploadSet,IMAGES,configure_uploads,patch_request_class
import os
from PIL import Image #导入图片处理模块
app = Flask(__name__)
bootstrap = Bootstrap(app)
app.config['MAX_CONTENT_LENGTH'] = 1024*1024*64  # 设置上传内容最大为64M
app.config['UPLOADED_PHOTOS_DEST'] = os.getcwd()+'/static/upload'  # 设置上传文件保存的路径
# 实例化下载设置对象
file = UploadSet('photos',IMAGES)
# 把app设置的config注册到file中
configure_uploads(app,file)
patch_request_class(app,size=None) #将第三方上传大写设置为 app.config['MAX_CONTENT_LENGTH']的大小
manager = Manager(app)


@app.route('/upload/',methods=['GET','POST'])
def upload():
    img_url = None
    #判断是否为表单提交 并且上传有内容,key(file)在request.files中，即为有内容
    if request.method == 'POST' and 'file' in request.files:
        print(request.files)
        # 这里的file是  # 实例化对象
        # file = UploadSet('photos',IMAGES)
        fileName = file.save(request.files.get('file')) #文件保存
        # print(fileName)
        #进行图片缩放处理
        imgPath = os.path.join(app.config['UPLOADED_PHOTOS_DEST'],fileName)   # 拿到原图的路径
        img = Image.open(imgPath) #打开图片并且生成可操作实例对象
        img.thumbnail((300,300)) #生成缩略图
        # img.save(imgPath) #保存并覆盖原图
        img.save(os.path.join(app.config['UPLOADED_PHOTOS_DEST'],'s_'+fileName)) #指定保存到某个路径下
        # print(fileName)
        #需求 大图和小图都需要 但是数据库存储图片只有一个字段 应该怎样存储或者操作？
        img_url = file.url('s_'+fileName) #获取图片的地址
        # print(img_url)
        # file_url = file.url(fileName)
        # print(file_url)
        #需求 如果存储的图片量过大 有什么好的办法来处理？
    return render_template('upload.html',img_url=img_url)


if __name__ == '__main__':
    manager.run()

