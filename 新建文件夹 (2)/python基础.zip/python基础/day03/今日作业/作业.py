
#1, 入职薪水10K，每年涨幅入职薪水的5 %，50年后工资多少？
salary = 10
d =0.05
year = 50
result = salary + salary * d * year
print("50年后工资为：", result)

# 2, 为抵抗洪水，战士连续作战89小时，编程计算共多少天零多少小时？
time = 89
day = time//24
hour = time  % 24
print("共 %d 天 %d 小时"%(day,hour))

# 3, 小明要到美国旅游，可是那里的温度是以华氏度为单位记录的。它需要一个程序将华氏温度（80度）转换为摄氏度，并以华氏度和摄氏度为单位分别显示该温度。
#提示：摄氏度与华氏度的转换公式为：摄氏度 = 5 / 9.0 * (华氏度 - 32)
huashi = 80
sheshi = round(5 / 9.0 * (huashi-32))
print("华氏度：",huashi)
print("摄氏度: ",sheshi)

# 4, 给定一个5位数，分别把这个数字的万位， 千位，百位、十位、个位算出来并显示。如： 34567

n = int(input("请输入一个5位数:"))
wan = n// 10000
qian = (n % 10000)//1000
bai = (n % 1000)//100
shi = (n % 100) //10
ge = n % 10
print("万位为：%d 千位为：%d 百位为：%d 十位为：%d 个位为：%d"%(wan,qian,bai,shi,ge))

# 5.彩票系统:用户输入一个数,再随机生成一个数,判断2个数是否相等,如果相等,恭喜中奖了
import random

n = int(input("请输入一个数:"))
f =  random.choice(range(10))
if n == f :
    print("恭喜中奖了！！")

# 6.从控制台输入一个三位数，如果是水仙花数(是指一个三位数,其各位数字立方和等于该数 )就打印“是水仙花数”，否则打印“不是水仙花数”
#  如：153=1^3+5^3+3^3

n = int(input("请输入一个三位数:"))
num1 = n // 100
num2 = (n % 100)//10
num3 = n % 10
num4 = num1**3+num2**3+num3**3
if num4 == n :
    print("是水仙花数！！")
else :
    print("不是水仙花数！！")


# 7.从控制台输入一个五位数，如果是回文数(对称的五位数),就打印“是回文数”，否则打印“不是回文数”
#  如： 11111   12321   12221

n = int(input("请输入一个五位数:"))
wan = n// 10000
qian = (n % 10000)//1000
shi = (n % 100) //10
ge = n % 10
if  (wan == ge )and(qian == shi ):
    print("是回文数！！")
else:
    print("不是回文数！！")


# 8.不准使用max min
#  从控制台输入两个数，输出较大的值
#  从控制台输入三个数，输出较大的值

n1 = int(input("请输入第一个数："))
n2 = int(input("请输入第二个数："))
if n1 > n2 :
    print(n1)
else :
    print(n2)

n1 = int(input("请输入第一个数："))
n2 = int(input("请输入第二个数："))
n3 = int(input("请输入第三个数："))
if n1 > n2 and n1 >n3 :
    print(n1)
else:
    if n2 > n1 and n2 >n3 :
        print(n2)
    else:
        print(n3)
