from flask import Flask,render_template
from flask_script import Manager
from flask_mail import Mail,Message
from threading import Thread #导入线程模块
import os
app = Flask(__name__)

# smtp为发送邮件协议+邮箱后缀
app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER','smtp.163.com')
# username 为用户名
app.config['MAIL_USERNAME'] = os.environ.get('MAIL_USERNAME','a5978431633@163.com')
# password 为授权码
app.config['MAIL_PASSWORD'] = os.environ.get('MAIL_PASSWORD','a123456')

mail = Mail(app)
manager = Manager(app)
#线程执行干的活
def async_send_mail(app,msg):
    #程序上下文
    with app.app_context():
        mail.send(message=msg)

def send_mail(subject,to,username):
    msg = Message(subject=subject,recipients=[to],sender=app.config['MAIL_USERNAME'])
    msg.html = render_template('active.html',username=username)
    # 第一个参数为 让当前线程干活的函数  第二个为传参 需要元组形式
    send = Thread(target=async_send_mail,args=(app,msg))
    send.start() #开启线程

@app.route('/')
def index():
    send_mail('邮件激活','597843163@qq.com','张三')
    return '邮件发送成功'


if __name__ == '__main__':
    manager.run()