from django.shortcuts import render, redirect, reverse
from django.http import HttpResponse, HttpResponseRedirect
import datetime
import hashlib
import time
import random
from .models import User


# 首页
def index(request):
    # cookie
    # username = request.COOKIES.get('username', '')

    # session
    # username = request.session.get('username', '')

    # token
    token = request.COOKIES.get('token')
    users = User.objects.filter(token=token)
    if users.exists():
        username = users.first().username
    else:
        username = ""

    return render(request, 'App/index.html', {'username': username})


# 登录页面
def login(request):
    return render(request, 'App/login.html')


# 登录操作
def login_handle(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        password = my_md5(password)  # 登录时也对密码加密，使用密文进行匹配

        users = User.objects.filter(username=username, password=password)

        # 登录成功
        if users.exists():
            response = HttpResponseRedirect(reverse('App:index'))

            # cookie
            # response.set_cookie('username', username)  # 默认在浏览器关闭时失效
            # response.set_cookie('username', username, max_age=10)  # 10秒后失效
            # d = datetime.datetime(2019, 10, 11, 2, 3, 4)
            # d = datetime.datetime.now() + datetime.timedelta(days=1)
            # response.set_cookie('username', username, expires=d)  # 在指定时间失效

            # session
            # request.session['username'] = username

            # token
            response.set_cookie('token', users.first().token, max_age=3600*24)

            return response

        else:
            return HttpResponse("登录失败,用户名或密码错误!")

    else:
        return redirect(reverse('App:login'))


# 退出、注销
def logout(request):
    response = HttpResponseRedirect(reverse('App:index'))

    # cookie
    # response.delete_cookie('username')

    # session
    # del request.session['username']
    # 同时删除session和cookie
    # request.session.flush()

    # token
    response.delete_cookie('token')

    return response


# 注册
def register(request):
    return render(request, 'App/register.html')


# 注册操作
def register_handle(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        password = my_md5(password)  # 将密码加密存储
        age = request.POST.get('age')

        # token / usertoken : 用户的唯一标识
        # 时间戳+username+域名， 时间戳+随机数+...
        token = genarate_token()

        # 注册: 给user表中加入一条数据
        # u = User()
        # u.username = username
        # u.password = password
        # u.age = age
        # u.token = token
        # u.save()
        try:
            if age:
                user, created = User.objects.get_or_create(username=username, password=password, token=token, age=age)
            else:
                user, created = User.objects.get_or_create(username=username, password=password, token=token)
            return redirect(reverse('App:login'))
        except:
            return HttpResponse("注册失败")

    else:
        return redirect(reverse('App:register'))


# md5加密 128位-> 32位十六进制
def my_md5(str1):
    # 创建对象
    m = hashlib.md5()
    m.update(str1.encode('utf-8'))
    return m.hexdigest()


# 创建token
def genarate_token():
    m = str(time.time()) + str(random.random())
    return my_md5(m)


# 购物车页面
def shopping_cart(request):

    # token
    token = request.COOKIES.get('token')
    users = User.objects.filter(token=token)
    if users.exists():
        username = users.first().username
    else:
        username = ""

    return render(request, 'App/shoppingCart.html', {'username': username})


