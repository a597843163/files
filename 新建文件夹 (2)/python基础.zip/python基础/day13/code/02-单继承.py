


# 面向对象的特征： 封装，继承，多态
#       封装： 将属性和方法封装在类中
#       继承： 子类继承父类的属性和方法, 子类也可以扩展自己的属性和方法
#       多态： 在继承的基础上（一般是多个子类继承同一个父类，且重写父类的同一个方法），使用父类对象指向不同的子类
#

# 定义了三个类
'''
# Person
class Person(object):
    def __init__(self, name, age, sex, qq, wechat, phone):
        pass

# Man
class Man(object):
    def __init__(self, name, age, sex, qq, wechat, phone, makeMoney):
        pass

# Female
class Female(object):
    def __init__(self, name, age, sex, qq, wechat, phone, shopping):
        pass

'''


# 使用继承
# 父类
class Person(object):
    # 属性
    def __init__(self, name, age, sex, qq, wechat, phone):
        self.name = name
        self.age = age
        self.sex = sex
        self.qq = qq
        self.wechat = wechat
        self.phone = phone

    # 方法
    def eat(self):
        print("我是吃货")


# 子类
# Man类 继承了 Person类
class Man(Person):
    # 属性
    def __init__(self, name, age, sex, qq, wechat, phone, makeMoney):
        # super: 指向父类的
        super().__init__(name, age, sex, qq, wechat, phone)    # 隐式调用父类
        # super(Man, self).__init__(name, age, sex, qq, wechat, phone)
        # Person.__init__(self, name, age, sex, qq, wechat, phone)  # 显示调用父类（可以看到父类）

        self.makeMoney = makeMoney

    # 方法
    def sleep(self):
        print("我是懒虫，爱睡觉")

# 创建对象
# 创建父类对象
# person = Person("霍金", 76, "男", 123456, "huojin", 13456789324)
# person.eat()
# person.sleep()  # 不可以使用子类的方法和属性
# print(person.name, person.age)

# 创建子类对象
man = Man("霍金", 76, "男", 123456, "huojin", 13456789324, "100块")
man.sleep()  # 我是懒虫，爱睡觉
man.eat()  # 我是吃货
print(man.name, man.age, man.makeMoney)  # 霍金 76 100块




