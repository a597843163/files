from flask import Blueprint, render_template, flash, get_flashed_messages, redirect, url_for, request
from app.models import Posts
from app.forms import PostsForm
from flask_login import current_user
from app.extensions import db

posts = Blueprint('posts',__name__)

#发表帖子的路由
@posts.route('/publish/',methods=['GET','POST'])
def publish():
    form = PostsForm()
    if form.validate_on_submit():
        if current_user.is_authenticated:
            #获取当前current_user代理对象的真实对象
            u = current_user._get_current_object()
            p = Posts(content=form.content.data,user=u)
            db.session.add(p)
            flash('博客发表成功！！！')
        else:
            flash('你还没有登录 请登录在发表')
            return redirect(url_for('user.login'))
    return render_template('posts/publish.html',form=form)

# 点击我发布的帖子,显示帖子
@posts.route('/showposts/')
def show_myposts():
    '''
    1.把数据传给template,
    2.模板进行显示
    :return:
    '''
    # 获取当前用户的所有帖子
    if current_user.is_authenticated:
        # 得到当前用户对象
        u = current_user._get_current_object()
        # 当前页码数
        page = int(request.args.get('page', 1))
        # 拿到本用户的分页对象
        pagination = Posts.query.filter(Posts.uid == u.id).order_by(Posts.timestamp.desc()).paginate(page, 5, False)
        data = pagination.items
    return render_template('posts/show_myposts.html',data=data,pagination=pagination,def_name='posts.show_myposts')

# 帖子详情页
'''
    1.点击一个帖子，然后进入页面
    2.页面显示内容: 1.user, 2.user头像  3.帖子的内容  4.时间.  5.评论回复 
'''
@posts.route('/postsinfo/')
def posts_info():
    # 当前帖子的posts_id
    posts_id =  request.args.get('posts_id')
    # 拿到帖子对象,并且传入
    p = Posts.query.filter(Posts.id==posts_id).first()
    # 找到path字段中带有,2,
    answers = Posts.query.filter(Posts.path.contains(','+posts_id+','))

    return render_template('posts/postsinfo.html',p=p,answers=answers)


@posts.route('/collect/')
def collect():
    return '收藏帖子'