from django.apps import AppConfig


class LxgloginConfig(AppConfig):
    name = 'LXGlogin'
