


'''
    if 单分支
        if 条件:
            语句
            语句
'''

# n = input("请问您是不是VIP客户（Y/N）:")
# if n == "Y":
#     print("请您走VIP通道")
# if n == "N":
#     print("请排队")


'''
    if 双分支
        if 条件:
            语句
        else:
            语句
'''

# s = input("请问我头像牛B吗（像/不像）:")
# if s == "像":
#     print("牛B")
# else:
#     print("不牛B")


'''
    if 多分支
        if 条件:
            语句
        elif 条件2:
            语句2
        ...
        else:
            语句
    
'''

# 判断年龄阶段：少年(<=16)，青年(16<age<=35)，中年(35<age<=65)，老年(age>65)
age = int(input("请输入您的年龄:"))
if age <= 16:
    print("少年")
elif age <= 35:
    print("青年")
elif age <= 65:
    print("中年")
else:
    print("老年")



'''
    if 嵌套
    
    
    
'''
#  从控制台输入三个数，输出较大的值
num1 = int(input("请输入第一个数："))
num2 = int(input("请输入第二个数："))
num3 = int(input("请输入第三个数："))

# if num1 > num2:
#     max = num1
# else:
#     max = num2
#
# if max > num3:
#     print("较大数：", max)
# else:
#     print("较大数：", num3)


if num1 > num2:
    if num1 > num3:
        print("较大数：", num1)
    else:
        print("较大数：", num3)

else:  #num1 <= num2
    if num2 > num3:
        print("较大数：", num2)
    else:
        print("较大数：", num3)


