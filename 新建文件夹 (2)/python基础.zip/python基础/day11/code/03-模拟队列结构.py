


# 队列： 一种数据结构
# 特点： 先进先出，后进后出

# 可以使用列表去模拟队列


# 导入collections模块
import collections

# 创建一个队列
queue = collections.deque()
print(queue)  # deque([])

# 入队列
# append() : 在队列的右边加入数据
# appdenleft() ：在队列的左边加入数据
queue.append("B")
print(queue)  # deque(['B'])

queue.append("C")
print(queue)  # deque(['B', 'C'])

queue.appendleft("A")
print(queue)  # deque(['A', 'B', 'C'])


# 出队列
# pop() : 在队列的右边删除数据（取出数据）
# popleft() ： 在队列的左边删除数据（取出数据）
res = queue.pop()
print(queue)  # deque(['A', 'B'])
print(res)  # C

res = queue.popleft()
print(queue)  # deque(['B'])
print(res)  # A



# 实现队列的操作
#  使用append()在队列的右边加入数据
#  使用popleft()在队列的左边取出数据
queue = collections.deque()

# 入队列
queue.append("A")
print(queue)

queue.append("B")
print(queue)

queue.append("C")
print(queue)

queue.append("D")
print(queue)


# 出队列
res = queue.popleft()
print(queue)  # deque(['B', 'C', 'D'])
print(res)  # A

res = queue.popleft()
print(queue)  # deque(['C', 'D'])
print(res)  # B















