class Config():
    # 配置数据库连接
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:root@127.0.0.1:3306/flask'
    # 设置数据发生改变不追踪
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # 设置为自动提交  不需要每次都commit
    # SQLALCHEMY_COMMIT_ON_TEARDOWN = True

# 导入路由转换器的类，重写url方法，让其可以正则匹配
from werkzeug.routing import BaseConverter
class RegexConverter(BaseConverter):
    def __init__(self,url,*args):
        super(RegexConverter,self).__init__(url)
        self.regex = args[0]

