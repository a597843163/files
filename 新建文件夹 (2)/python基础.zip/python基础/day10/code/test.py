import os
dic = {}
def count(path):
    list1 = os.listdir(path)
    global dic
    for name in list1:
        if os.path.isfile(name):
            with open('a.txt', 'r', encoding='utf-8') as fp:
                Str = fp.read()
                for Str1 in Str:
                    if not dic.get(Str1):
                        dic[Str1] = 1
                    else:
                        dic[Str1] += 1
                print(dic)
        if os.path.isdir(name):
            count(name)

