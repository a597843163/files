

'''

day01:
    装环境

day02：
    1，数据存储原理
    2，原码反码补码
    3，注释
        单行注释： #
        多行注释： """ 注释内容 """
    4，输入输出
        输入： input("请输入内容：")
        输出： print("hello world")

day03:
    1，数据类型：
        Number, String, Boolean, List, Tuple, Dict, Set, None, Byte
        type(): 判断数据类型
        isinstance(): 判断对象是属于什么类
    2，变量
        声明变量：
            age = 20
            a = b = c = 10
            a,b = 10,20
            a,b = (20,30)
            a,*b,c = 1,2,3,4
            (a=1,b=2,c=3, 报错)
        关键字
        命名规范：
            # 1，变量名称只能为数字，字母和下划线组成
            # 2，不能以数字开头
            # 3，不能使用关键字
            # 4，区分大小写
            # 5，见名思意
            # 驼峰原则myStuGrade, my_stu_grade
        删除变量：
            del age

    3, Number类型
        int, float
        int() : 转成整型
        float() : 转换成浮点型
        max(), min(), abs(), round()

    4, math模块: 数学函数
        math.ceil()
        math.floor()
        math.sqrt()
        math.sin()

    5, random随机数模块
        random.choice() : 从序列中随机选择一个
            random.choice([1,2,3,4])
            random.choice(range(1,101))
        random.randrange(start, end, step) : 从[start, end)中随机取一位整数,step为步数
        random.randint(start, end) : 从[start, end]中随机取一位整数
        random.random() : 随机取[0,1)的小数
        random.uniform(start, end) : 从[start, end]中随机取一个实数（一般是小数）
        random.shuffle() : 乱序

    6，算术运算符
        四则运算： +, -, *, /
        整除： //
        取模： %
        次幂： **


day04:
    1, 比较运算符(关系运算符)
        数值类型： 比较数字大小
        字符串： 从左往右依次比较字符ASCII码的大小
    2，逻辑运算符
        and， or， not
        注意： and和or有短路操作
    3, 成员运算符
        in, not in
    4, 身份运算符: 比较内存地址
        is, not is
    5， 位运算符
        &, |, ^, >>
    6， 赋值运算符
        =, +=, -=, *=, /=, %=
    7, Boolean
        两个值： True, False
    8，None
        一个值： None
    9, if语句
        if 单分支
        if-else 双分支
        if-elif-else 多分支
        if 嵌套

day05:
    1, while循环
    2, for 循环
    3, break, continue
    4，pass语句


day06:
    1, 列表list
        创建列表
            mylist = [1,2,3,4]
        列表的基本操作
            下标（索引）： mylist[index], mylist[1], mylist[-1]
            长度： len(mylist)
            遍历： for i in mylist:
            拼接： list1 + list2
            重复： mylist*3
            元素是否存在： i in mylist
            截取（切片）： mylist[:], mylist[3:], mylist[:5], mylist[2:5]
                         mylist[::-1], mylist[3::-1]
        列表的常用操作：
            增：
                append(n)
                extend(list)
                insert(index, n)
            删：
                del mylist
                pop(), pop(index)
                remove(n)
                clear()
            改：
                mylist[index] = n
            查：
                mylist[index]
                index()
            排序：
                list.sort()
                list.sort(reverse=True)
                sorted(list)
                sorted(list, reverse=True)
            反转：
                list.reverse()
                reversed(list)
            元素个数：
                count()
                max(), min(), sum()

    2, 元组tuple
        和list类似，不同点是元组不可以修改

    3，字典dict
        创建字典：
            mydict = {"name":"宝强", "age":33}
        字典的操作：
            增：
            改：
                mydict[key] = value
            删：
                pop(key), pop(key, default)
                popitem()
                clear()
            查：
                mydict[key]
                mydict.get(key)
        判断key是否存在： key in mydict
        遍历：
            for key in mydict:
            for key in mydict.keys():
            for value in mydict.values():
            for key,value in mydict.items():
            {1:"a", 2:"b"} = > {"a":1, "b":2}

    4, 集合set
        特点： 不存在重复元素，每个元素都是唯一的
        myset = {1,2,3}
        add()
        update()
        pop() : 随机删
        remove(n) : 根据元素删除，如果n不存在，会报错
        discard(n) : 根据元素删除，不会报错
        clear()

        遍历： for i in myset:

        操作：
            交集： &
            并集： |
            差集： -
            对称差集： ^
            包含： >=, <=

        去重： 使用


day07:
    1, 函数
        作用：封装功能
        创建函数
        def fn(a, b):
            sum = a + b
            return sum
        调用函数
        res = fn(3,4)
        print(res)
        参数：
            形参， 实参
        返回值：return

        copy() : 复制
        mylist = [1,2,3,["a", "b", "c"]]
        mylist2 = mylist.copy()

        默认参数:
            def fn(age=33)
        关键字参数:
            def fn(a=1, b=2, c=3):
                pass
            fn(b=20)
        不定长参数(可变参数):
            def fn(*args):  # args = (1,2,3,4)
                pass
            fn(1,2,3,4)
            def fn(**kwargs): # kwargs= {"a":10, "b":20}
                pass
            fn(a=10, b=20)
        匿名函数:
            表示一些简单的函数
            def fn(n):
                return n+1
            =>
            lambda x:x+1
        偏函数:
        生成器函数
            def fn():
                yield 10
            generator = fn()
            print(next(generator))
        回调函数：
        作用域：
            局部作用域： 局部变量
            全局作用域： 全局变量
        globle
        nonlocal

        异常处理：
            try:
                ...
            except:
                print("发送错误")

day08
    1, 文件操作
        1，打开文件
        2，获取数据/修改数据
        3, 关闭文件
        # url: 表示网址之类的路径
        # path: 表示本地路径
        open(path, mode, encoding)
        mode:
            r : 只读， 如果文件不存在会报错
            rb ： 读二进制, 如果文件不存在会报错
            w: 清空写， 如果文件不存在，会创建
            wb: 清空写二进制, 如果文件不存在，会创建
            a : 追加写， 如果文件不存在，会创建
            ab : 追加写二进制， 如果文件不存在，会创建
            r+, rb+,...
        读
            read()
            read(1024)
            readline()
            readlines()
        写
            write()

        encode() ： 字符串转二进制
        decode() ： 二进制转字符串

        移动定位符：
            seek(1)
            tell()
        目录
            os.curdir()
            os.getcwd()
            os.listdir()
            os.mkdir()
            os.rmdir()
            os.remove()
            os.rename()
            os.system()
            os.path.abspath()
            os.path.join()
            os.path.split()
            os.path.splittext()
            os.path.isfile()
            os.path.isdir()
            os.path.exists()

        pickle模块:
            pickle.dump() : 将python对象 存入文件中
            pickle.load() : 将文件中的内容 取出变成python对象

day09
    1, time模块
    2，字符串操作
        创建字符串：
            mystr = "hello 宝强"
        字符串的基本操作
            下标： mystr[index]
            长度： len(mystr)
            遍历： for ch in mystr:
            拼接： str1 + str2
            重复： mystr * 2
            截取（切片）： mystr[:], mystr[2:5], mystr[::-1]

        字符串的常用操作
            upper()
            lower()
            title() ： 把字符串标题化
            swapcase() : 把大小写翻转
            capitalize() : 把字符串的首字母大写
            isupper()
            islower()
            istitle()

            center()
            ljust()
            rjust()

            strip() : 清除两边的空格
                strip("*") : 清除两边的*号
            lstrip() : 清除左边
            rstrip() : 清除右边

            # 重要
            find(): 从左往右查找，查找子字符串在字符串中第一次出现的下标, 如果不存在则返回-1
            rfind() : 从右往左查找
            index() : 查找子字符串在字符串中第一次出现的下标, 如果不存在则报错
            rindex() : 从右往左

            split() : 拆分
            splitlines() : 按行拆分

            join() : 拼接
                mylist = [1,2,3,4]
                "+".join(mylist) => "1+2+3+4"

            replace() : 替换

            startswith(): 判断是否以指定字符串开头
            endswith() : 判断是否以指定字符串结尾
            count(): 统计指定字符串出现的次数
            ord() : 将字符转换成 ASCII码
            chr() : 将ASCII码转换成字符
            eval() : 执行一个字符串表达式，返回一个表达式的值


day10
    模块
        导入模块
            import hello
            from hello import age,fn
            from hello import *  # 不推荐

        if __name__ == "__main__":
            test()

        包
            import package.hello
            from package import hello
            from package.hello import age,fn
        calendar模块
        datetime模块
        hashlib模块

        函数递归

day11
    1, 栈
        特点：先进后出， 后进先出

        list模拟栈： 控制对列表的操作在列表末尾

    2，队列
        特点： 先进先出， 后进后出
        from collections import queue
        queue.deque()
        append()
        appendleft()
        pop()
        popleft()


day12
    面向对象
        面向对象的思想，面向过程的思想
        类和对象
        类： 抽象
        对象： 具体
        在代码中一般使用的是对象
        类的作用：用来创建对象
    class Person(object):
        # age是类属性或类变量
        age = 30

        # 构造函数
        def __init__(self, name, sex):
            # 成员属性/成员变量/对象属性
            self.name = name
            # 私有属性/私有变量
            self.__sex = sex


        # 析构函数
        def __del__(self):
            print("析构函数")
        def __str__(self):
            return "姓名：%s, 性别: %s" % (self.name, self.__sex)
        def __repr__(self):
            return "姓名：%s, 性别: %s" % (self.name, self.__sex)

day13
    1, 单继承
        # 父类
        class A:
            def __init__(self, name):
                self.name = name
            def eat(self):
                print("吃货")

        # 子类B 继承 A
        class B(A):
            def __init__(self, name, age):
                super().__init__(name)
                self.age = age
            # 重写父类的方法
            def eat(self):
             print("我喜欢吃肉")

    2， 多继承
        class A:
            def __init__(self, name):
                self.name = name
        class B:
            def __init__(self, age)
                self.age = age
        class C(A,B):
            def __init__(self, name, age, sex):
               super().__init__(name)
               super(A,self).__init__(age)
               self.sex = sex
    3， 类方法和静态方法
        类方法： @classmethod
        静态方法： @staticmethod
    4， 限制属性 __slots__ = ("name", "age", "sex")
    5， 动态添加属性和方法
        对象.属性 = 10
        对象.方法 = 函数名
    6， @property ：让私有属性可以通过点语法调用,如obj.sex
    7,  多态

day14
    银行系统
    发送短信
    发送邮件

day15
    正则表达式
       import re
       re.match() : 从开始匹配
       re.search() : 匹配整个字符串，并返回第一个匹配的
       re.findall() : 返回所有匹配项，以列表的形式

       元字符
          单个字符
            . : 除了换行以外的任意单个字符， 使用re.S则可以包含换行
            [] : 表示范围
            [234] : 表示可以出现2或3或4
            [0-9] : 表示数字
            [a-zA-Z0-9_] : 表示数字字母下划线
            \d ：数字
            \w : 表示数字字母下划线
            \s : 表示空格，换行，换页，回车符
            \D : 非\d
            \W : 非\w
            \S : 非\s

          数量
            ? : 0个或1个
            * : 0个或多个
            + ：1个或多个
            {} ： 表示数量范围
            {4} ： 4个
            {2,}: 至少2个
            {,5}: 最多5个
            {2,5}： 2-5个

          边界:
            ^ : 开始匹配
            $ : 结尾匹配
            ^ $ : 完全匹配
            上面两种是在re.M换行模式下会每行都重新匹配

            \A: 开始匹配
            \Z: 结尾匹配

            \b : 单词以指定的字符串结尾
            \B : 字符串出现在单词中但不以该字符串结尾

            | 或
            () : 分组，可以用来捕获

            group()
            groups()

          先编译：com = re.compile()
                 com.search()
                 com.match()
                 com.findall()

day16
    爬虫
day17
    网络编程
        TCP
        UDP
day18
    列表生成器
        [i for i in range(10) if i%2==0]

day19
    装饰器
    去重
    str.isdigit() : 判断字符串是否为数值型字符串
    type(n) == int : 判断是否为整数
    
'''

def fn():
    return 10, 20
# a, b = fn()
# a, b = (10, 30)
# print(a, b)

a,*b,c = 1,2,3,4
print(a, b, c)  # 1 [2, 3] 4


mylist = [1,2,3,4,5,6]
res = mylist[3::-1]
print(res)  # [4, 3, 2, 1]


# copy() : 浅复制，只会复制第一层元素，元素中如果有引用类型，则只会复制地址，不会复制内存
# deepcopy() : 深复制,会把所有的元素都复制
mylist = [1,2,3,["a", "b", "c"]]
mylist2 = mylist * 1

# mylist[0] = 99
mylist[-1][0] = 99
print(mylist)
print(mylist2)



# from hello import *
# print(age)  # 10
# print(_age)  # 报错
# print(__age)  # 报错


