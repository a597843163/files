


'''

    for循环
        格式： for 变量 in 序列:
                  语句

    # 其他语言的for循环
    for (int i=0; i<len(list); i++){
        语句
    }

'''

ages = [10, 20, 30, 40]
for i in ages:
    print(i)  # 元素的值
print()
# for: 内部会自动从列表的第一个遍历到最后一个，然后返回遍历过程中的每一个元素

# range(100) : 0-99
# range(2,10) : 2-9
# range(len(ages)) : range(4) : 0-3
for i in range(len(ages)):
    print(i)   # 元素对应的下标


# enumerate：枚举
for i,n in enumerate(ages):
    print('枚举',i, n)  # i下标， n示值




# 5,判断一个数是不是素数（质数）。(除了1和它本身以外不再有其他的除数整除。)
# 如： 7， 13， 23

# while-else语法, 和break搭配使用
n = 23
i = 2
while i < n:
    if n%i == 0:
        print(n, "是合数")
        break
    i += 1
else:
    print("是素数")
# if i == n:
#     print("是素数")


# 要搭配break来使用, 如果执行break就不执行else, 如果不执行break就会执行else



# for-else语法, 和break搭配使用
n = 23
for i in range(2, n):
    if n%i == 0:
        print(n, "是合数")
        break
else:
    print("是素数")





# 15, 99乘法表
'''
1 * 1 = 1
1 * 2 = 2	2 * 2 = 4
1 * 3 = 3	2 * 3 = 6	3 * 3 = 9
1 * 4 = 4	2 * 4 = 8	3 * 4 = 12	4 * 4 = 16
1 * 5 = 5	2 * 5 = 10	3 * 5 = 15	4 * 5 = 20	5 * 5 = 25
1 * 6 = 6	2 * 6 = 12	3 * 6 = 18	4 * 6 = 24	5 * 6 = 30	6 * 6 = 36
1 * 7 = 7	2 * 7 = 14	3 * 7 = 21	4 * 7 = 28	5 * 7 = 35	6 * 7 = 42	7 * 7 = 49
1 * 8 = 8	2 * 8 = 16	3 * 8 = 24	4 * 8 = 32	5 * 8 = 40	6 * 8 = 48	7 * 8 = 56	8 * 8 = 64
1 * 9 = 9	2 * 9 = 18	3 * 9 = 27	4 * 9 = 36	5 * 9 = 45	6 * 9 = 54	7 * 9 = 63	8 * 9 = 72	9 * 9 = 81
'''

for i in range(1, 10):  # 1-9
    for j in range(1, i+1):
        print(str(j) + "*" + str(i) + "=" + str(i*j), end="\t")
    print()

