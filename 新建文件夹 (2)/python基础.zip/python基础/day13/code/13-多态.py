

# 面向对象的特征： 封装，继承，多态
#       封装： 将属性和方法封装在类中
#       继承： 子类继承父类的属性和方法, 子类也可以扩展自己的属性和方法
#       多态： 在继承的基础上（一般是多个子类继承同一个父类，且重写父类的同一个方法），使用父类对象指向不同的子类
#              多种形态， 调用不同的子类，会有不同的执行效果
#


# 父类
class Animal(object):
    def beat(self):
        pass


# 子类
class Dog(Animal):
    def beat(self):
        print("汪汪汪的叫~~ 然后再咬你一口")

class Cat(Animal):
    def beat(self):
        print("喵喵喵的叫~~ 然后回头挠你一把")

class Wolf(Animal):
    def beat(self):
        print("嗷嗷嗷的叫~~ 然后把你吃了")


# Person类
class Person(object):
    def __init__(self, name):
        self.name = name

    def beatAnimal(self, animal):
        print(self.name, "正在殴打小动物")
        animal.beat()


# 创建对象
dog = Dog()
cat = Cat()
wolf = Wolf()

xiaoHuang = Person("小黄人")
xiaoHuang.beatAnimal(dog)

