from django.shortcuts import render, reverse
from django.http import HttpResponseRedirect


def index(request):
    old_username = request.session.get("username", "")
    print("old_username:", old_username)
    return render(request, 'sessionApp/index.html', {'username': old_username})


def login(request):
    return render(request, 'sessionApp/login.html')


# 处理登录操作
def login_handle(request):

    errmsg = ""
    if request.method == 'POST':
        username = request.POST.get('username1')

        # 如果用户名有值
        if username:
            # 将username的值存入名称为'username'的session中
            request.session['username'] = username
            return HttpResponseRedirect(reverse('sessionApp:index'))

        else:
            errmsg = '请填写正确的用户名'

    return render(request, 'sessionApp/login.html', {'errmsg': errmsg})


# 注销
def logout(request):
    # 删除session
    del request.session['username']
    return HttpResponseRedirect(reverse('sessionApp:index'))





