


# 大小写

# upper() : 将小写字母变成大写
str1 = "hello WORLD"
print(str1.upper())  # HELLO WORLD

# lower() : 将大写字母变成小写
print(str1.lower())  # hello world

# title() : 把字符串“标题化”,把每个单词的首字母大写，其他小写
str2 = "I love movie"
print(str2.title())  # I Love Movie

# swapcase() : 把大小写翻转
print(str1.swapcase())  # HELLO world

# capitalize() : 把字符串的首字母大写
print(str1.capitalize())  # Hello world


# isupper() : 判断是否所有字母都是大写
str3 = "HELLO123"
print(str3.isupper())  # True

# islower() : 判断是否所有字母都是小写
str4 = "helLO123"
print(str4.islower())  # False

# istitle() : 判断是否是“标题化”的字符串
str5 = "I Like Lol"
print(str5.istitle())  # True


# 对齐方式
# center() : 居中
str6 = "李白"
print(str6.center(60))
print(str6.center(60, "*"))

# ljust() : 居左
print(str6.ljust(60, "-"))

# rjust() : 居右
print(str6.rjust(60, "-"))

print("华丽的分割线".center(80, "*"))



#  字符串截取
# strip() : 将字符串左侧和右侧的指定字符清除，默认清除非空字符,如空格,制表符,换行
# str7 = "      hello   world      "
str7 = "------hello---world------\n\n\t"
print("------------------------------")
print(str7.strip())  # hello---world
print("------------------------------")
# lstrip(): 清除左侧的指定字符
print(str7.lstrip("-"))  # hello---world------

# rstrip(): 清除右侧的指定字符
print(str7.rstrip("-"))  # ------hello---world


# os.path.join()
path = r"C:\wamp\www\day09\code\\"
file = "04-字符串的操作.py"
str4 = path.rstrip("\\") + "\\" + file
print(str4)

