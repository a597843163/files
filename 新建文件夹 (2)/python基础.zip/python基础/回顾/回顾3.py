from  urllib import request

# 发送请求
response = request.urlopen("http://www.baidu.com")
# 读取源码数据
dataStr = response.read().decode("utf-8")

'''
read() :读取全部  2进制字符串
read(1024):按1024个字节读取
readline():按行来读取
readlines():按行读取所有数据，返回列表

'''
# 服务端返回的响应数据
print(response.info())
# 查看响应状态
print(response.getcode())

#  下载/写入本地文件
request.urlretrieve("链接","文件路径及名称")
request.urlcleanup()
#  模拟浏览器访问网页（设置代理）
# 1
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
}
url = "http://www.baidu.com"
myRequest = request.Request(url,headers=headers)
response = request.urlopen(myRequest)
res = response.read().decode("utf-8")
# 2
myRequest = request.Request(url)
myRequest.add_header("User-Agent","Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36")
response1 = request.urlopen(myRequest)
res1 = response.read().decode("utf-8")

#  设置超时时间
myRequest = request.Request(url)
myRequest.add_header("User-Agent","Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36")
response2 = request.urlopen(myRequest,timeout=0.1)
res2 = response.read().decode("utf-8")

#  post 请求
# post接口：http://mrobot.pcauto.com.cn/v2/cms/channels/1
#     参数：pageNo=1&pageSize=20&serialIds=2143,3404&v=4.0.0
import urllib.request
url = "http://mrobot.pcauto.com.cn/v2/cms/channels/1"

paramDict = {
    "pageNo":"1",
    "pageSize":"20",
    "serialIds":"2143,340",
    "v":"4.0.0"
}
# 把参数字典编译成字符串
paramStr = urllib.parse.urlencode(paramDict)
paramData = paramStr.encode("utf-8")

# 把参数放进请求体
myRequest = urllib.request.Request(url,paramData)
response3 = urllib.request.urlopen(myRequest)
resStr = response3.read().decode("utf-8")
print(resStr)

# json格式
import json
# 把字符串转换成json格式对象
str = '{"name": "张三", "age": 33}'
res4 = json.loads(str)
print(res4)







