
import  re
import itertools
print (list(itertools.permutations([1,2,3,4],3)))  # 排列
print(len((list(itertools.permutations([1,2,3,4],3)))))
# itertools.combinations   组合
# itertools.product (" " repeat = )   排列组合
r'''

re.match
原形：match(pattern,string,flags=0)
参数：pattern：匹配的正则表达式
string：要匹配的字符串
flags:标志位，用于控制正则表达式的匹配方式，值如下
re.I      忽略大小写
re.L      做本地识别
re.M      多行匹配，影响^和$
re.S      是.匹配包括换行符在内的所有字符
re.U      根据Unicode字符集解析字符，影响\w \W \b \B
re.X      使我们以更灵活的格式理解正则表达式
  功能：尝试从字符串的起始位置匹配一个模式，如果不是起始位置匹配成功的话
        也会返回None

re.search
  原形：search（pattern，string，flags=0）
  参数：同上
  flags：同上
功能：扫描整个字符串，并返回第一个成功的匹配

re.findall
  原形：findall（pattern，string，flags=0）
  参数：同上
  flags：同上
功能：扫描整个字符串，并返回列表
'''
#  单个字符
r'''
.              匹配除换行符以外的任意字符
[0123456789]   []是字符集合，表示匹配方括号中所有所包含的任意字符
[sunck]        匹配"s","u","n","c","k"  任意一个字符
[a-z]          匹配任意小写字母
[A-Z]          匹配任意大写字母
[0-9]          匹配任意数字  ，类似 [0123456789]
[0-9a-zA-Z_]   匹配任意的数字和字母和下划线
[^sunck]       匹配除了s u n c k 这几个字母以为的所有字符，中括号里的^称为脱字符，表示不匹配集合中的字符
[^0-9]         匹配所有的非数字字符
\d             匹配数字，效果同[0-9]
\D             匹配非数字字符，效果同[^\d]
\w             匹配数字，字母，和下划线，效果同 [0-9a-zA-Z_]
\W             匹配非 数字，字母，和下划线，效果同[^0-9a-zA-Z_]
\s             匹配任意的空白符（空格，换行，回车，换页，制表），效果同[ \f\n\r\t]
\S             匹配任意的非空白符，效果同[^ \f\n\r\t]

'''
# print(re.search(".","sunck is a good man 7"))
# print(re.search("[0123456789]","sunck is a good man 3"))
# print(re.search("[sunck]","sunck is a good man 3"))
# print(re.findall("[^0-9]","sunck is a good man 7"))
# print(re.findall("\D","sunck is a good man 7"))
# print(re.findall("\w","sunck is a good man 7"))

print("----------------锚字符(边界字符)-----------")
'''

^       行首匹配，和在[]里的^不是一个意思
$       行尾匹配
\A      匹配字符串开始，他和^的区别是，\A只匹配整个字符串的开头，即使在re.M模式下也不会匹配他的行首
\Z      匹配字符串结束，他和$的区别是，\Z只匹配整个字符串的开头，即使在re.M模式下也不会匹配他的行尾

\b      匹配一个单词的边界，也就是值单词和空格间的位置
        "er\b"可以匹配never,不能匹配nerve
\B      匹配非单词的边界，

'''
print(re.search("^sunck","sunck is a good man 7"))
# print(re.search("man$","sunck is a good man"))


print(re.findall("^sunck","sunck is a good man\nsunck is a nice man",re.M))
print(re.findall("\Asunck","sunck is a good man",re.M))
print()
print(re.findall("man$","sunck is a good man\nsunck is a nice man",re.M))
print(re.findall("man\Z","sunck is a good man",re.M))
print()
print(re.search(r"er\b","never"))
print(re.search(r"er\b","nerve"))
print(re.search(r"er\B","never"))
print(re.search(r"er\B","nerve"))


print("---------------------匹配多个字符---------------------------")
'''
说明：下方的x、y、z、n、m均为假设的普通字符，n，m为非负整数不是正则表达式的元字符
（xyz）       匹配小括号内的xyz（作为一个整体去匹配）
x?            匹配0个或者1个x
x*            匹配0个或者任意多个X（*表示匹配0个或者任意多个字符(换行符除外)）
x+            匹配至少一个x
x{n}          匹配确定的n个x（n是一个非负整数）
x{n,}         匹配至少n个x
x{n,m}        匹配至少n个最多m个x。注意：n<=m
x|y           |表示或，匹配的是x或y
'''
print(re.findall(r"(sunck)","sunckgood is good man,sunck is a nice man"))
print(re.findall(r"a?","aaa"))      #  非贪婪匹配
print(re.findall(r"a*","aaabaa"))  #  贪婪匹配（尽可能多的匹配）
print(re.findall(r".*","aaabaa"))  #  贪婪匹配（尽可能多的匹配）
print(re.findall(r"a+","aaa"))  #  贪婪匹配（尽可能多的匹配）
print(re.findall(r"a+","aaa"))  #  贪婪匹配（尽可能多的匹配）
print(re.findall(r"a{3}","aaaaaaa"))
print(re.findall(r"a{3,}","aaaabaaa"))  #  贪婪匹配（尽可能多的匹配）
print(re.findall(r"a{3,6}","aaaaaaabaa"))  #  贪婪匹配（尽可能多的匹配）
print()
print(re.findall(r"(s|S)unck","sunck__Sunck"))  #  贪婪匹配（尽可能多的匹配）



print()
str = "sunck is a good man!sunck is a nice man!sunck is a very handsome man"
print(re.findall(r"^sunck.*man$",str))
print(re.findall(r"sunck.*?man",str))
# ['sunck is a good man', 'sunck is a nice man', 'sunck is a very handsome man']

print("-----------------------特殊----------------------------")
'''
*?    +?   x?  最小匹配，通常都是尽可能多的匹配，可以用这种方式解决贪婪匹配

(?:x)       类似(xyz),但他不表示一个组

'''

print(re.findall(r"//*.*?/*/",r"/*  part1  */  /*  part2  */"))
#  ['/*  part1  */', '/*  part2  */']

# 判断手机号
def checkPhone2(str):
    pat = r"^1(([3578]\d)|(47))\d{8}$"
    res = re.match(pat,str)
    print(res)

checkPhone2("13912345678")
checkPhone2("139123456785")



print("-----------------------re模块深入----------------------------")

'''
字符串切割

'''
str1 = "sunck     is a good man"
print(str1.split(" "))
print(re.split(r" +",str1))


'''
re.finditer函数
原形：finditer(pattern,string,flags=0)
参数：
pattern：匹配的正则表达式
string：要匹配的字符串
flags:标志位，用于控制正则表达式的匹配方式
功能：与findall类似，扫描整个字符串，返回的是一个迭代器
'''
str3 = "sunck is a good man! sunck is a nice man!sunck is a handsome man"
d = re.finditer(r"(sunck)",str3)
while True:
    try:
        l = next(d)
        print(d)
    except StopIteration as e :
        break

"""
sunck is a good good good man
字符串的替换和修改
sub(pattern,rep1,string,count=0,flags=0)
sub(pattern,rep1,string,count=0,flags=0)
pattern:正则表达式（规则）
rep1:   指定用来替换的字符
string：目标字符串
count:  最多替换数量
flags:  标志位，用于控制正则表达式的匹配方式
功能：在目标字符串中以正则表达式的规则匹配字符串，再把他们替换成指定的字符串
        可以指定替换的次数，如果不指定，替换所有的匹配字符串

区别:   sub返回一个被替换的字符串，后者返回一个元组，
        第一个元素被替换的字符串，第二个元素表示被替换的次数
"""

str5 = "sunck is a good good good man"
# print(re.sub(r"(good)","nice",str5,count=2))

print(re.subn(r"(good)","nice",str5))
print(type(print(re.subn(r"(good)","nice",str5))))

'''
分组：
概念：除了简单的判断是否匹配之外，正则表达式还有提前子串的功能。
        用()表示的就是提取分组

'''

str6 = "010-53247654"
m = re.match(r"(?P<first>\d{3})-(?P<last>\d{8})",str6)
#使用需要获取对应组的信息，group(0)一直代表的原始字符串
print(m.group(0))
print(m.group(1))
print(m.group(2))
# 查看匹配的各组的情况
print(m.group("first"))  #  起名字，?P<name>



'''
编译：当我们使用正则表达式时，re模块会干两件事
1、编译正则表达式，如果正则表达式本身不合法，会报错
2、用编译后的正则表达式去匹配对象
compile(pattern,flags=0)
pattern:要编译的正则表达式

'''
# pat = r"^1(([3578]\d|(47))\d{8}$"

# 编译成正则对象
# re_telephon = re.compile(pat)
# print(re_telephon.match("13600000000"))



