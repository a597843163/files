from django.shortcuts import render, redirect, reverse
from userDemo import settings
import os
from django.http import HttpResponse
from .models import User
import hashlib
import uuid


def index(request):
    return render(request, 'index2.html')


# 文件上传
def file_upload(request):
    print(11111)
    if request.method == "POST":
        # 获取浏览器提交过来的文件
        my_file = request.FILES.get('myfile', None)
        
        # 没有文件
        if not my_file:
            return redirect(reverse('mediaApp:index'))
        
        # 将上传的文件保存到指定目录
        file_path = os.path.join(settings.MEDIA_ROOT, my_file.name)
        with open(file_path, 'ab') as fp:
            for part in my_file.chunks():
                fp.write(part)
        return HttpResponse("上传成功!")
    
    else:
        return redirect(reverse('mediaApp:index'))


# 多文件上传
def index3(request):
    return render(request, 'index3.html')


def file_upload2(request):
    print(2222)
    if request.method == "POST":
        # 通过getlist来获取多个文件
        my_files = request.FILES.getlist('myfile')
        for my_file in my_files:
            if not my_file:
                return redirect(reverse('mediaApp:index3'))

            # 保存文件
            file_path = os.path.join(settings.MEDIA_ROOT, my_file.name)
            print("file_path: ", file_path)

            with open(file_path, 'ab') as fp:
                for part in my_file.chunks():
                    fp.write(part)

        return HttpResponse("上传成功！")
    else:
        return redirect(reverse('mediaApp:index3'))


# 头像上传
def index4(request):
    return render(request, 'index4.html')


def upload_icon(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        icon = request.FILES.get('icon', None)
        
        if not icon:
            return redirect(reverse('mediaApp:index4'))

        # 生成的随机的32位md5的图片文件名称
        file_name = my_md5() + '.png'

        # 保存文件到后台
        file_path = os.path.join(settings.MEDIA_ROOT, file_name)
        with open(file_path, 'ab') as fp:
            for part in icon.chunks():
                fp.write(part)
                fp.flush()

        # 保存文件的名称或路径到数据库表中
        # User.objects.get_or_create(username=username, icon=file_path)
        # User.objects.get_or_create(username=username, icon=icon.name)
        User.objects.get_or_create(username=username, icon=file_name)

        return HttpResponse("头像上传成功")
    
    else:
        return redirect(reverse('mediaApp:index4'))


def my_md5():
    # uuid：获取唯一标识
    uid = uuid.uuid4()
    uid = str(uid)
    m = hashlib.md5()
    m.update(uid.encode('utf-8'))
    return m.hexdigest()

