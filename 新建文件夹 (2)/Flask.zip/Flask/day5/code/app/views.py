from math import ceil

from flask import Blueprint, render_template, request
from ext import db
# 导入sql 逻辑语句
from sqlalchemy import and_, or_, not_

from .models import Stu  # 模型创建好了以后，需要导入用一下，否则不会加载的
import random

view = Blueprint('view',__name__)

@view.route('/create_table/')
def index():
    db.drop_all()   # 删除表
    db.create_all() # 创建表
    return '创建表'

# 添加一条数据
@view.route('/insert_one/')
def insertOne():
    # try:
    #     stu = Stu(name='张三',sex=False,age=18,info='张三的个人信息')
    #     db.session.add(stu)
    #     #默认开启了事务,要提交
    #     # db.session.commit()  # 提交
    # except:
    #     db.session.rollback()  # 出现错误回滚
    stu = Stu(name='赵六', sex=False, age=18, info='张三的个人信息')
    # 因为设置了staticmethod 可以直接用类名.方法调用
    Stu.save()
    return '数据添加成功'

# 添加多条数据
@view.route('/insert_many/')
def insertMany():
    stu1 = Stu(name='张' + str(random.randrange(10000, 99999)), sex=[True, False][random.randint(0, 1)],
    age=random.randint(10, 30), info=str(random.randrange(10000, 99999)) + '个人简介')

    stu2 = Stu(name='李' + str(random.randrange(10000, 99999)), sex=[True, False][random.randint(0, 1)],
    age=random.randint(10, 30), info=str(random.randrange(10000, 99999)) + '个人简介')
    # 将创建多个数据的对象，放到列表中，执行添加多条数据
    # db.session.add_all([stu1, stu2])
    # db.session.commit()
    # 使用自定义的添加多条数据的方法
    Stu.save_all([stu1,stu2])

    return '添加多条数据'

#修改数据
@view.route('/update/')
def update():
    s =Stu.query.get(1)  # 拿到id为7的数据 返回对象
    print(s)
    print(s.name)
    print(s.info)
    s.name = 'new李小妹'
    # db.session.add(s)
    # db.session.commit()
    s.save()
    return ''

# 数据的删除
@view.route('/delete/')
def delete():
    # 删除id为6的数据
    s = Stu.query.get(12)
    name = s.name
    # db.session.delete(s)
    # db.session.commit()
    Stu.delte()

    return '删除数据为{}'.format(name)


# all获取所有数据查询集
@view.route('/all/')
def all():
    data = Stu.query.all()
    # print(data) # 得到所有对象的id
    for i in data:
        print(i.name)
    return '查询all'

# filter() 添加条件过滤，默认返回所有
# 类名.query.filter([类名.属性名 条件 值])
@view.route('/filter/')
def myFilter():
    # data = Stu.query.filter()  # 默认查询所有
    # data = Stu.query.filter(Stu.id<10)    # 查询id小于10的
    data = Stu.query.filter(Stu.id<10,Stu.sex==False) # 查询id小鱼10且性别为女的
    return render_template('showdata.html',data=data)

@view.route('/filter_by/')
def filter_by():
    data = Stu.query.filter_by()  # 默认查询所有
    # data = Stu.query.filter_by(id=1)
    # data = Stu.query.filter_by(sex=False)
    data = Stu.query.filter_by(sex=False, id=10)
    # 只能支持关键字参数的形式 名=值  不能存在其他符号 以下为错误的写法
    # data = Stu.query.filter_by(sex=False, id > 10)
    return render_template('showdata.html',data=data)


# 偏移量
@view.route('/offset/')
def myOffset():
    # 取出偏移5条的数据
    data = Stu.query.offset(5)
    # 报错，all拿到的是列表，不是查询集
    # data = Stu.query.all().offset(5)
    return render_template('showdata.html',data=data)

# 取出num数据，通常offset和limit合作使用
@view.route('/limit/')
def myLimit():
    # 取出5条的数据
    # data = Stu.query.limit(5)
    # 偏移几条取出几条数据
    data = Stu.query.offset(5).limit(5)
    return render_template('showdata.html', data=data)

# 分页
@view.route('/page/')
def page():
    num = 5   # 每页显示数据的条数
    countPage = ceil(12/num)  # 总页数
    try:
        nowPage = int(request.args.get('page',1))  # 拿到请求第几页参数
        if nowPage >=countPage:
            nowPage = countPage
    except:
        nowPage = 1
    offset = (nowPage-1)*num
    data = Stu.query.offset(offset).limit(num)   # 每一页的数据
    return render_template('showdata.html', data=data)

# 排序
@view.route('/order_by/')
def orderBy():
    # 升序
    data = Stu.query.order_by(Stu.id)
    # 降序
    # data = Stu.query.order_by(-Stu.id)
    # 拿id最大的数据
    data = Stu.query.order_by(-Stu.id).limit(1)
    return render_template('showdata.html', data=data)

@view.route('/first/')
def myFirst():
    # 取出查询集的第一条数据
    data = Stu.query.first()  # 一个对象不能被迭代
    return render_template('showdata.html', data=data)

@view.route('/get/')
def get():
    data = Stu.query.get(1)  # 一个对象不能被迭代
    print(data)
    return render_template('showdata.html', data=data)

# 包含关系  类似SQL语句like
@view.route('/contains/')
def myContains():
    # 等用于 select * from stu where name like '%张%'
    data = Stu.query.filter(Stu.name.contains('张'))
    return render_template('showdata.html', data=data)

# 模糊查询like
@view.route('/like/')
def myLike():
    # 等用于 select * from stu where name like '%张%'
    data = Stu.query.filter(Stu.name.like('%张%')) # 包含张
    data = Stu.query.filter(Stu.name.like('张%')) # 以张开头
    data = Stu.query.filter(Stu.name.like('%张')) # 以张结尾
    return render_template('showdata.html', data=data)

# startswith  和endswith 以...开头  以...结尾
@view.route('/startend/')
def startend():
    # 以张作为开头
    # data = Stu.query.filter(Stu.name.startswith('张'))
    # 以张作为结尾
    data = Stu.query.filter(Stu.name.endswith('张'))
    return render_template('showdata.html', data=data)

# 比较运算符
@view.route('/ge/')
def  ge():
    # 大于18
    # data = Stu.query.filter(Stu.age.__gt__(18))
    # data = Stu.query.filter(Stu.age>18)
    # 大于等于
    # data = Stu.query.filter(Stu.age.__ge__(18))
    # data = Stu.query.filter(Stu.age>=18)
    # 小于
    # data = Stu.query.filter(Stu.age.__lt__(18))
    # data = Stu.query.filter(Stu.age<18)
    # 小于等于
    # data = Stu.query.filter(Stu.age.__le__(18))
    data = Stu.query.filter(Stu.age<=18)
    return render_template('showdata.html', data=data)

# in  not in
@view.route('/in/')
def myIn():
    # 查询id在 1.3.5的数据
    # data = Stu.query.filter(Stu.id.in_([1,3,5]))
    # 查询id不在 1.3.5的数据
    data = Stu.query.filter(~Stu.id.in_([1,3,5]))
    return render_template('showdata.html', data=data)

# 查询null或者不为null的数据
@view.route('/null/')
def myNull():
    # 查询为名字为空的数据
    # data = Stu.query.filter(Stu.name==None)
    # data = Stu.query.filter(Stu.name.is_(None))
    # 查询不为名字为空的数据
    # data = Stu.query.filter(Stu.name != None)
    # data = Stu.query.filter(~Stu.name.is_(None))
    data = Stu.query.filter(Stu.name.isnot(None))
    return render_template('showdata.html', data=data)

# ------------ 数据库的逻辑查询 ------------ #
# 逻辑与
@view.route('/andornot/')
def andornot():
    # 逻辑与
    # data = Stu.query.filter(Stu.sex==False,Stu.age<18)
    # data = Stu.query.filter(and_(Stu.sex==False,Stu.age<18))
    # 逻辑或
    # data = Stu.query.filter(or_(Stu.sex==False,Stu.age<18))
    # and 和or合并
    # data = Stu.query.filter(or_(Stu.sex==False,Stu.age<18),Stu.name.isnot(None))
    # 逻辑非not_
    # data = Stu.query.filter(~Stu.sex==True)
    data = Stu.query.filter(not_(Stu.sex==True))
    # data = Stu.query.filter(not_(Stu.sex==True,Stu.age<18)) 错误写法,not里面只能放一个参数
    # 统计函数,统计数量
    # data = Stu.query.filter(not_(Stu.sex==True)).count()
    return render_template('showdata.html', data=data)


# 让路由可以用正则匹配
@view.route('/r/<regex("\w{2}"):data>')
def r(data):
    # .* 贪婪模式
    # .*？ 非贪婪模式
    # (?:) # 将括号只作为一个单元来存储
    return data



