


# 登录功能
def login():
    print("packagetest包中的module5")


print("模块5")










