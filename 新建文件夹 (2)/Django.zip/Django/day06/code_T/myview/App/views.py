from django.shortcuts import render
from django.http import (
    HttpResponse,
    HttpRequest,
    JsonResponse,
    HttpResponseRedirect,
    HttpResponseNotFound,
)


def index(request):
    # return render(request, 'myview/index.html')
    # return HttpResponse("Welcome to 深圳")
    # return JsonResponse({'name':'宝强', 'age': 33})
    # return HttpResponseNotFound("Not Found!")
    # return HttpResponseRedirect('http://www.baidu.com')

    # request的属性和方法
    print(request.path)  # /app/index/
    print(request.method)  # GET
    print(request.encoding)  # None
    print(request.GET)  # <QueryDict: {'name': ['1', '2'], 'pwd': ['22']}>
    print(request.POST)  # <QueryDict: {}>
    print(request.FILES)  # <MultiValueDict: {}>
    print(request.COOKIES)  # {'csrftoken': '7CgGKeLOolSWEwdyDyfv4bIyDGRSIu1ppMyhOzsbITSrVcvymt4UXYoOVpbk78JC'}
    print(request.session)  # <django.contrib.sessions.backends.db.SessionStore object at 0x000000000436AE10>

    print(request.get_full_path())  # /app/index/?name=1&pwd=22
    print(request.is_ajax())  # False

    print(request.GET.get('name'))  # 2
    print(request.GET.getlist('name'))  # ['1', '2']

    # return HttpResponse("Welcome to 深圳")

    # response的属性和方法
    response = HttpResponse("Welcome to 西部硅谷")
    response.content = "你好 西部硅谷"
    # response.status_code = 404
    response.write(" 欢迎再来")  # 追加的数据
    response.flush()

    return response





