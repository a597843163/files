from django.db import models


class User(models.Model):
    username = models.CharField(max_length=30, unique=True)
    password = models.CharField(max_length=40)
    age = models.PositiveIntegerField(default=1, null=True, blank=True)
    token = models.CharField(max_length=50, default="", null=True, blank=True)


