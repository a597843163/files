

'''

    列表list的操作：
        1，创建列表
        2，增: 列表增加数据
        3，删：把列表中的元素删除
        4，改：修改列表中的元素
        5，查：查询列表中的数据

'''

# 创建列表
list1 = [11, 22, 33, 44, 55]
print(list1)


# 增
# append() : 追加一个元素
list1.append(66)
print(list1)   # [11, 22, 33, 44, 55, 66]

# extend() : 追加多个元素
# list1.append([77, 88])  # [11, 22, 33, 44, 55, 66, [77, 88]]
list1.extend([77, 88])
print(list1)  # [11, 22, 33, 44, 55, 66, 77, 88]

# insert() : 插入元素
# 参数1：表示要插入的位置(下标)
# 参数2：表示要插入的值
# 注意：插入位置的后面所有元素往后面移动一个位置
list1.insert(3, 999)
print(list1)  # [11, 22, 33, 999, 44, 55, 66, 77, 88]


# 删除
list1 = [11, 22, 33, 44, 55]

#删除列表
# del list1
# print(list1)  # 报错

# pop() : 根据元素的下标 删除元素，默认是删除最后一个元素, 并返回删除的元素值
res = list1.pop()
res = list1.pop(2)  # 删除对应下标的元素
print(list1)  # [11, 22, 44, 55]
print(res)  # 33

# remove() : 根据元素的值 删除元素，删除第一次匹配的元素
list1 = [11, 22, 33, 44, 55, 33, 33]
res = list1.remove(33)
print(list1)  # [11, 22, 44, 55]
print(res)  # None

# count(): 统计列表中指定元素出现的次数
list1 = [11, 22, 33, 44, 55, 33, 33]
print(list1.count(33))  # 3

# 删除所有的33
for i in range(list1.count(33)):
    list1.remove(33)
print(list1)  # [11, 22, 44, 55]

# clear(): 清空列表
list1.clear()
print(list1)  # []



# 改
list1 = [11, 22, 33, 44, 55, 22]
list1[2] = "999"
print(list1)  # [11, 22, '999', 44, 55, 22]


# 查
print(list1[2])  # '999'
print(type(list1[2]))  # <class 'str'>

# index(): 获取指定元素在列表中第一次出现的对应的下标，如果不存在，则会报错（出现异常）
print(list1.index('999'))  # 2
print(list1.index(22))  # 1
# print(list1.index(99))  # 报错

