

import os

# 获取文件的路径
# C:\wamp\www\day08\code\情书.txt
print(os.path.abspath(""))


# 将目录和文件拼接成一个完整的路径
# C:\wamp\www\day08\code\情书.txt
print(os.path.join(r"C:\wamp\www\day08\code", "情书.txt"))


# 把完整的路径拆分成目录和文件名
# ('C:\\wamp\\www\\day08\\code', '情书.txt')
print(os.path.split(r"C:\wamp\www\day08\code\情书.txt"))

# 将文件的文件名和扩展名拆分
# ('情书', '.txt')
print(os.path.splitext("情书.txt"))


# path1 = r"C:\wamp\www\day08\code"   # 目录
# path2 = r"C:\wamp\www\day08\code\情书.txt"  # 文件

path1 = "..\\code"   # 目录
path2 = ".\\情书.txt"  # 文件
# 判断是否是文件
print(os.path.isfile(path1))  # False
print(os.path.isfile(path2))  # True

# 判断是否是目录
print(os.path.isdir(path1))  # True
print(os.path.isdir(path2))  # False

# 判断文件或目录是否存在
print(os.path.exists(path1))  # True
print(os.path.exists(path2))  # True





