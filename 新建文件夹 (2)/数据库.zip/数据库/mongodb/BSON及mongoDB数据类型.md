# BSON及mongoDB数据类型

> > JSON是一种被广泛使用的轻量级的数据交换格式，支持现今绝大多数主流的开发语言。而近几年崛起的mongDB则采用了类JSON的数据格式，在JSON之上进行了丰富和增强，使得mongoDB可以处理及报错更大的数据类型。本文就2者进行描述同时给出mongoDB支持的数据类型。

## 一、JSON特性

```python
1、什么是JSON
        JSON(JavaScript Object Notation) 是一种轻量级的数据交换格式。
        JSON采用完全独立于语言的文本格式，但也使用了类似于C语言家族的习惯(包括C、C++、C#、Java、JavaScript、Perl、Python等）。
        这些特性使JSON成为理想的数据交换语言。 易于人阅读和编写，同时也易于机器解析和生成(一般用于提升网络传输速率)。
        可以详细参考：http://www.json.org.cn/

2、JSON 数据的书写格式
        名称/值对 对象
        是一个无序的“‘名称/值’对”集合。一个对象以“{”（左括号）开始，“}”（右括号）结束。
        每个“名称”后跟一个“:”（冒号）；“‘名称/值’ 对”之间使用“,”（逗号）分隔。
        如：  ({"firstName":"John"})，更多的格式见本文第而部分BSON支持的数据类型
        等价于这条 JavaScript 语句： firstName="John"

3、JSON仅支持以下数据类型
        数字（整数或浮点数）
        字符串（在双引号中）
        逻辑值（true 或 false）
        数组（在方括号中）
        对象（在花括号中）
        null

4、JSON基于两种结构：
        “名称/值”对的集合（A collection of name/value pairs），在不同的编程语言中有不同的描述
                    如：对象（object），纪录（record），结构（struct），字典（dictionary）
                    哈希表（hash table），有键列表（keyed list），或者关联数组 （associative array）
        值的有序列表。在大部分语言中，它被实现为数组(array)，矢量(vector)，列表(list)，序列(sequence)1234567891011121314151617181920212223242526
```

## 二、BSON特性

```Python
1、什么是BSON
        BSON（）是一种类json的一种二进制形式的存储格式，简称Binary JSON
        它和JSON一样，支持内嵌的文档对象和数组对象，但是BSON有JSON没有的一些数据类型，如Date和BinData类型。
        https://docs.mongodb.com/manual/reference/bson-types/

2、BSON的特性
    轻量性、可遍历性、高效性

3、mongoDB与BSON
        mongoDB对JSON串做了一些增加，使其可以支持更多的数据类型，并且将其作为存储结构
        mongoDB这种格式转化成一文档这个概念(Document)，因为BSON是schema-free的，所以在MongoDB中所对应的文档也有这个特征
        mongoDB以BSON做为其存储结构的一种重要原因是其可遍历性123456789101112
```

4、演示mongoDB支持的数据类型 
//null值

> db.mycol.insert({x:null}) 
> WriteResult({ “nInserted” : 1 })

//布尔型，用于存储布尔值（真/假）

> db.mycol.insert({x:true}) 
> WriteResult({ “nInserted” : 1 })

//小数

> db.mycol.insert({x:3.1515}) 
> WriteResult({ “nInserted” : 1 })

//整数，用于存储数值。根据你所采用的服务器，可分为 32 位或 64 位

> db.mycol.insert({x:3}) 
> WriteResult({ “nInserted” : 1 })

//4字节带符合整数

> db.mycol.insert({x:NumberInt(“3”)}) 
> WriteResult({ “nInserted” : 1 })

//8字节带符号整数

> db.mycol.insert({x:NumberLong(“3”)}) 
> WriteResult({ “nInserted” : 1 })

//字符型，存储数据常用的数据类型。在 MongoDB 中，UTF-8 编码的字符串才是合法的

> db.mycol.insert({x:”robin”}) 
> WriteResult({ “nInserted” : 1 })

//日期型

> db.mycol.insert({x:new Date()}) 
> WriteResult({ “nInserted” : 1 })

//正则表达式

> db.mycol.insert({x:/u01/i}) 
> WriteResult({ “nInserted” : 1 })

//数组，用于将数组或列表或多个值存储为一个键

> db.mycol.insert({x:[“a”,”b”,”c”]}) 
> WriteResult({ “nInserted” : 1 })

//嵌套文档，用于内嵌文档

> db.mycol.insert({x:{y:”nested”}}) 
> WriteResult({ “nInserted” : 1 })

//对象id

> db.mycol.insert({x:ObjectId()}) 
> WriteResult({ “nInserted” : 1 })

//代码段

> db.mycol.insert({x:function(){/*This is a test code*/}}) 
> WriteResult({ “nInserted” : 1 })

//查找集合mycol的文档

> db.mycol.find({},{_id:0}) 
> { “x” : null } 
> { “x” : true } 
> { “x” : 3.1515 } 
> { “x” : 3 } //Author : Leshami 
> { “x” : 3 } //Blog : [http://blog.csdn.net/leshami](http://blog.csdn.net/leshami) 
> { “x” : NumberLong(3) } 
> { “x” : “robin” } 
> { “x” : ISODate(“2016-09-06T02:46:35.173Z”) } 
> { “x” : /u01/i } 
> { “x” : [ “a”, “b”, “c” ] } 
> { “x” : { “y” : “nested” } } 
> { “x” : ObjectId(“57ce2f34ce8685a6fd9df3ae”) } 
> { “x” : function (){/*This is a test code*/} }

//undefined类型

> db.mycol.insert({name:undefined}); 
> WriteResult({ “nInserted” : 1 }) 
> db.mycol.insert({name:”123”}); 
> WriteResult({ “nInserted” : 1 }) 
> printjson(db.mycol.find().toArray()) 
> [ 
> { 
> “_id” : ObjectId(“57ce1cc8c60f1fe489e49c68”), 
> “name” : undefined 
> }, 
> { 
> “_id” : ObjectId(“57ce1cdbc60f1fe489e49c69”), 
> “name” : “123” 
> } 
> ]

//查找undefined类型的文档

> db.mycol.find({name:”undefined”}) 
> db.mycol.find({name:undefined}) 
> Error: error: { 
> “waitedMS” : NumberLong(0), 
> “ok” : 0, 
> “errmsg” : “cannot compare to undefined”, 
> “code” : 2 
> }
>
> db.mycol.find({name:{$type:6}}) 
> { “_id” : ObjectId(“57ce1cc8c60f1fe489e49c68”), “name” : undefined }
>
> db.mycol.find({name:{$type:”undefined”}}) 
> { “_id” : ObjectId(“57ce1cc8c60f1fe489e49c68”), “name” : undefined }

//mongoDB数据类型的比较与排序优先级 
1) MinKey (internal type) 
2) Null 
3) Numbers (ints, longs, doubles) 
4) Symbol, String 
5) Object 
6) Array 
7) BinData 
8) ObjectId 
9) Boolean 
10) Date 
11) Timestamp 
12) Regular Expression 
13) MaxKey (internal type)

```python
5、关于_id与Object_Id
mongoDB中每一个文档都必须有一个"_id"键，该键等同于RDBMS中的主键，只不过这个主键是由mongoDB自动生成
"_id"键的值可以使用任意类型，可以不使用系统创建，而由用户自定义的规则生成
"_id"为轻量级，全局唯一，可类比为MySQL数据中的GTID，也用于解决不同机器副本集复制时唯一性问题

a 4-byte value representing the seconds since the Unix epoch,  //时间戳
a 3-byte machine identifier,                                   //机器唯一标识码
a 2-byte process id, and                                       //进程ID
a 3-byte counter, starting with a random value.                //随机数123456789
```

> db.mycol.findOne() 
> { “_id” : ObjectId(“57ce2d4cce8685a6fd9df3a3”), “x” : null } 
> 57ce2d4c //时间戳 ==>1473129804 ==> 2016/9/6 10:43:24 
> ce8685 //机器唯一标识码 
> a6fd //进程ID 
> 9df3a3 //随机数