from selenium  import webdriver

from time import sleep

driver = webdriver.Chrome()


driver.get('https://www.douban.com/')
print(driver.current_url)
driver.find_element_by_xpath('//a[@class="lnk-movie"]').click()
print(driver.current_url)

handles = driver.window_handles

sleep(2)
driver.switch_to.window(handles[0])
print(driver.current_url)
sleep(2)
driver.switch_to.window(handles[1])
print(driver.current_url)
sleep(2)
driver.close()
sleep(2)
driver.quit()
print(handles)

