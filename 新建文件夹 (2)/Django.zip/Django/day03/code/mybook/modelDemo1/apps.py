from django.apps import AppConfig


class Modeldemo1Config(AppConfig):
    name = 'modelDemo1'
