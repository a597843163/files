

'''
    字典dict: dictionary
        格式： {key:value, key2:value2,...}
        key：键
        value: 值
        key-value: 键值对

    字典： 是以key-value（键值对）的形式存储数据的， 查找速度快

    key:
        1, 是唯一的
        2， key是不可变类型：字符串，数字
        3， 是无序的
'''

# 创建字典
dict1 = {}
print(dict1)  # {}
print(type(dict1))  # <class 'dict'>

# list1 = ["宝强哥", 36]
# 列表：一般保存相同类型的数据
# 字典：一般用来保存同一个对象的不同属性
dict1 = {"name": "宝强哥", "age": 36}
print(dict1)  # {'name': '宝强哥', 'age': 36}

# 后面的age会覆盖前面的age
dict1 = {"name": "宝强哥", "age": 36, "age": 18}
print(dict1)  # {'name': '宝强哥', 'age': 18}

# 可变类型不可以作为key
# dict1 = {"name": "宝强哥", "age": 36, [1,2]: "halo"}
# print(dict1)


# 查
print(dict1["name"])  # 宝强哥
print(dict1["age"])   # 18
# print(dict1["sex"])  # 报错, 如果key不存在则会报错

# get() : 可以获取字典中对应key的value值，如果key不存在则返回None但不会报错
#         如果存在则使用存在的value，如果不存在则使用第二个参数
print(dict1.get("sex", "男"))


# 增，改
# 增：当key不存在时就会增加一个键值对
# 改：当key存在时就会修改该键值对
personDict = {"name":"老王", "age":20, "sex":"男"}
personDict["qq"] = "123456"
print(personDict)  # {'name': '老王', 'age': 20, 'sex': '男', 'qq': '123456'}

personDict["sex"] = "女"
print(personDict)  # {'name': '老王', 'age': 20, 'sex': '女', 'qq': '123456'}


# 删除
# pop()： 删除对应key的键值对，返回key对应的value值
#         如果不存在key，则会报错，如果再加上第二个参数，则不会报错，且会返回第二个参数的值
personDict = {"name":"老王", "age":20, "sex":"男"}
res = personDict.pop("sex1", "人妖")
print(personDict)  # {'name': '老王', 'age': 20, 'sex': '男'}
print(res)  # 人妖

# popitem() : 随机删除字典中的键值对,因为字典是无序的，所以这里删除的是随机的其中一项
personDict.popitem()
print(personDict)
personDict.popitem()
print(personDict)

# clear() : 清空字典
personDict = {"name":"老王", "age":20, "sex":"男"}
# personDict.clear()
# print(personDict)  # {}


# 判断name是否是personDict的key
print("name" in personDict)  # True


# 遍历
personDict = {"name":"老王", "age":20, "sex":"男"}
print('我',personDict.items())

# 方式1（掌握）：
for key in personDict:
    print(key)  # 键
    print(personDict[key])  # 值

# 方式2(不推荐)：
for i in range(len(personDict)):
    print(i)  # 下标

# 方式3（不推荐）:
for i, key in enumerate(personDict):
    print(i, key)  # 下标，键


# 方式4
for key in personDict.keys():
    print(key)  # 键

# 方式5：
for value in personDict.values():
    print(value)  # 值

# 方式6：
for key, value in personDict.items():
    print(key, value)  # 键，值


# list 和 dict 的区别：
#    dict:  1，书写格式：{"name":"宝强","age":33}
#           2，字典查询和插入数据的速度极快, 随着保存的数据量的增大，对速度影响不大
#           3，消耗内存会较大
#    list:  1,书写格式：[1,2,3]
#           2, 列表查询和插入数据的速度相对字典而已较慢，随着保存的数据量的增大，对速度的影响较大
#           3，消耗内存相对较小
#
#  存储一个人的信息： {"name":"宝强", "age":33}
#  存储多个人的信息：
#      [{"name":"宝强", "age":33}, {"name":"马蓉", "age":30}, {"name":"宋喆", "age":32}]
#





