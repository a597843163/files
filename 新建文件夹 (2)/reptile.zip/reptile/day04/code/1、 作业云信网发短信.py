import json
import random
import urllib.request
import urllib.parse
import hashlib
import time
import string


# 封装发短信的函数
def send_sms():
    # 请求的api地址
    api = 'https://api.netease.im/sms/sendcode.action'

    # 准备headers数据
    # 开发者平台分配的appkey
    app_key = '900982c9e79901b045032ce89a97cf33'
    # 随机数（最大长度128个字符）
    nonce = ''.join(random.sample(string.ascii_letters + string.digits, 20))
    # 当前UTC时间戳，从1970年1月1日0点0 分0 秒开始到现在的秒数(String)
    cur_time = str(int(time.time()))
    app_secret = '74e954691b5d'
    # CheckSum是：SHA1(AppSecret + Nonce + CurTime),三个参数拼接的字符串，进行SHA1哈希计算，转化成16进制字符(String，小写)
    sum_str = app_secret + nonce + cur_time
    hash = hashlib.sha1()
    hash.update(sum_str.encode('utf-8'))
    check_sum = hash.hexdigest()

    # headers
    headers = {
        'AppKey': app_key,
        'Nonce': nonce,
        'CurTime': cur_time,
        'CheckSum': check_sum
    }

    data = {
        'mobile': '18320770647',
        'codeLen': 6,
    }
    # 编码,POST请求用urlencode来编码url的参数
    data = urllib.parse.urlencode(data).encode('utf-8')
    # 创建request对象
    req = urllib.request.Request(url=api, headers=headers, data=data)

    # 发送请求
    response = urllib.request.urlopen(req)

    # print(response.read().decode('utf-8'))
    # 生成json对象
    obj = json.loads(response.read())

    json_string = json.dumps(obj, ensure_ascii=False)
    print(json_string)


if __name__ == '__main__':
    send_sms()