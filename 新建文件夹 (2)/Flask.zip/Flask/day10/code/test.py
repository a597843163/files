from werkzeug.security import generate_password_hash,check_password_hash
# password_hash = generate_password_hash('abcdefg')
# print(password_hash)
# print(check_password_hash(password_hash,'abcdef'))
"""

class A:
    # __age = 18
    @property
    def age(self):
        return self.__age
    @age.setter
    def age(self,arg):
        self.__age = arg
    def getxxx(self):
        # print(self.__xxx)
        self.__dict__['__xxx'] = '新的值'
        print(self.__dict__['__xxx'])
a = A()
# a.age=10
a.__xxx = 'abcd'
# print(a.age)
# print(a.__dict__)
# print(a.getxxx())
# print(a.__xxx)
"""
# from itsdangerous import TimedJSONWebSignatureSerializer as Serialize
# s = Serialize('abcd')
# token = s.dumps({'id':1})
#
# token_check = Serialize('abcd')
# print(token_check.loads(token))
"""
str = 'abcd'
del str
print(str)
# Str = 'abcd'
# del Str
# print(Str)

myDict = {[1,2,3]:'ABC'}
# myDict = {(1,2,3):'ABC'}
print(myDict)

img ; width>height  height>width
#300  400
# 300 200
#300   150
#150   200
if width>height:
    height
else height>width:
    with

"""



