from django.conf.urls import url
from .views import authors,index
urlpatterns = [
url('^authors/$',index,name='index'),
    url('^authors/(\d+)$',authors,name='authors')
]