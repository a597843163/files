$(function () {
    // 点击全部类型
    $("#all_type").click(function () {
        // $("#sort_rule_container").hide();
        // $("#sort_rule_icon").removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down')
        $("#all_type_container").toggle();  //切换显示和隐藏
        $("#all_type_icon").toggleClass('glyphicon-chevron-down').addClass('glyphicon-chevron-up')
        // 主动触发$("#sort_rule_container") 的click事件
        $("#sort_rule_container").triggerHandler('click')
    });


    $("#all_type_container").click(function () {
        $(this).hide(); //隐藏
        $("#all_type_icon").removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down')

    });

    // 点击综合排序
    $("#sort_rule").click(function () {
        // $("#all_type_container").hide();
        // $("#all_type_icon").removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down')
        $('#sort_rule_container').toggle();
        $("#sort_rule_icon").toggleClass('glyphicon-chevron-down').addClass('glyphicon-chevron-up')
        $("#all_type_container").triggerHandler('click')

    });

    $("#sort_rule_container").click(function () {
       $(this).hide();
       $("#sort_rule_icon").removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down')
    });



});