from urllib import request
import re
import os

def getData(url):

    userAgent ="Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.162 Safari/537.36"
    myRequest = request.Request(url)
    myRequest.add_header("User-Agent",userAgent)

    response = request.urlopen(myRequest)
    htmlStr = response.read().decode("utf-8")

    imReg1 = '<img alt=".*" src="(.*?)" class="s-access-image cfMarker" height="260" width="200"></a></div>'
    imReg2 = 'data-a-image-source="(.*?)"></div></a></div>'
    imgCom1 = re.compile(imReg1)
    imgCom2 = re.compile(imReg2)

    imgList1 = imgCom1.findall(htmlStr)
    imgList2 = imgCom2.findall(htmlStr)
    print(len(imgList1))
    print(len(imgList2))

    imgList1.extend(imgList2)

    # 遍历imgList1,将所有的图片存储到本机
    for imgSrc in imgList1:
        path =r"C:\Users\sdsd\Desktop\图片名\\"
        index =imgSrc.rfind("/")
        fileName = imgSrc[index+1:]
        absPath = os.path.join(path,fileName)

        request.urlretrieve(imgSrc,absPath)
        request.urlcleanup()

if __name__ == "__main__":
    # url = "https://www.amazon.cn/s/ref=lp_2152154051_pg_2?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=2&ie=UTF8&qid=1516169582"
    # url = "https://www.amazon.cn/s/ref=sr_pg_3?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=3&ie=UTF8&qid=1516169970"
    url = "https://www.amazon.cn/s/ref=sr_pg_4?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=4&ie=UTF8&qid=1516171321"
    getData(url)




