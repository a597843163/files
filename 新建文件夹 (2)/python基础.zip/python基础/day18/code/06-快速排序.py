


# 快速排序
# 时间复杂度

'''

        [3, 4, 8, 7, 5, 9, 6, 1, 2]
        [3, 4, 1, 2]               [5]   [8, 7, 9, 6]
        [3, 1, 2]        [4] []    [5]   [6] [7] [8, 9]
        [] [1] [3,2]     [4] []    [5]   [6] [7] [][8][9]
        [] [1] [2][3][]  [4] []    [5]   [6] [7] [][8][9]

'''

# 快速排序
def quickSort(list):

    # 临界值
    if len(list) <= 1:
        return list

    # 取出列表中间的数
    centerIndex = len(list)//2
    center = list.pop(centerIndex)

    # 遍历列表，将小于center的数放在leftList中，大于center的数放在rightList中
    leftList = []
    rightList = []
    for i in list:
        if i < center:
            leftList.append(i)
        else:
            rightList.append(i)

    # 递归
    return quickSort(leftList) + [center] + quickSort(rightList)


list1 = [3, 4, 8, 7, 5, 9, 6, 1, 2]
list1 = quickSort(list1)
print(list1)  # [1, 2, 3, 4, 5, 6, 7, 8, 9]













