import jsonpath
import requests
import json

url = 'http://www.lagou.com/lbs/getAllCitySearchLabels.json'


r = requests.get(url=url)

# 把json字符串转换成python字典
obj = json.loads(r.text)
city_list = jsonpath.jsonpath(obj, '$..name')
print(city_list)

# 把列表转换成json对象
json_obj = json.dumps(city_list, ensure_ascii=False)
# 写入文件。
with open('./city_list.json', 'w', encoding='utf-8') as fp:
    fp.write(json_obj)

