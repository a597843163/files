


# 银行
# Bank
#   属性：用户账户的字典
#   方法：开户  查询  存款  取款  转账 改密 锁定 解锁 补卡 销户 退出

import random
import pickle
import os
from card import Card
from user import User


class Bank(object):

    # 构造函数
    def __init__(self):
        self.userDict = {}  # key:银行卡号， value:用户对象
        self.path = "users.txt"  # 用户文件目录
        self.__getAllUser()
        print(self.userDict)

    # 把原来的所有用户从文件中取出
    def __getAllUser(self):
        if os.path.exists(self.path):
            fp = open(self.path, "rb")
            self.userDict = pickle.load(fp)
            fp.close()

    # 把所有用户存入文件中
    def __saveAllUser(self):
        fp = open(self.path, "wb")
        pickle.dump(self.userDict, fp)
        fp.close()

#------------------------ 开户 -------------------------------#
    # 开户
    def createUser(self):

        # 创建卡对象
        # 创建用户对象

        usernameInput = input("请输入您的开户人姓名:")
        idcardInput = input("请输入您的身份证:")
        phoneInput = input("请输入您的手机号:")

        # 创建卡
        cardid = self.__createCardId()  # 创建一个随机的银行卡号(6位)
        passwd = self.__setPasswd()  # 设置密码
        if passwd == -1:  # 恶意用户
            print("三次输入都错误，创建用户失败！")
            return
        money = input("请输入您要存入的金额:")

        # 银行卡对象
        card = Card(cardid, passwd, float(money))
        print(card)

        # 用户对象
        user = User(usernameInput, idcardInput, phoneInput, card)
        print(user)

        # 将创建的用户和卡存入到字典userDict中
        self.userDict[cardid] = user
        print(self.userDict)

        # 本地保存
        self.__saveAllUser()


    # 创建银行卡id
    def __createCardId(self):

        while True:
            cardid = ""  # 6位随机银行卡号
            for i in range(6):
                cardid += str(random.randrange(0, 10))

            # 如果不存在相同的银行卡号，则返回
            if not cardid in self.userDict:
                return cardid

    # 设置密码
    def __setPasswd(self):

        # 允许用户输入最多3次
        for i in range(3):

            passwd1 = input("请输入您的新密码:")
            again = input("请再次输入您的新密码:")

            # 输入正确,则返回密码
            if passwd1 == again:
                return passwd1

            # 如果第3次输入也错误，则返回-1
            if i == 2:
                return -1

            print("您输入的密码不匹配，请重新输入")



# ------------------------ 查询 -------------------------------#
    # 查询
    def searchUser(self):
         x = self.__cardIdError()  # 返回一个user对象和card对象
         if x == None  :
             return
         print("您的余额为:%.2f"%x[1].money)
        # 输入银行卡号
        #     判断是否输入有误
        # 输入卡号对应的密码
        # 显示余额

    # 封装函数，输入卡号，判断卡号是否异常
    def  __cardIdError(self):
        # 输入卡号
        cardId = input("请输入要操作的卡号:")
        if not cardId in self.userDict:
            print("卡号输入有误")
            return

        user = self.userDict[cardId]
        card = user.card  # 银行卡对象

        # 先判断该卡是否已锁住
        if card.isLock == True:
            print("该卡已锁住，请先解锁")
            return

        # 输入密码
        res = self.__checkPasswd(card)
        if res == False:  # 输入错误3次，把卡锁住
            print("输入密码错误3次，卡已锁住")
            card.isLock = True
            self.__saveAllUser()  # 重新保存到文件
            return
        return user,card

    # 检查密码是否正确
    def __checkPasswd(self, card):
        for i in range(3):
            passwd = input("请输入密码:")
            if passwd == card.passwd:   # 密码正确
                return True
            if i == 2:   # 密码输入错误3次
                return False
            print("密码输入有误，请重新输入")



# ------------------------ 存款 -------------------------------#
    # 存款
    def saveMoney(self):
        x = self.__cardIdError()       # 返回一个user对象和card对象
        if x == None:
            return
        money = input("请输入要存入的钱:")
        x[1].money += float(money)
        print("存款成功！目前余额: %.2f" % x[1].money)
        self.__saveAllUser()  # 重新保存到文件


# ------------------------ 取款 -------------------------------#
    # 取款
    def getMoney(self):
        x = self.__cardIdError()
        if x == None:
            return
        # 输入要取出的钱
        money = input("当前余额:%.2f, 请输入要取出的钱:"%x[1].money)
        res2 = x[1].money - float(money)
        if res2 < 0:
            print("操作失败，余额不足！")
            return

        x[1].money = res2
        print("取款成功！目前余额: %.2f" % x[1].money)
        self.__saveAllUser()  # 重新保存到文件

# ------------------------ 转账 -------------------------------#
    # 转账
    def transferMoney(self):
        x1 = self.__cardIdError()       # 得到卡对象card1
        if x1 == None:
            return
        n = input("请输入要转入的卡号:")
        if  n in self.userDict :    # 判断卡号是否存在
               print("卡号正确")
        else:
            print("您输入的卡号有误")
            return
        x2 = self.userDict[n].card                   #  得到卡2的对象
        money = input("当前余额:%.2f, 请输入要转出的钱:" % x1[1].money)
        res2 = x1[1].money - float(money)
        if res2 < 0:
            print("操作失败，余额不足！")
            return
        x1[1].money = res2
        x2.money += float(money)
        print("转账成功!目前余额为:%.2f" % (x1[1].money))
        self.__saveAllUser()

# ------------------------ 改密 -------------------------------#
    # 改密
    def modifyPasswd(self):
        x = self.__cardIdError()    # 得到卡的用户对象和卡对象
        if x == None:
            return
        oldPasswd = input("请输入旧密码:")
        newPasswd = input("请输入新密码:")
        if oldPasswd == x[1].passwd :
            print("修改密码成功")
            return
        else:
            print("密码错误，修改密码失败..")
        self.__saveAllUser()

# ------------------------ 锁定 -------------------------------#
    # 锁定
    def lockCard(self):
        cardId = input("请输入要操作的卡号:")
        if not cardId in self.userDict:
            print("卡号输入有误")
            return

        user = self.userDict[cardId]
        card = user.card  # 银行卡对象

        # 先判断该卡是否已锁住
        if card.isLock == True:
            print("卡号已锁")

        res = self.__checkPasswd(card)
        if res == False:  # 输入错误3次，把卡锁住
            print("输入密码错误3次，卡已锁住")
            card.isLock = True
            self.__saveAllUser()  # 重新保存到文件
            return

        passwd = input("锁定请输入密码:")
        if passwd == card.passwd :
            card.isLock = True
            print("卡号已锁")
        self.__saveAllUser()

# ------------------------ 解锁 -------------------------------#
    # 解锁
    def unlockCard(self):
        cardId = input("请输入要操作的卡号:")
        if not cardId in self.userDict:
            print("卡号输入有误")
            return

        user = self.userDict[cardId]
        card = user.card  # 银行卡对象

        # 先判断该卡是否已锁住
        if card.isLock == True:
            print("该卡已锁住，正在解锁")
        else:
            print("该卡未被锁，无需解锁")
            return

        # 输入密码
        res = self.__checkPasswd(card)
        if res == False:  # 输入错误3次，把卡锁住
            print("输入密码错误3次，卡已锁住")
            card.isLock = True
            self.__saveAllUser()  # 重新保存到文件
            return

        passwd = input("解锁请输入密码:")
        if passwd == card.passwd:
            card.isLock = False
            print("卡号解锁成功")
        self.__saveAllUser()

# ------------------------ 补卡 -------------------------------#
    # 补卡 ，只更改卡号，其他不变
    def makeupCard(self):
        Idcard = input("请输入您的身份证:")
        # 遍历得到所有用户对象user，匹配user.idcard,则输出user.card ,更改卡号
        for i in self.userDict :
            if Idcard == self.userDict[i].idcard :
                card =self.userDict[i].card     # 得到卡类对象
                user = self.userDict[i]         # 得到用户对象
                break
        else:
            print("您的输入有误...")
            return
        # 创建新卡号
        newIdcard = self.__createCardId()               #  创建新的卡号
        oldcardId = card.cardId                         #  得到老卡卡号
        card.cardId = newIdcard                         #  用户新卡的卡号
        newpasswd = self.__setPasswd()                  # 设置新密码
        user.passwd = newpasswd                         #  卡的密码修改成新密码
        user.card = card                                # 用户的卡新对象
        self.userDict[newIdcard] = user                 #   添加新卡进字典
        print("补卡成功！您的新卡号为:%s ,原卡已注销"%newIdcard)
        self.userDict.pop(oldcardId)
        print(self.userDict)

        self.__saveAllUser()

# ------------------------ 销户 -------------------------------#
    # 销户
    def delUser(self):
        Idcard = input("请输入您的身份证:")
        # 遍历得到所有用户对象user，匹配user.idcard,则输出user.card ,销户
        for i in self.userDict:
            if Idcard == self.userDict[i].idcard:
                card = self.userDict[i].card  # 得到卡类对象
                break
        else:
            print("您的输入有误...")
            return
        # 创建新卡号
        oldcardId = card.cardId             #  得到老卡卡号
        print("操作成功！ 销户成功" )
        self.userDict.pop(oldcardId)
        print(self.userDict)

        self.__saveAllUser()

