def factorial(n):
    if n == 1:
        return 1
    return n* factorial (n-1)

num = factorial(4)
print(num)


list1 = [1,2,1,1,2,3,4,5]
tuple1 = set(list1)
print(tuple1)
list1 = list(tuple1)
print(type(list1))

str1 = '123456'
str2 = list(str1)
list3 = list(map(lambda x:int(x),str2))
list3.reverse()
print(list3)

# str3 = "".join(str2)
# print(str3)


