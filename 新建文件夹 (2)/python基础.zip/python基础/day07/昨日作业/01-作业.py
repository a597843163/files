


# 1, 声明一个包含5个数的元组，求元组中所有元素的和
t1 = (1,2,3,4,5)
sum = 0
for i in t1:
    sum += i
print(sum)

# 2, 取出元组(3,2,4,5,8,6,3,9)中的(5,8,6).
t1 = (3,2,4,5,8,6,3,9)
print(t1[3:6])

# 3, 在列表[1,2,3,4,6,7,8]中对应的位置插入5, 变成[1,2,3,4,5,6,7,8]
list1 = [1,2,3,4,6,7,8]
n = 5
list1.insert(4, n)
print(list1)


# 4, 将列表[1, 5, 6, 3, 2, 8, 9, 4] 降序排序
list1 = [1, 5, 6, 3, 2, 8, 9, 4]
list1.sort(reverse=True)
print(list1)

# 5, 将列表[1,46,74,3,5,6]中的元素右移1位, 变成[6,1,46,74,3,5]
list1 = [1,46,74,3,5,6]
res = list1.pop()
list1.insert(0, res)
print(list1)

# 6, 对称列表. 给定一个列表，元素类型与个数皆未知，返回新列表，由原列表的元素正序反序拼接而成;
#  如传入[“One”, “Two”,”Three”] 返回[“One”, “Two”, “Three”,”Three”,”Two”, “One”]
list1 = ["one", "two", "three"]
list2 = list1*1
list2.reverse()
list3 = list1 + list2
print(list3)


# 7,  给定一个不存在重复元素的整数列表，例如[6,4,7,2,5,8]和一个数字，例如10，
#  找出两个元素(或同一个元素加自身)，并且使这两个数的和为给定数字，并打印出来
# 例如[6,4,7,2,5,8]和数字10. 打印结果为: 6,4  2,8  5,5
list1 = [6,4,7,2,5,8]
n = 10

for i in range(len(list1)):
    for j in range(i, len(list1)):
        if list1[i] + list1[j] == n:
            print(list1[i], list1[j])



# 8,  有一个从小到大排好序的列表。现输入一个数，要求按原来的规律将它插入列表中,
#      如: [2,3,4,56,67,98]    //如插入63, 100
list1 = [2,3,4,56,67,98]
n = 100

for i in range(len(list1)):
    if n < list1[i]:
        list1.insert(i, n)
        break
else:
    list1.append(n)

print(list1)  # [2, 3, 4, 56, 67, 98, 100]


# 9, 列表去重, 将下面的列表中重复的元素去除
list1 = [1,2,3,5,4,4,4,5,5,3,2,1]
print(list(set(list1)))

