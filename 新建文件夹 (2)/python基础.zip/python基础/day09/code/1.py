import json

# dic={}
# dic['{'] = 1
# print(dic)

with open(r'F:\pythonStudy\reptile\zhongheng\zhongheng.json','r',encoding='utf-8') as fp:
    ress = fp.readlines()
    dic = {}
    for res in ress:
        for Str in res:
            if not dic.get(Str):
                dic[Str] = 1
            else:
                dic[Str] += 1
    list1 = []
    list2 = []
    for key,value in dic.items():
        list1.append(key)
        list2.append(str(value))
    print(list1)
    print(list2)