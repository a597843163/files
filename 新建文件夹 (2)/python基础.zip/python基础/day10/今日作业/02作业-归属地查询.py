''''''
fp= open("guishudi.txt","r",encoding="utf-8")
str1 = fp.read()
#
# 题目：创建函数， 从文件guishudi.txt中获取数据，输入完整手机号11位，匹配前7位，输出对应的地址和卡类型
#
# 60268|1340475|0431|吉林省长春市|吉林移动大众卡
#   手机号前7位 ：1340475
#
def fn(a):
        b  = (str(a))[0:7]
        dict1 = {}
        list1 = str1.splitlines()
        for i in list1:
            list2 = i.split("|")       #  按“|”拆分，得到列表2
            str2 = list2[-2]+"|"+list2[-1]
            dict1[list2[1]]=str2      #  key 对应地址和卡类型，存入字典
        return dict1[b]
print(fn(15536250359))
fp.close()


