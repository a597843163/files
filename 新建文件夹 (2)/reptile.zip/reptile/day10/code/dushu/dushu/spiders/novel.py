# -*- coding: utf-8 -*-
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from ..items import NovelItem

class NovelSpider(CrawlSpider):
    name = 'novel'
    allowed_domains = ['www.dushu.com']
    start_urls = ['https://www.dushu.com/book/1078.html']

    rules = (
        Rule(LinkExtractor(allow=r'/book/1078(_\d+)?\.html'), callback='parse_item', follow=False),
    )

    def parse_item(self, response):
        li_list = response.xpath('//div[@class="bookslist"]/ul/li')
        for li in li_list:
            item = NovelItem()
            name = li.xpath('.//h3/a/text()').extract_first()
            author = li.xpath('.//p[1]/a/text()').extract_first(default="暂缺作者")
            brief = li.xpath('.//p[last()-1]/text()').extract_first()
            item['name'] = name
            item['author'] = author
            item['brief'] = brief
            yield item
