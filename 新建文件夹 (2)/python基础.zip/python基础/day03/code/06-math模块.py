
# 导入数学math模块
import math

# 开平方
n = math.sqrt(25)
print(n) # 5.0

# 向上取整 ： 大于等于4.3的最小整数
n = math.ceil(4.3)
print(n)  # 5

# 向下取整: 小于等于4.8的最大整数
n = math.floor(4.8)
print(n)  # 4








