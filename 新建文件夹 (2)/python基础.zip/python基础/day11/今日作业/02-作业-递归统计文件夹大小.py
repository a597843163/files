''''''

#
# 统计文件夹大小 (os.path.getSize()：获取文件大小)
#

import os
sum = 0
def filesize(sourcePath):
       if not os.path.exists(sourcePath):
              return "目录不存在"
       fileNameList = os.listdir(sourcePath)
       if len(fileNameList) == 0:
              return
       for fileName in fileNameList:
              absPath = os.path.join(sourcePath,fileName)
              if os.path.isfile(absPath):
                     size = os.path.getsize(absPath)
                     global sum
                     sum  += size
              elif os.path.isdir(absPath):
                     filesize(absPath)
       return sum
if __name__ == "__main__":
       path = r"F:\python千峰课件\day10副本"
       print(filesize(path))


