


# 分别爬取下面url的亚马逊图片，保存到本地images文件夹中

# url = "https://www.amazon.cn/s/ref=lp_2152154051_pg_2?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=2&ie=UTF8&qid=1516169582"
# url = "https://www.amazon.cn/s/ref=sr_pg_3?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=3&ie=UTF8&qid=1516169970"
# url = "https://www.amazon.cn/s/ref=sr_pg_4?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=4&ie=UTF8&qid=1516171321"
#

from urllib import request
import re
import os

def getData(url):

    userAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"
    myRequest = request.Request(url)
    myRequest.add_header("User-Agent", userAgent)
    response = request.urlopen(myRequest)
    htmlStr = response.read().decode("utf-8")

    imgReg1 = '<img alt=".*" src="(.*?)" class="s-access-image cfMarker" height="260" width="200">'
    imgReg2 = 'data-a-image-source="(.*?)"></div></a></div>'
    imgCom1 = re.compile(imgReg1)
    imgCom2 = re.compile(imgReg2)

    imgList1 = imgCom1.findall(htmlStr)
    imgList2 = imgCom2.findall(htmlStr)
    print(len(imgList1))
    print(len(imgList2))

    imgList1.extend(imgList2)

    # 遍历imgList1, 将所有的图片存储到本地
    for imgSrc in imgList1:
        # https://images-cn.ssl-images-amazon.com/images/I/31Fssmq2F4L._SL260_SX200_CR0,0,200,260_.jpg
        path = r"C:\wamp\www\day18\昨日作业\images"
        index = imgSrc.rfind("/")
        fileName = imgSrc[index + 1:]
        absPath = os.path.join(path, fileName)
        print(imgSrc)
        request.urlretrieve(imgSrc, absPath)


if __name__ == "__main__":
    url = "https://www.amazon.cn/s/ref=lp_2152154051_pg_2?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=2&ie=UTF8&qid=1516169582"
    # url = "https://www.amazon.cn/s/ref=sr_pg_3?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=3&ie=UTF8&qid=1516169970"
    # url = "https://www.amazon.cn/s/ref=sr_pg_4?rh=n%3A2016156051%2Cn%3A%212016157051%2Cn%3A2152154051&page=4&ie=UTF8&qid=1516171321"

    getData(url)





