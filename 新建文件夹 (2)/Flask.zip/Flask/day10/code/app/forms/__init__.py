from .user import Register,Login,ChangePassword,Changeemail,UploadForm
from .posts import PostsForm

