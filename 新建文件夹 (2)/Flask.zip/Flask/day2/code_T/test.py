myList = [('a','a'),('b','b')]
# print(dict(myList))
myDict = dict(myList)
# print(myDict.items())
for k,v in myDict.items():
    print(k,'=>',v)