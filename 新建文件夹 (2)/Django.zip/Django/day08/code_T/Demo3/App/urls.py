from django.conf.urls import url

from App.views import *

urlpatterns = [
    url(r'^index/$', index, name='index'),
    url(r'^getuserlist/$', get_user_list, name='get_user_list'),
    
]
