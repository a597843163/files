



# 广度遍历
# 深度遍历


# 广度遍历

import os
import collections

def getAllDirAndFile(sourcePath):

    # 先判断目录是否存在
    if not os.path.exists(sourcePath):
        return "目录不存在"

    # 创建队列
    queue = collections.deque()
    queue.append(sourcePath)  # 从右边加入目录
    # [newdir]
    # 取出newdir, 遍历newdir里面的子目录，并依次加入队列中 [dir1, dir2, dir3]
    # 又取出dir1, 遍历dir1里面的子目录，并依次加入队列中 [dir2,dir3,dir1-1,dir1-2]
    # 又取出dir2, 遍历dir2里面的子目录，并依次加入队列中 [dir3,dir1-1,dir1-2]
    # 又取出dir3, 遍历dir3里面的子目录，并依次加入队列中 [dir1-1,dir1-2,dir3-1]
    # 又取出dir1-1, 遍历dir1-1里面的子目录，并依次加入队列中 [dir1-2,dir3-1]
    # 又取出dir1-2, 遍历dir1-2里面的子目录，并依次加入队列中 [dir3-1]
    # 又取出dir3-1, 遍历dir3-1里面的子目录，并依次加入队列中 []
    # 如果队列中没有目录了，则会退出while循环

    # 遍历队列中的目录
    while True:
        
        # 判断队列中是否还有目录需要遍历
        if len(queue) == 0:
            break

        # 从队列中获取目录: 从左边取出目录
        dirPath = queue.popleft()

        # 获取队列目录中的所有子目录和子文件名称
        fileNameList = os.listdir(dirPath)

        # 遍历
        for fileName in fileNameList:

            absPath = os.path.join(dirPath,fileName)

            if os.path.isfile(absPath):  # 文件
                print("fileName：", fileName)
            elif os.path.isdir(absPath):  # 目录
                print("dirName: ", fileName)

                # 将子目录依次加入到队列中
                queue.append(absPath)

# 队列中的目录： newdir, dir1, dir2, dir3, dir1-1, dir1-2, dir3-1

if __name__ == "__main__":
    path = r"C:\wamp\www\day11\code\newdir"
    getAllDirAndFile(path)









