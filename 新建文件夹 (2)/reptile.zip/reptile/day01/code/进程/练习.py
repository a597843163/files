import os
from multiprocessing import Process,Pool
from time import sleep, time

def write(oldsource,newsource):
    # 打开每一个文件
    fp1 = open(oldsource , "rb")  # 以只读的方式读取二进制
    fp2 = open(newsource , "wb")  # 以只写的方式写入二进制（覆盖）
    # 读取并且写入
    while True:
        # 一次获取1024byte, 1KB
        content = fp1.read(1024)
        if len(content) == 0:  # 写完了
            break
        fp2.write(content)  # 写入


# 单进程拷贝
def copy_file(oldpath,newpath):
    print('开始拷贝')
    start = time()
    file_list = os.listdir(oldpath)  # 得到目录下面的文件名
    for file in file_list:
        if os.path.isfile(oldpath+'\\'+file):
            # 旧文件和新绝对路径:
            oldsource = os.path.join(oldpath,file)
            newsource = os.path.join(newpath,file)
            write(oldsource,newsource)
    end = time()
    print('拷贝完毕,拷贝时间为{}'.format(end-start))

# 单进程拷贝
def more_copy_file(oldpath,newpath):
    print('开始拷贝')
    start = time()
    file_list = os.listdir(oldpath)  # 得到目录下面的文件名
    pp = Pool(4)
    for file in file_list:
        if os.path.isfile(oldpath+'\\'+file):
            # 旧文件和新绝对路径:
            oldsource = os.path.join(oldpath,file)
            newsource = os.path.join(newpath,file)
            pp.apply_async(write(oldsource,newsource))
    end = time()
    print('拷贝完毕,拷贝时间为{}'.format(end-start))



#     newpath = r'F:\pythonStudy\pachong\day01\code\today01'
#     newpath = r'F:\pythonStudy\pachong\day01\code\today02'
if __name__ == '__main__':
    print('主程序执行开始')
    # 单线程,直接调用
    copy_file(
        r'F:\pythonStudy\reptile\day01\code\进程\day01',
        r'F:\pythonStudy\reptile\day01\code\进程\today01'
    )
    # 创建进程调用
    '''
    p = Process(target=copy_file,kwargs={
        'oldpath':r'F:\pythonStudy\reptile\day01\code\进程\day01',
        'newpath':(r'F:\pythonStudy\reptile\day01\code\进程\today01')
    })
    p.start()
    p.join()
    print('主进程结束执行')
    '''


    # 多线程
    # more_copy_file(
    #     r'F:\pythonStudy\reptile\day01\code\进程\day01',
    #     r'F:\pythonStudy\reptile\day01\code\进程\today02'
    # )

    # # 创建进程池
    # pp = Pool(4)
    # # 得到文件名字
    # file_list = os.listdir(oldpath)  # 得到目录下面的文件名
    # # 往进程池添加进程
    # for file in file_list:
    #     if os.path.isfile(oldpath + '\\' + file):
    #         pp.apply_async(copy, args=(file,))
    # # 关闭进程池
    # pp.close()
    # # 等待进程池中的进程结束
    # pp.join()
    # p.join()
    # print('主进程结束执行,程序执行时间{}'.format(end-now))
    print('主进程结束执行')
# 主程序执行开始
# 主进程结束执行,程序执行时间641.4900619983673


'''
num = 100

def run1():
    print('子程序1开始执行')
    global num
    num += 1
    print(num)
    print('子程序1结束执行')

def run2():
    print('子程序2开始执行')
    global num
    num += 100
    print(num)
    print('子程序2结束执行')

if __name__ == '__main__':
    print('主程序开始执行')
    p1 = Process(target=run1)
    p2 = Process(target=run2)
    print(p1.exitcode)
    p1.start()
    p2.start()
    print(p1.exitcode)


    sleep(10)
    print(num)
    print('主程序结束执行')
'''




