import urllib.request
import urllib.parse

# 百度手机翻译
url = 'http://fanyi.baidu.com/basetrans'

# word = input('请输入您要查找的英文单词：')
# 构造post请求的data。
# data = {
#     'from': 'en',
#     'to': 'zh',
#     'query': 'love',
#     'transtype':'realtime',
#     'simple_means_flag':'3',
#     'sign':'954346.683227',
#     'token':'dcc146aee5efd9f2d03d4b4dd06a2ec5'
# }
"""
sign:284353.46576
token:dcc146aee5efd9f2d03d4b4dd06a2ec5
"""
data = {
    'from': 'en',
    'to': 'zh',
    'query': 'love',
}

headers = {
# 手机浏览器的UA
    "User-Agent":"Mozilla/5.0 (Linux; Android 5.1.1; Nexus 6 Build/LYZ28E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Mobile Safari/537.36"
}

data = urllib.parse.urlencode(data).encode('utf-8')

req = urllib.request.Request(url=url, data=data, headers=headers)
response = urllib.request.urlopen(req)

print(response.read().decode('utf-8'))

