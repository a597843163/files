$(function () {

    flag1 = false; //   用户名是否输入合法，默认不合法
    flag2 = false; //   密码是否输入合法，默认不合法
    flag3 = false; //   确认密码是否输入合法，默认不合法
    flag4 = false; //   邮箱是否输入合法，默认不合法

    //keyup()  每一次改变触发
    //change()  离开以后才触发
    //blur()
   $('#username').change(function () {
        // uname = this.value
        var uname = $(this).val();
        // 检测用户名6-18位的数字字母下划线,不能以数字开头
        if (/^[a-zA-Z_]\w{5,17}$/.test(uname)){
            flag1 = true
        }
        else {
            flag1 = false;
            alert('用户名输入不合法')
        }
   });

   // 密码
   $('#password').change(function () {
        // uname = this.value
         var passwd = $(this).val();
        // 检测:8位以上的字符
        if (/^\w{8,}$/.test(passwd)){
            flag2 = true
        }
        else {
            flag2 = false;
            alert('密码输入不合法,请重新输入')
        }
   });

   // 确认密码
   $('#repassword').change(function () {
        // uname = this.value
        var repasswd = $(this).val();
        var passwd = $('#password').val();
        // 检测:8位以上的字符
        if (passwd == repasswd){
            flag3 = true
        }
        else {
            flag3 = false;
            alert('确认密码输入不合法,请重新输入')
        }
   });

   // 邮箱
   $('#email').change(function () {
        // uname = this.value
         var email = $(this).val();
        // 检测:合法的邮箱
        if (/^\w+@\w+\.\w+$/.test(email)){
            flag4 = true
        }
        else {
            flag4 = false;
            alert('邮箱输入不合法,请重新输入')
        }
   });
   // 判断4个是否符合,不符合不让点注册
    $('button').click(function () {
        if (flag1 != true || flag2 != true || flag3 != true || flag4 != true){
            alert("您的输入有误，请重新输入...");
            return false;
        }
    });


});