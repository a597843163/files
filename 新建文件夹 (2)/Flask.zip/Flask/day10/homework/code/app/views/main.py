from flask import Blueprint, render_template, request, redirect, url_for, current_app

# from app.extensions import cache
main = Blueprint('main',__name__)
#定制首页