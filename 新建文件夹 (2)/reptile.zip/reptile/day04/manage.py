import urllib.request
import re

def handle_url(page=1):
    url = 'https://www.kuaidaili.com/free/intr/'+str(page)+'/'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
    }

    req = urllib.request.Request(url=url,headers=headers)
    response = urllib.request.urlopen(req)
    html_str = response.read().decode('utf-8')

    # ip+port+location
    reg = '<td data-title="IP">(.*?)</td>.*?data-title="PORT">(.*?)</td>.*?title="位置">(.*?)</td>'
    com = re.compile(reg,re.S)
    info_list = com.findall(html_str)
    return info_list

from flask import Flask, render_template
from flask_script import Manager

app = Flask(__name__)
manager = Manager(app)

@app.route('/')
def index():
    info_list = handle_url()
    return render_template('index.html',info_list=info_list)

@app.route('/index/<int:page>')
def pn(page):
    info_list = handle_url(page)
    return render_template('index.html',info_list=info_list)

if __name__ == '__main__':
    manager.run()


