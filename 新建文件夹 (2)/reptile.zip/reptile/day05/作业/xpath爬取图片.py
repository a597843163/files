from lxml import etree
from urllib import request

# 处理url的函数
def handle_url(base_url,page):
    if page == 1:
        url = base_url
    else:
        url_list = base_url.split('.html')
        url = url_list[0] + '_'+str(page)+'.html'
    headers= {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
    }

    req = request.Request(url=url,headers=headers)
    response = request.urlopen(req)
    return response.read().decode('utf-8')

# 下载图片
def url_retrieve(html):
    # 对html实例化
    html_url = etree.HTML(html)
    img_url_list = html_url.xpath('//div[@id="container"]/div/div/a/img/@src2')
    # print(len(img_url_list))  40
    # http://pic2.sc.chinaz.com/Files/pic/pic9/201805/wpic997_s.jpg
    # 遍历img_url_list
    for img_url in img_url_list:
        filename = img_url.split('/')
        filename_path = './img/'+filename[-1]
        request.urlretrieve(img_url,filename=filename_path)

def main():
    start_page = int(input('请输入从第几页开始读取:'))
    end_page = int(input('请输入从第几页结束读取:'))
    base_url = 'http://sc.chinaz.com/tupian/rentiyishu.html'

    for page in range(start_page,end_page+1):
        # 得到每一页的字符串
        html = handle_url(base_url,page)
        # 处理字符串,得到每一页所有img的url，并且下载
        print('开始下载')
        url_retrieve(html)
        print('结束下载')

if __name__ == '__main__':
    main()

