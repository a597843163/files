

#
# 人开枪发射子弹
#
#  对象：人，枪，弹夹
#
#   人：
#       属性：有枪
#       方法：开枪（让枪发射子弹），换弹夹（给枪换弹夹）
#
#   枪：
#       属性：弹夹
#       方法：发射子弹，换弹夹
#
#   弹夹：
#       属性：子弹数量
#       方法：获取子弹数量， 设置子弹数量
#


from person import Person
from gun import Gun
from clip import Clip


# 创建弹夹对象, 并设置30发子弹
clip1 = Clip()
clip1.setNumber(30)

# 创建枪对象
gun1 = Gun(clip1)

# 创建人的对象
person1 = Person(gun1)


# 发射子弹
# person1.shoot()
# person1.shoot()

for i in range(100):
    person1.shoot()

# person1.shoot()












