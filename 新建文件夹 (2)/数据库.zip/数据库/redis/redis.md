# Redis数据库

redis： 半持久化，存储于内存和硬盘

## 一 前期准备

#### 下载地址:

https://github.com/ServiceStack/redis-windows

https://github.com/MSOpenTech/redis/releases

#### 设置  redis.windows.conf

455行 maxheap 1024000000   设置最大的数据堆的大小

387行 requirepass 123456		设置数据库的密码

#### port 端口号为

6379

## 二 启动服务

cd C:\redis64-2.8.2101

C:\redis64-2.8.2101>**redis-server.exe redis.windows.conf**  #执行 redis-server.exe 并加载Windows的配置文件

C:\redis64-2.8.2101—>dump.rdb  为数据文件

##### mac 下安装也可以使用 homebrew，homebrew 是 mac 的包管理器。

ce1、执行 brew install redis

2、启动 redis，可以使用后台服务启动 brew services start redis。或者直接启动：redis-server /usr/local/etc/redis.conf

## 三 测试是否连接成功

##### 再打开一个新的终端

##### 输入密码 (这个密码就是在redis.windows.conf里面设置的密码)

C:\redis64-2.8.2101>Redis-cli.exe

127.0.0.1:6379>auth '123456'    

#### 注意:

密码 为 字符串类型

## 四 Redis值的类型

1. ##### 字符串 String

2. ##### 哈希 hash

3. ##### 列表 list

4. ##### 集合 set

5. ##### 有序集合 zset

##### 数据操作的全部命令：

http://redis.cn/commands.html

config get databases 查看所有的数据库 数据库以0开始 一共16个

### (1) String

Ss概述：String是redis最基本的类型，最大能存储512MB的数据，String类型是二进制安全的，即可以存储任何数据、比如数字、图片、序列化对象等

一个key对应一个value

string类型是Redis最基本的数据类型，一个键最大能存储512MB。

#### 1、设置键值

##### A、设置键值

> set key value 

```python
set name "zhangsan"
```

##### B、设置键值及过期时间，以秒为单位

> setex key seconds value

 ```python
setex name 10 'zhangsan'
 ```

##### C、查看有效时间，以秒为单位

> ttl key

```python
ttl name
```

##### D、只有在 key 不存在时设置 key 的值

> setnx key value

```
 setnx name 'a'
```



##### E、设置多个键值

> mset key value [key value ……]

```python
mset name 'zs' age 18 	
```

##### F、覆盖key对应的string的一部分，从指定的offset处开始，覆盖value的长度

> setrange key offset value

```python
redis> SET key1 "Hello World"
OK
redis> SETRANGE key1 6 "Redis"
(integer) 11
redis> GET key1
"Hello Redis"
redis> 
```



#### 2、key的操作

##### A.根据键获取值，如果键不存在则返回None(null 0 nil)

> get key

 `get name`

#####  B、根据多个键获取多个值

> mget key [key ……]

  `mget name age`

##### C、返回 key 中字符串值的子字符

> getrange key start end

```python
getrange name 0 4
```

##### D、将给定 key 的值设为 value ，并返回 key 的旧值(old value)

> getset key value

```python
getset name 'x'
```



#### 3、运算

##### 要求：值是字符串类型的数字

##### A、将key对应的值加1

> incr key   

 `incr age`

##### B、将key对应的值减1

> decr key

`decr age`

#####  C、将key对应的值加整数

> incrby key intnum

` incrby age 10	`	

#####  D、将key对应的值减整数

> decrby key intnum

`incrby age 10`



#### 4、其它

#####  A、追加值

> append key value

`append age 20`

##### B、获取值长度

> strlen key

  `strlen age`



## key 键的操作

##### A、查找所有符合给定模式pattern（正则表达式）的 key 

> keys *

> KEYS \*o\*

> KEYS t??

##### 支持的正则表达模式：

- `h?llo` 匹配 `hello`, `hallo` 和 `hxllo`
- `h*llo` 匹配 `hllo` 和 `heeeello`
- `h[ae]llo` 匹配 `hello` 和 `hallo,` 但是不匹配 `hillo`
- `h[^e]llo` 匹配 `hallo`, `hbllo`, … 但是不匹配 `hello`
- `h[a-b]llo` 匹配 `hallo` 和 `hbllo`

##### B、判断键是否存在，如果存在返回1，不存在返回0

> exists key

`exists name`

##### C、查看键对应的value类型

> type key

 `type name`

##### D、删除键及对应的值

> del key [key ……]

##### E、设置过期时间，以秒为单位

> expire key seconds

   `expire age 10`

##### F、查看有效时间，以秒为单位

> ttl key

##### H、以毫秒为单位返回 key 的剩余的过期时间

> pttl key 

##### I、移除 key 的过期时间，key 将持久保持

> persist key

##### J、删除所有的key

> flushdb	删除当前数据库中的所有

> flushall		删除所有数据库中的key

##### K、修改 key 的名称(仅当 newkey 不存在时，将 key 改名为 newkey)

> rename key newkey

##### L、将key移动到指定的数据库中

> Move key db

```python
mover name 1	#将name 移动到数据库1
```

##### M、随机返回一个key

> randomkey



### (2) hash

##### 概述：hash用于存储对象

{

​	naem:"tom",
​	age:18

}

Redis hash 是一个键值(key=>value)对集合。

Redis hash是一个string类型的field和value的映射表，hash特别适合用于存储对象。

#### 1、设置

##### a、设置单个值

> hset key field value

```python
redis> e
(integer) 1z
redis> HGET myhash field1
"Hello"
```

##### b、设置多个值

> hmset key field value [field value ……]

```python
hmset a x "o" y "y" z "z"
```
##### C 为哈希表 key 中的指定字段的整数值加上增量 increment 

> hincrby key field incrment

```python
hincrby hh age 10
```

##### E 为哈希表 key 中的指定字段的浮点数值加上增量 increment

> HINCRBYFLOAT key field increment

```
hincrbyfloat hh money 0.1
```

##### F 只有在字段 field 不存在时，设置哈希表字段的值

> hsetnx key field value

```python
 hget hh name
```



#### 2、获取

##### A、获取一个属性的值

> hget key field

`hget name field1`

##### B、获取多个属性的值

> hmget key filed [filed ……]

##### C、获取所有字段和值

> hgetall key

##### D、获取所有字段

> hkeys key

##### E、获取所有值

> hvals key

##### F、返回包含数据的个数

> hlen key



#### 3、其它

##### A、判断属性是否存在，存在返回1，不存在返回0

> hexists key field

`hexists a x`

##### B、删除字段及值	

> hdel key field [field ……]

` hdel a x y z`

##### C、返回值的字符串长度  起始版本 3.2	

> hstrlen key field



### (3) 列表 list

概述：Redis 列表是简单的字符串列表，按照插入顺序排序。你可以添加一个元素到列表的头部（左边）或者尾部（右边）

### 1、设置

##### A、在头部插入

> lpush key value [vlaue ……] 

```python
lpush demo 2 3`
```

##### 将一个值插入到已存在的列表头部，列表不存在时操作无效

> Lpushx  key val

```
lpushx list 'a'
```

##### B、在尾部插入

> rpush key value [vlaue ……]


```python
rpush demo 2 1
```

##### 为已存在的列表添加值

> rpushx  key val

```python
rpushx mm 'a'	
```

##### C、在一个元素的前|后插入新元素

>linsenrt key before|after value value

```python
LINSERT mylist BEFORE "World" "There"
```

##### D、设置指定索引的元素值

> lset key index value

```python
lset demo 0 'x'	#把x的索引值设置为0 并添加
```

注意：index从0开始

注意：索引值可以是负数，表示偏移量是从list的尾部开始，如-1表示最后一个元素

#### 2、获取

##### A、移除并返回key对应的list的第一个元素

>lpop key

```python
lpop demo
```

##### B、移除并返回key对应的list的最后一个元素

>rpop key

```python
rpop demo
```

##### C、Lrem 根据参数 COUNT 的值，移除列表中与参数 VALUE 相等的元素

###### COUNT 的值可以是以下几种：

- count > 0 : 从表头开始向表尾搜索，移除与 VALUE 相等的元素，数量为 COUNT 。
- count < 0 : 从表尾开始向表头搜索，移除与 VALUE 相等的元素，数量为 COUNT 的绝对值。
- count = 0 : 移除表中所有与 VALUE 相等的值

> LREM KEY_NAME COUNT VALUE

```python
lrem mm 3 'b'  #删除mm列表中 3个 元素b 从左往右搜索
```



##### D、返回存储在key的列表中的指定范围的元素

> lrange key  start end

```python
lrange demo 0 -1	#查看列表中的所有元素
```
注意：start end都是从0开始
注意：偏移量可以是负数



#### 3、其它

##### A、裁剪列表，改为原集合的一个子集

> ltrim key start end

```python
ltrim demo 1 -1	#将索引为1 到 -1的元素裁剪出来
```



注意：start end都是从0开始
注意：偏移量可以是负数

##### B、返回存储在key里的list的长度

> llen key

##### C、返回列表中索引对应的值

> lindex key index

```python
LINDEX mylist 0
```



### 四 集合 set

概述：无序集合，元素类型为String类型，元素具有唯一性，不重复

{ 'a','b'}

#### 1、设置

##### A、添加元素

> sadd key member [member ……]

```python
sadd set 'a' 'b' 'c'
```

#### 2、获取

##### A、返回key集合中所有元素

> smembers key

```python
smembers set
```

##### B、返回集合元素个数

> scard key

```python
scard set
```

##### C、移除并返回集合中的一个随机元素

> Spop  key

```
spop set
```

##### D、返回集合中一个或多个随机数

> srandmember  key  count

```python
srandmember set		#返回一个随机元素
srandmember set 2	#返回2个随机元素
```

##### E、移除集合中一个或多个成员

> srem  key   member1 [memkber2]

```python
srem set 'd' 'b'
```





#### 3、集合的其它操作

##### A、求多个集合的交集s

> sinter key [key ……]

```python
 sinter m l	#求集合l和集合m的交集
```

##### B、求多个集合的差集

> sdiff key [key ……]

```python
sdiff m l	#求差集 注意比较顺序
```

##### C、求多个集合的合集

> sunion key [key ……]

```Python
sunion  l m	#将集合l 和集合m的值结合在一起
```

##### D、判断元素是否在集合中，存在返回1，不存在返回0

> sismember key member

```python
smember m 'a'   #集合m中是否存在元素'a'
```



### 五 有序集合 zset

##### 概述：

##### a、有序集合，元素类型为Sting，元素具有唯一性，不能重复

##### b、每个元素都会关联一个double类型的score(表示权重),通过权重的大小排序，元素的score可以相同

#### 1、设置

##### A、添加

> zadd key score member [score member ……]

```python
zadd zset 1 a 5 b 3 c 2 d 4 e
```

##### B、有序集合中对指定成员的分数加上增量 increment

> Zincrby	key increment  mcfaember

```
zincrby zset 10 'a'   #给a的权重上加10
```



#### 2、获取k

##### A、返回指定范围的元素

> zrange key start end

```python
zrange z1 0 -1
```

##### B、返回元素个数

> zcard key

```python
 zcard z1
```

##### C、返回有序集合key中，score在min和max之间的元素的个数

> zcount key min max

##### D、返回有序集合key中，成员member的score值

> zscore key member

```python
zscore l 'c'	#返回c的权重
```

##### E、当前集合所有的值和权重

> ZRANGE key 0 -1 WITHSCORES



#### 数据库:

默认在 数据库 0

select num  进行数据库的切换

select  1  #进入到数据库1



## 六 持久化设置

### RDB和AOF

RDB方式按照一定的时间间隔对数据集创建基于时间点的快照。
AOF方式记录Server收到的写操作到日志文件，在Server重启时通过回放这些写操作来重建数据集。该方式类似于MySQL中基于语句格式的binlog。当日志变大时Redis可在后台重写日志。
若仅期望数据在Server运行期间存在则可禁用两种持久化方案。在同一Redis实例中同时开启AOF和RDB方式的数据持久化方案也是可以的。该情况下Redis重启时AOF文件将用于重建原始数据集，因为叫RDB方式而言，AOF方式能最大限度的保证数据完整性。

#### (1) RDB持久化设置

默认情况下Redis在磁盘上创建二进制格式的命名为dump.rdb的数据快照。可以通过配置文件配置每隔N秒且数据集上至少有M个变化时创建快照、是否对数据进行压缩、快照名称、存放快照的工作目录。redis 2.4.10的默认配置如下：

```python
#900秒后且至少1个key发生变化时创建快照  
save 900 1  
#300秒后且至少10个key发生变化时创建快照  
save 300 10  
#60秒后且至少10000个key发生变化时创建快照  
save 60 10000  
#可通过注释所有save开头的行来禁用RDB持久化  
#创建快照时对数据进行压缩  
rdbcompression yes  
#快照名称  
dbfilename dump.rdb  
#存放快照的目录（AOF文件也会被存放在此目录） 
/usr/local/var/db/redis
```

---

#### (2) AOF持久化设置

利用快照的持久化方式不是非常可靠，当运行Redis的计算机停止工作、意外掉电、意外杀掉了Redis进程那么最近写入Redis的数据将会丢。对于某些应用这或许不成问题，但对于持久化要求非常高的应用场景快照方式不是理想的选择。AOF文件是一个替代方案，用以最大限度的持久化数据。同样，可以通过配置文件来开闭AOF：

```python
#关闭AOF  
appendonly no  
#打开AOF  
appendonly yes 
```

当设置appendonly为yes后，每次Redis接收到的改变数据集的命令都会被追加到AOF文件。重启Redis后会重放AOF文件来重建数据。