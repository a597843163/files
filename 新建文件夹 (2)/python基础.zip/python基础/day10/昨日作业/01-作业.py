

# 1,  将下面的字符串str1的敏感字符*用空字符串""替换:
#     然后将str1的空格用空字符串""替换;
#      str1 = "H e  l  ** l    o    Wo r         L d  !"
str1 = "H e  l  ** l    o    Wo r         L d  !"
str1 = str1.replace("*", "")
str1 = str1.replace(" ", "")
print(str1)  # HelloWorLd!


# 2, 去掉字符串123@zh@qq.com中的@;
str2 = "123@zh@qq.com"
str2 = str2.replace("@", "")
print(str2)  # 123zhqq.com


# 3, 任意给定的一串字符，统计字符串里面的大写字母和小写字母的个数
#   如： str1 = "HelloWorLD123"
str1 = "HelloWorLD123"
count1 = 0
count2 = 0
for i in str1:
    if i.isupper():  # 大写
        count1 += 1
    elif i.islower():  # 小写
        count2 += 1

print(count1, count2)  # 4 6


# 4, https://www.baidu.com/s?name=avery&age=20&sex=male
#   封装函数, 传入参数名，获取对应参数的值，
#   如：传入参数"name"返回avery，
#   如：传入参数"age"返回20，
#   如：传入参数"sex"返回male，
def getAttribute(key):
    urlStr = "https://www.baidu.com/s?name=avery&age=20&sex=male"

    # index = urlStr.find("?")
    # str1 = urlStr[index+1:]

    # 按照?拆分
    list1 = urlStr.split("?")
    str1 = list1[1]
    # print(str1)  # "name=avery&age=20&sex=male"

    # 按照&符号拆分
    list2 = str1.split("&")
    # print(list2)  # ['name=avery', 'age=20', 'sex=male']

    # 遍历
    # 方式1：
    # for str2 in list2:
    #     list3 = str2.split("=")
    #     if list3[0] == key:
    #         return list3[1]

    # 方式2：
    # dict1 = {}
    # for str2 in list2:
    #     list3 = str2.split("=")
    #     dict1[list3[0]] = list3[1]
    # # print(dict1)
    # return dict1.get(key)

    # 方式3：
    for str2 in list2:
        index = str2.find("=")
        if str2[:index] == key:
            return str2[index+1:]


print(getAttribute("sex"))



'''
https://www.baidu.com/s?name=avery&age=20&sex=male
http://localhost:80/day09/code/
http://www.12306.cn/mormhweb/
ftp://
svn://
git://
file://
协议： https://
域名：www.baidu.com （IP地址）
端口：80
路径： /day09/code/
? : 分隔 服务器地址 和 参数部分
参数部分: name=avery&age=20&sex=male


'''









# 5,  将字符串按照单词进行逆序，空格作为划分单词的唯一条件
#      如传入:”Welome to Beijing”改为 “Beijing to Welcome”
str1 = "Welome to Beijing"
list1 = str1.split()
list1.reverse()
# print(list1)  # ['Beijing', 'to', 'Welome']
str2 = " ".join(list1)
print(str2)  # "Beijing to Welome"


# 6,  实现函数，查找子串出现的次数，返回字符串str中出现子串的次数
#      如传入:”abcabcabc”, “ab”;  返回:3
#          “dddababacccababa”, “aba”, 返回：4

def fn1(str1, subStr1):
    count = 0
    # 如果能够找到下标，则次数+1，同时将str1截取后面一段
    while str1.find(subStr1) != -1:
        count += 1
        str1 = str1[str1.find(subStr1) + 1:]
    return count
print(fn1("dddababacccababa", "aba"))


# 7, 已知千锋邮箱的用户名只能由数字字母下划线组成，域名为@1000phone.com,
#   写一个函数，判断一个字符串是否是千锋邮箱，是返回True，不是返回False。
#     mail@1000phone.com  是
#     $mail@1000phone.com  不是
#     mail@1000phone.comp  不是
def isLegalEmail(email):
    list1 = email.split("@")
    if len(list1) != 2:
        return False

    if list1[1] != "1000phone.com":
        return False

    str1 = list1[0]
    for ch in str1:
        if not ((ch>='0' and ch<='9') or (ch>='a' and ch<='z') or (ch>='A' and ch<='Z') or ch=="_"):
            return False

    return True

print(isLegalEmail("mail@1000phone.com"))


# 8, 将字符中单词用空格隔开
#       已知传入的字符串中只有字母,每个单词的首字母大写，
#       请将每个单词用空格隔开，只保留第一个单词的首字母大写
#       传入:”HelloMyWorld”
#       返回:”Hello my world”

str1 = "HelloMyWorld"
count = 0
for i in range(1, len(str1)):
    count += 1
    if str1[i].isupper():
        str1 = str1.replace(str1[i], " "+str1[i].lower())

print(str1)  # Hello my world
print(count)





