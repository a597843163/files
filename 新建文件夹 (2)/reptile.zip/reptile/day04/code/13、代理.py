import urllib.request
import ssl
ssl._create_default_https_context = ssl._create_unverified_context



# 创建代理handler
# 此ip为代理的IP地址
handler = urllib.request.ProxyHandler({'http': '27.37.47.166:9797'})

# 创建opener
opener = urllib.request.build_opener(handler)

request = urllib.request.Request(url='http://www.baidu.com/s?wd=ip')

response = opener.open(request)

# print(response.read().decode('utf-8'))
with open('ip.html','w',encoding='utf-8') as fp:
    fp.write(response.read().decode('utf-8'))
