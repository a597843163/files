import smtplib
from  email.mime.text import MIMEText

# 163邮箱
# 账号:niejeff@163.com
#   授权码: 123456abcde

# 发生给谁：597843163@qq.com

# smpt服务器: smtp.163.com
#   端口 : 25

mailSever = "smtp.163.com"
mailPort = 25

mailUsername = "niejeff@163.com"
mailAuthCode = "123456abcde"

toMail = "597843163@qq.com"

# 链接163邮箱服务器,并登录
server = smtplib.SMTP(mailSever, mailPort)
server.login(mailUsername, mailAuthCode)

#  创建邮件
msg = MIMEText("今晚来我家吃鸡")
msg["subject"] = "欢迎光临"
msg["From"]    = mailUsername
msg["To"]      = toMail

# 发送邮件
server.sendmail(mailUsername,toMail,msg.as_string())


# 关闭链接
server.close()


