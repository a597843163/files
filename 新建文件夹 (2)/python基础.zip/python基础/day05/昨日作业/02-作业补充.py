''''''


# 1, 输入赵本山的考试成绩，显示所获奖励
#        成绩==100分，爸爸给他买辆车
#         成绩>=90分，妈妈给他买MP4
#         90分>成绩>=60分，妈妈给他买本参考书
#         成绩<60分，什么都不买
score = int(input("输入赵本山的成绩："))
if score == 100:
    print("爸爸给他买辆车")
elif score >= 90:
    print("妈妈给他买MP4")
elif score >= 60:
    print("妈妈给他买本参考书")
else:
    print("什么都不买,打一顿")


# 2，输入一个字符，判断是否是小写字符。输出Y或N?
# 比如：
# 输入 a 输出为Y
# 输入 D 输出为N
ch = input("请输入一个字符：")
if ch>='a' and ch<='z':
    print("Y")
else:
    print("N")


# 3，输入一个字符，判断是否是大写字符。输出Y或N?
# 比如：
# 输入 a 输出为N
# 输入 D 输出为Y
ch = input("请输入一个字符：")
if ch>='A' and ch<='Z':
    print("Y")
else:
    print("N")



# 4, 输入两个数字，输出这两个数字的大小关系：
# 比如：输入3 5
# 输出3<5
# 输入5 3
# 输出5>3
# 输入5 5
# 输出5==5
a = int(input("请输入第一个数字："))
b = int(input("请输入第二个数字："))
if a < b:
    print(str(a) + "<" + str(b))
elif a > b:
    print(str(a) + ">" + str(b))
else:
    print(str(a) + "==" + str(b))


# 5,定义两个整型变量x,y，从键盘初始化变量值，判断两个变量的大小，将较大的值赋给变量max,将max输出,.?
# 比如：
# 输入 6 4 输出为6
# 输入 2 1 输出为2
# 三目运算符: ?:
a = int(input("请输入第一个数字："))
b = int(input("请输入第二个数字："))
max1 = max(a,b)
print(max1)

# 6,定义三个整型变量x,y,z，从键盘初始化变量值，判断三个变量的大小，将较大的值赋给变量max，将max输出,.?
# 比如：
# 输入 6 3 4 输出为6
# 输入 2 7 1 输出为7
a = int(input("请输入第一个数字："))
b = int(input("请输入第二个数字："))
c = int(input("请输入第三个数字："))
max1 = max(a,b,c)
print(max1)





