

import re


# re.match()
# re.search()
# re.findall()

# 先将正则表达式编译成一个正则对象，然后再使用match,search,findall
reg = "^1[345789]\d{9}$"
com = re.compile(reg)


list1 = com.findall("13838384389")
print(list1)  # ['13838384389']




# 邮政编码(共6位数字, 第一位不能为0)
reg = "^[1-9]\d{5}$"
str1 = "518000"
print(re.search(reg, str1))

# 简单日期格式
# 如："2017-11-11"，"2017-1-1", "2017.1.1", "2017.11.1", "2017/1/1", "2017/1/1"
reg = "^\d{4}[\-\./]\d{1,2}[\-\./]\d{1,2}$"
str2 = "2017/11/11"
print(re.search(reg, str2))


# 图片文件格式 如："aa.jpg", "aa.jpeg","aa.png", "aa.gif"
reg = "^(\w+\.)+(jpg|jpeg|png|gif|bmp)$"
str3 = "dd.dd.aa.jpg"
print(re.search(reg, str3))




# 匹配网址url
# http://www.baidu.com
# https://org.baidu.net
# https://www.sina.com.cn
reg = "https?://(\w+\.)+\w+"
str4 = "https://www.sina.com.cn"
print(re.search(reg, str4))


# 匹配url
# https://www.baidu.com/index.html
# https://www.baidu.com:8080/aaa/bbb/index.asp
reg = "https?://(\w+\.)+\w+(:\d+)?(/\w+)*(/\w+\.\w+)?"
str4 = "https://www.baidu.com:8080/aaa/bbb/index.asp"
print(re.search(reg, str4))


# 匹配带参数的url
# https://www.sina.cn:80/index.html?username=goudan
# https://www.sina.cn:80/index.html?username=goudan&passwd=222
# https://www.sina.cn:8080/aaa/bbb/index.html?username=goudan&passwd=222&passwd=222
reg = "^(https?://(\w+\.)+\w+(:\d+)?(/\w+)*(/\w+\.\w+)?\??(\w+=\w+)?(&\w+=\w+)*)$"
str5 = "https://www.sina.cn:8080/aaa/bbb/index.html?username=goudan&passwd=222&passwd=222"
print(re.findall(reg, str5))
print(len(str5))


