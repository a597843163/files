

name=input("请输入您的姓名：")
age=int(input("请输入您的年龄："))
height=int(input("请输入您的身高:"))
weight=int(input("请输入您的体重："))

print("姓名：%s,年龄：%d,身高:%d,体重:%d"%(name,age,height,weight))
print("姓名:",name,"年龄:",str(age),"身高:",height,"体重:",str(weight))

