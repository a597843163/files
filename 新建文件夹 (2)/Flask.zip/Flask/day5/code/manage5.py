from flask import Flask
from flask_script import Manager
from ext import db
import settings
from app.views import view
from flask_migrate import MigrateCommand,Migrate


app = Flask(__name__)

# 从外部导入配置
app.config.from_object(settings.Config) # 加载配置类
# 配置完成之后，实例化orm模型，把app加载上去
db.init_app(app)  # 加载app  因为在实例化的时候拿不到写在蓝本的上方
app.url_map.converters['regex'] = settings.RegexConverter   #路由正则匹配配置
# 注册蓝本
app.register_blueprint(view)

migrate = Migrate(app,db)   # 实例化迁移对象
manager = Manager(app)
manager.add_command('db',MigrateCommand) # 添加迁移命令
'''
迁移步骤
1.python manage.py db init  创建迁移目录
2.python manage.py db migrate 生成迁移文件
3.python manage.py db upgrade 执行迁移文件(更新数据库)
'''
if __name__ == '__main__':
    manager.run()