import urllib.request



url = 'http://imgsrc.baidu.com/imgad/pic/item/54fbb2fb43166d229f3b7eb04c2309f79052d242.jpg'

response = urllib.request.urlretrieve(url=url, filename=r'C:\Users\sdsd\Desktop\day04\meinv.jpg')

print(response)
