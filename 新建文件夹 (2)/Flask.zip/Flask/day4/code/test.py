# myStr = 'abc'
# print(myStr.trim('a'))

#0123456789  通过函数怎样获取到？
#
# myList = map(str,list(range(10)))
# # myList = ['1','2','3']
# print(''.join(myList))
import string,random
def randomName(shuffix,length=32):
    myStr = string.ascii_letters+'0123456789'
    # print(myStr)
    newName = ''.join(random.choices(myStr,k=length))+shuffix
    return newName
randomName('.jpg')