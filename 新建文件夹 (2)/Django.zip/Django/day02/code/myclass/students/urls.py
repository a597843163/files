from django.conf.urls import url
from .views import student_list, detail, detail2, detail3, index,block


urlpatterns = [
    url(r'^list/$', student_list, name='list'),
    url(r'^detail/$', detail, name='detail'),
    # url(r'^detail2/(\d+)/$', detail2, name='detail2'),
    url(r'^detail2/(?P<id>\d+)/$', detail2, name='detail2'),
    # url(r'^detail3/(\d+)/(\d+)/$', detail3),
    
    url(r'^index/$', index, name='index'),
    url(r'^block/$', block, name='block'),
    


]
