

'''

    面向对象和面向过程：

        面向过程： 注重过程，解决问题的每一个步骤，写函数把功能封装，然后再按顺序依次调用函数
        面向对象： 注重对象，注重问题当中的每个对象，把大的问题中的每个对象使用类来封装，需要找出类中的属性和方法

    类 和 对象：
        类： 抽象，模型
        对象： 使用类来创建对象， 一般我们使用对象

    class Person(object):

        # 构造函数/构造方法：写属性，初始化
        def __init__(self, name, age):
            self.name = name  # 对象属性 / 成员属性 / 成员变量
            self.__age = age  # 私有变量: 只能在类中使用

        # 析构函数：在对象销毁时调用
        def __del__(self):
            print("析构函数")

        # __str__: 设置对象的输出格式
        def __str__(self):
            return self.name + str(self.__age)

        #__repr__:
        def __repr__

'''


class Person(object):

    # 构造函数/构造方法：写属性，初始化
    def __init__(self, name, age):
        self.name = name  # 对象属性 / 成员属性 / 成员变量
        self.__age = age  # 私有变量: 只能在类中使用

    # 析构函数：在对象销毁时调用
    def __del__(self):
        print("析构函数")

    # __str__: 设置对象的输出格式
    def __str__(self):
        return self.name + str(self.__age)

    # __repr__:
    def __repr__(self):
        return self.name + str(self.__age) + "repr"


    # 私有方法： 在类内部提供给其他方法使用
    def __getMoney(self):
        return 10000
    #
    def getSalary(self):
        return self.__getMoney()

    # self: 指向当前类的对象
    #       哪个对象调用了方法，则该方法中的self就是这个对象
    #

# 创建对象
person = Person("霍金", 76)
print(person)
print(repr(person))
# print(person.getMoney())  # 报错， 不能调用私有方法
# print(person.__getMoney())  # 报错
print(person.getSalary())   # 10000





