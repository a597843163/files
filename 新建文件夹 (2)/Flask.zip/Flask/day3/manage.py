from flask import Flask,render_template,abort,g,url_for,request
from flask_script import Manager
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm #导入需要自定义表单类的基类
#导入表单字段
from wtforms import StringField,PasswordField,SubmitField,ValidationError,HiddenField,TextAreaField,DateField,DateTimeField,IntegerField,FloatField,BooleanField,RadioField,SelectField,FileField
#导入验证器
from wtforms.validators import DataRequired,Length,NumberRange,Email,URL,IPAddress,EqualTo,Regexp

app = Flask(__name__)
manager = Manager(app)
# 设置bootstrap为本地的文件，不再访问cdn的bootstrap
app.config['BOOTSTRAP_SERVE_LOCAL'] = True
bootstrap = Bootstrap(app)
app.config['SECRET_KEY'] = 'abcdedf' #secret key用来给session和csrf进行加密
class MyForm(FlaskForm):# 先继承基类！！！！
    #用户名为 label内的内容作为显示 username为当前input 的name名称 validators为存放验证器的关键字
    # username = StringField('用户名',validators=[DataRequired(message='此字段为必填字段')],render_kw={'placeholder':'请输入用户名...'})

    # userpass = PasswordField('密码',validators=[DataRequired(message='必填字段'),Length(min=6,max=12,message='输入内容的长度为6~12位'),EqualTo('confirm',message='密码和确认密码不一致')])

    # confirm = PasswordField('请输入确认密码')
    # userpass = PasswordField('密码',validators=[DataRequired(message='必填字段')])
    # hidde = HiddenField('隐藏域',default='123')
    # info = TextAreaField('个人信息',validators=[Length(min=10,max=40,message='个人信息介绍内容为10-40个字')])
    # birth = DateField('出生年月')
    # myTime = DateTimeField('当前时间为')
    # age = IntegerField('请输入你的年龄',validators=[NumberRange(min=1,max=99,message='请输入正确年龄的区间范围 1~99')])
    # money = FloatField('请输入你的存款')

    # checked = BooleanField('请认真阅读以下条款')
    # sex = RadioField('性别',choices=[('m','男'),('w','女')])

    # address = SelectField('请选择你的地址',choices=[('1234','北京'),('2345','黑龙江')])

    # file = FileField('请选择你的头像',validators=[DataRequired()])

    # email = StringField('请输入邮箱地址',validators=[Email(message='请输入正确的邮箱地址'),DataRequired(message='邮箱不能为空')])

    # url = StringField('请输入url地址',validators=[URL(message='请输入正确的url地址'),DataRequired(message='邮箱不能为空')])

    # ip = StringField('请输入ipv4地址',validators=[IPAddress(message='请输入正确的ipv4地址'),DataRequired(message='ipv4不能为空')])

    # phone = IntegerField("请输入手机号码",validators=[Regexp('^1\d{3,9}\d{9}$',flags=re.I|re.S|re.M)])
    # phone = StringField("请输入手机号码",validators=[Regexp('^1[3-9]\d{9}$',message='请输入正确的手机号码')])
    phone = StringField("请输入手机号码",validators=[DataRequired(message='必填字段')])

    #正则匹配的内容 必须为字符串
    submit = SubmitField('登录')

    #自定义验证器，会自动调用，通过指定函数名validate_namefield即可,如(validate_userpass)
    def validate_userpass(self,field):
        length = len(field.data)
        if length<6 or length>12:
            raise ValidationError('密码的内容在6-12位之间！！！')

    def validate_phone(self,field):
        lenth = len(field.data)
        if lenth <6 or lenth>12:
            raise ValidationError('手机号在6-12位之间！！！')

@app.route('/login/',methods=['GET','POST'])
def login():
    form = MyForm() #实例化自定义表单类
    # form.sex.data = 'w'
    # form.address.data = '2345'
    if form.validate_on_submit(): #进行表单的校验  表单正确结果为真 否则为假
        # print(request.form.get('username'))
        # print(request.form.get('userpass'))
        # print(form.username.data) #通过表单对象取值
        # print(form.userpass.data)
        pass
    # return render_template('login.html',form=form)
    # return render_template('bootstrapLogin.html',form=form)
    return render_template('allField.html', form=form)




@app.route('/')
def index():
    # abort(404)
    # print(url_for('index')) #只构造路由
    # print(url_for('index',_external=True)) #构造完整的url链接地址
    return render_template('index.html')

@app.errorhandler(404)
def getFourError(e):
    return render_template('error.html', errorCode=404, errorInfo=e)

@app.errorhandler(500)
def getFiveError(e):
    return render_template('error.html', errorCode=500, errorInfo=e)

@app.route('/test/')
def test():
    # g.name = '张三'
    # g.age = 18
    # return render_template('test.html')
    name = 'zhangsan'
    age = 18
    print(locals())
    return render_template('test.html', **locals())

#跳转到表单
"""
@app.route('/login/')
def login():
    return render_template('pform.html')

#验证表单
@app.route('/check_form/',methods=['GET','POST'])
def checkForm():
    print(request.form.get('username'))
    print(request.form.get('userpass'))
    return '提交表单的地址'



#将表单的俩个路由合并为一个路由
@app.route('/login/', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('pform.html')

    return 'name 为{} age为{}'.format(request.form.get('username'),request.form.get('userpass'))
"""

if __name__ == '__main__':
    # app.run()
    manager.run()




