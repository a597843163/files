

# 1、自己实现splitext()
def mySplitext(path):
    index = path.rfind(".")
    return path[:index], path[index:]

print(mySplitext(r"day08\情书.txt"))


# 2、自己实现 os.path.join()
def myPathJoin(path, file):
    return path + "\\" + file

print(myPathJoin(r"C:\wamp\www\day08\code", "01-回顾.py"))


# 3、写一个拷贝函数，传入文件名称，拷贝一个文件，考虑大文件的拷贝
def myCopy(fileName):
    index = fileName.rfind(".")
    newFileName = fileName[:index] + "-副本1" + fileName[index:]

    fp1 = open(fileName, "rb")
    fp2 = open(newFileName, "ab")

    # content = fp1.read()
    # fp2.write(content)

    while True:
        content = fp1.read(1024)

        if len(content) == 0:
            break

        fp2.write(content)

    fp1.close()
    fp2.close()

myCopy("情书.txt")



# 4、复制day08\code目录下的所有文件到day08\code2中（只考虑一层）
import os

#   1, 先获取 C:\wamp\www\day08\code
#            C:\wamp\www\day08\code2
#   2，创建目录： C:\wamp\www\day08\code2
#   3，获取 C:\wamp\www\day08\code 下所有的文件和目录
#   4，遍历code下所有的文件名或目录名
#           如果是文件，那么就拷贝
#           如果是目录，那么创建目录

codePath1 = r"C:\wamp\www\day08\code"
codePath2 = r"C:\wamp\www\day08\code2"

# 当codePath2目录不存在时，则创建该目录
if not os.path.exists(codePath2):
    os.mkdir(codePath2)

# 获取code下所有的文件名和目录名
fileNameList = os.listdir(codePath1)
# print(fileNameList)

for fileName in fileNameList:
    filePath1 = os.path.join(codePath1, fileName)
    filePath2 = os.path.join(codePath2, fileName)
    # print(filePath2)

    # 如果是目录，则在code2下创建一个相同名称的目录
    if os.path.isdir(filePath1):
        os.mkdir(filePath2)

    # 如果是文件， 则拷贝
    elif os.path.isfile(filePath1):
        fp1 = open(filePath1, "rb")
        fp2 = open(filePath2, "ab")

        content = fp1.read()
        fp2.write(content)

        fp1.close()
        fp2.close()


