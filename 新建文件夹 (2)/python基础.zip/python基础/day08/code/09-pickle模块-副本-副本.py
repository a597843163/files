
import pickle

# pickle模块
#   序列化 : 把python中的对列表，元组等存储到文件中
#   反序列化： 把文件中数据转换成Python象,的对象，列表，元组

# 序列化
list1 = ("韩信", "赵云", "李白", "杜甫", "妲己")
fp = open("data.txt", "wb")

# 将list1 的数据 存入data.txt文件中
pickle.dump(list1, fp)

fp.close()



# 反序列化
fp = open("data.txt", "rb")

# 将文件data.txt中的数据 取出，并转成成对应的python对象返回
res = pickle.load(fp)

print(res)  # ['韩信', '赵云', '李白', '杜甫', '妲己']
print(type(res))  # <class 'list'>



