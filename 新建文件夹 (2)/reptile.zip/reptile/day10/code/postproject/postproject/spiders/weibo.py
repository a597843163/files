# -*- coding: utf-8 -*-
import scrapy


class WeiboSpider(scrapy.Spider):
    name = 'weibo'
    allowed_domains = ['weibo.cn']
    start_urls = ['https://weibo.cn/']

    def start_requests(self):
        headers = {
            'Host': 'weibo.cn',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Referer': 'https://weibo.cn/',
            'Accept-Language': 'zh-CN,zh;q=0.8',

        }

        data = {
            'username': '18676689715',
            'password': 'xuke666',
            'savestate': '1',
            'r': 'http://weibo.cn/',
            'ec': '0',
            'pagerefer': '',
            'entry': 'mweibo',
            'wentry': '',
            'loginfrom': '',
            'client_id': '',
            'code': '',
            'qq': '',
            'mainpageflag': '1',
            'hff': '',
            'hfp': ''
        }
        post_url = 'https://passport.weibo.cn/sso/login'

        yield scrapy.FormRequest(url=post_url, headers=headers, formdata=data, callback=self.user_info)

    def user_info(self, response):
        url = 'https://weibo.cn/2952685222/info'

        yield scrapy.Request(url=url, callback=self.save_info)

    def save_info(self, response):
        with open('./weibo.html', 'w', encoding='gbk') as fp:
            fp.write(response.text)


