from django.shortcuts import render,reverse
from django.http import HttpResponse,HttpResponseRedirect
from .models import User
# Create your views here.

# 首页
def index(request):
    return render(request,'LXGlogin/index.html')

# 登陆
def login(request):
    old_username = request.COOKIES.get('username',"")
    return render(request,'LXGlogin/login.html',{'old_name':old_username})

# 登陆操作
def login_handle(request):
    # 登录
    # get请求
    errmsg = ""
    if request.method == 'POST':
        username1 = request.POST.get('username')
        password1 = request.POST.get('password')
        remember = request.POST.get('remember')
        print(remember)

        # 查询数据库库中User表是否有匹配的用户名和密码
        res  = User.objects.filter(username=username1,password=password1)
        if res:
            response = HttpResponseRedirect(reverse('LXGlogin:login'))
            # 如果勾选了'记住用户名'，则添加cookie
            if remember:
                response.set_cookie("username",username1)
            return  response
            # return HttpResponseRedirect(reverse('LXGlogin:index'))  # 登录成功，返回到首页
        else:
            errmsg = "用户名或者密码错误"
            return render(request, 'LXGlogin/login.html',{'errmsg':errmsg})
    return HttpResponse(errmsg)


def logout(request):
    response = HttpResponseRedirect(reverse('LXGlogin:login'))
    response.delete_cookie("username")
    return response

def register(request):
    return render(request,'LXGlogin/register.html')


def register_handle(request):
    errmsg = ''
    if request.method == 'POST':
        # 获取输入框中的户数据
        username2 = request.POST.get('username')
        password2 = request.POST.get('password')
        email2 = request.POST.get('email')
        # print(username2,password2,email2)
        # 判断是否全部输入
        if username2 and password2 and email2:
            response = HttpResponseRedirect(reverse('LXGlogin:login'))
            # 存入数据库中
            User.objects.get_or_create(username=username2,password=password2,email=email2)
            response.set_cookie('username', username2,max_age=None)
            response.set_cookie('password', password2,max_age=None)
            response.set_cookie('email', password2,max_age=None)
            # 重定向到登录页面
            return response
        else:
            errmsg = '请输入用户名和密码'
            return render(request, 'LXGlogin/register.html', {'errmsg': errmsg})
    return HttpResponse(errmsg)



