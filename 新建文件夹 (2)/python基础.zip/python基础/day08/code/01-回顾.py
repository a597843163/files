

'''

    函数：
        函数的定义：
            def 函数名称(形参1, 形参2,...):
                代码块
                return 值
        函数的调用：
            res = 函数名称(实参1, 实参2,...)

        参数传递：
            值类型传递：不关联
            引用类型传递： 关联

        # 普通参数： 使用最多，参数数量要一致，需要按照顺序传参
        # 关键字参数： 可以根据形参名传值，不需要按照顺序传参
        # 默认参数：形参有默认值，可以不对默认参数传值，如果传递了值给默认参数，则会优先使用传递过去的值
        # 可变长参数: *args: 可以接受不定长度的参数序列（元组），一般使用在参数数量不固定的情况下
        #           **kwargs: 可以接受不定长的参数序列（字典），一般使用在参数数量不固定的情况下

        # 匿名函数： 一般使用在把匿名函数当成参数传递
        lambda m,n:m*n => def fn(m, n):
                              return m*n

        # 作用域： 函数可以形参作用域，在函数中定义的变量，在函数外部不可以使用
        #       全局变量， 局部变量, global, nonlocal

        # 异常处理： 捕获异常，为了越过错误，让后面的代码继续执行
        #       try:
        #       except:
        #       finally:

        #
        # copy: 浅复制
        # copy.deepCopy() : 深复制

'''

def fn1(a, b, fn):  # fn = lambda m,n:m*n
    print(a, b)
    return fn(a*a, b*b)  # fn(100, 400)

print( fn1(10, 20, lambda m,n:m*n) )

try:
    # print(5/0)
    print(num)
    # raise TypeError("哈哈， 错了")
# except ZeroDivisionError as e:
except Exception as e:
# except:
    print("出现了异常:", e)

print("end")

# raise TypeError("哈哈， 错了")