



# __name__ : 特殊属性
#            会自动去赋值


if __name__ == "__main__":
    print("当前模块")


import module2



# pip 安装第三方模块
#   命令：
#       pip -V  查看pip的版本
#       pip install numpy  安装模块
#       pip uninstall numpy  卸载模块
#       pip list  显示已经安装的模块
#       pip show numpy  显示模块的信息
#





