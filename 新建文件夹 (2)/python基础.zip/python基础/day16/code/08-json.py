


# json : 是一种数据格式
# xml : 是一种数据格式


# json数据的格式
'''
    一般使用字典或列表包含的数据，如： {}, [], "", True, None
    [
        {
            "name: "宝强",
            "age": 33
        },
        {
            "name: "马蓉",
            "age": 30
        }
    ]
'''

# xml数据的格式 ： 可读性好， 解析麻烦
'''
    <persons>
        <person>
            <name>宝强</name>
            <age>33</age>
        </person>
        <person>
            <name>马蓉</name>
            <age>30</age>
        </person>
    </persons>
'''


# json数据： json字符串， json对象（Python的字典，列表）


import json

# json字符串 json对象之间相互转换

# json字符串 转换成 json对象
# json.loads()  : json解析
str1 = '{"name": "张三", "age": 33}'
dict1 = json.loads(str1)
print(dict1)  # {'name': '张三', 'age': 33}
print(type(dict1))  # <class 'dict'>


# json对象 转换成 json字符串
# json.dumps()  ： json序列化
dict1 = {"name": "张三", "age": 33}
str1 = json.dumps(dict1)
print(str1)  # {"name": "\u5f20\u4e09", "age": 33}
print(type(str1))  # <class 'str'>



# json.load() : 将json文件的数据 转换成 json对象
with open(r"Json/myCity.json", "r", encoding="utf-8") as fp:
    dict1 = json.load(fp)
    print(dict1)
    print(type(dict1))  # <class 'dict'>


# json.dump() : 将 json对象 转换成 json文件保存
dict1 = {"name": "张三", "age": 33}
with open("city.txt", "w", encoding="utf-8") as fp:
    json.dump(dict1, fp)









# 把字符串转换成json格式对象
str = '{"name": "张三", "age": 33}'
res4 = json.loads(str)
print(res4)
print(type(res4))

# 把json格式对象转换成字符串
str2 = json.dumps(res4)
print(str2)
print(type(str2))










