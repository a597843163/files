


# 1，遍历所有子目录和子文件，
# 2， 如果在子目录，则创建相同名称的子目录
#     如果是子文件，则复制一个相同名称的子文件
import os

# 复制目录
def copyDir(sourcePath, targetPath):

    # 如果源文件不存在，则直接返回
    if not os.path.exists(sourcePath):
        return "目录不存在，无法复制"
    # 如果目标目录不存在，则创建目标目录
    if not os.path.exists(targetPath):
        os.mkdir(targetPath)

    print(2)
    # 遍历子文件和子目录
    fileNameList = os.listdir(sourcePath)
    for fileName in fileNameList:
        sourceAbsPath = os.path.join(sourcePath, fileName)  # 源文件的绝对路径
        targetAbsPath = os.path.join(targetPath, fileName)  # 目标文件的绝对路径

        if os.path.isfile(sourceAbsPath):  # 文件
            # 复制sourceAbsPath路径对应的文件 到 targetAbsPath对应的文件中去
            copyFile(sourceAbsPath, targetAbsPath)

        elif os.path.isdir(sourceAbsPath):  # 目录
            # 复制一个目录（创建一个目录）
            os.mkdir(targetAbsPath)

            # 递归, 去复制子目录下的内容
            copyDir(sourceAbsPath, targetAbsPath)

# 复制文件
def copyFile(sourceFilePath, targetFilePath):

    sourceFp = open(sourceFilePath, "rb")
    targetFp = open(targetFilePath, "ab")

    while True:
        content = sourceFp.read(1024)
        if len(content) == 0:
            break
        targetFp.write(content)

    sourceFp.close()
    targetFp.close()




if __name__ == "__main__":
    sPath = r"C:\wamp\www\day10"
    tPath = r"C:\wamp\www\day10副本"
    copyDir(sPath, tPath)
    print(1)















