''''''

import os
# 1、封装函数，传入n，得到前n个斐波那契数列
# 	    1 1 2 3 5 8 13 21    f(n)=f(n-1)+f(n-2)   list1=[],list.append(f(n))  n = 2 = 1   f(n)=1
#                            f(n)=f(n+1)+(n+2)


def fn1(n):
    if n <=2:
        return 1
    return fn1(n-1)+fn1(n-2)
print(fn1(7))
def fn2 (n):
    for i in range(1,n+1):
        print(fn1(i),end=" ")
fn2(6)
print()
# 2、使用函数递归，分别统计文件夹newdir中文件和文件夹的个数
# 统计当前目录下的文件数量和文件夹数量
#   如果碰到文件，则文件数量+1
#   如果碰到文件夹，则文件夹数量+1，递归调用fn()并传入当前子文件夹目录，如“C:\wamp\www\day10\今日作业\newdir\dir1”
n1 = 0
n2 = 0
def fn(dirPath):
    list1 = os.listdir(dirPath)
    for i in list1:
        x = dirPath + "\\" +i  #设置路径
        if os.path.isfile(x):   #  文件+1
             global n1
             n1 += 1
        if os.path.isdir(x):   #  文件夹 +1
             global n2
             n2 += 1
             fn(x)
    return n1,n2
print(fn(r"F:\python千峰课件\day10\code"))

