


# 作业3: 爬取以下页面中的所有QQ号
# http://bbs.tianya.cn/m/post-140-393974-6.shtml

from urllib import request
import re

# 1, 先获取url的数据
url = "http://bbs.tianya.cn/m/post-140-393974-6.shtml"
response = request.urlopen(url)  # 发送请求
lineList = response.readlines()  # 获取每一行数据


# 遍历每一行数据
allQQ = []  # 保存所有qq号码
for line in lineList:
    lineStr = line.decode("utf-8")
    # print(lineStr)

    # 先匹配是否存在q字符
    qqCom = re.compile("q{1,2}", re.I)
    res = qqCom.findall(lineStr)

    # 判断是否存在q字符，如果存在，则再取出这一行的qq号码
    if len(res) > 0:

        # 匹配是否为qq号码
        qqNumberCom = re.compile("[1-9]\d{4,10}")
        qqNumberList = qqNumberCom.findall(lineStr)
        allQQ.extend(qqNumberList)

print(allQQ)











