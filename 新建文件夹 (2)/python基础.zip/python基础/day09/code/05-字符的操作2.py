



# 字符串的查找
# find() : 查找字符串中指定子字符串第一次出现的位置（下标/索引）,如果找不到则返回-1
str1 = "I am a good good good guy"
print(str1.find("good"))  # 7
print(str1.find("hello"))  # -1
print(str1.find("good", 8, 16))

# rfind() : 从右往左查找
print(str1.rfind("good"))  # 17


# index() : 跟find类似，查找子串第一次出现的位置，如果不存在则报错
str1 = "I am a good good good guy"
print(str1.index("good"))  # 7
# print(str1.index("hello"))  # 报错
print(str1.index("good", 8, 16))  # 12

# rindex(): 从右往左查找
print(str1.rindex("good"))  # 17




# split() : 将字符串按照指定的字符串拆分/分割
#  默认按照空格拆分
str1 = "张学友 刘德华 郭富城 黎明"
res = str1.split()
print(res)  # ['张学友', '刘德华', '郭富城', '黎明']

str2 = "I am a nice nice boy"
res = str2.split("boy")
print(res)   # ['I am a nice nice ', '']

str2 = "I am a nice nice boy"
res = str2.split("ic")
print(res)   # ['I am a n', 'e n', 'e boy']

str2 = "hellof"
res = str2.split("boy")
print(res)  # ['hellof']


# splitlines() : 按行拆分
str3 = '''唧唧复唧唧
木兰当户织
不闻机杼声
惟闻女叹息'''

res = str3.splitlines()
print(res)  # ['唧唧复唧唧', '木兰当户织', '不闻机杼声', '惟闻女叹息']

res = str3.splitlines(True)
print(res)  # ['唧唧复唧唧\n', '木兰当户织\n', '不闻机杼声\n', '惟闻女叹息']


# join() : 将序列中的元素以指定的字符拼接成字符串
list1 = ["宝强", "狗蛋", "鸭蛋"]
# res = "".join(list1)  # '宝强狗蛋鸭蛋'
# res = ",".join(list1)  # '宝强,狗蛋,鸭蛋'
res = "        ".join(list1)  # '宝强        狗蛋        鸭蛋'
print(res)
print(type(res))  # <class 'str'>



# replace() : 替换
# 参数1： 旧字符串
# 参数2： 新字符串
# 参数3： 指定替换前面几个，默认是全部替换
str4 = "how are are are you"
# res = str4.replace("are", "old")  # how old old old you
res = str4.replace("are", "old", 2)  # how old old are you
print(res)




