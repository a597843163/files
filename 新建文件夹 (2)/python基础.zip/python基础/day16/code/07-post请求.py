


# post接口：http://mrobot.pcauto.com.cn/v2/cms/channels/1
#     参数：pageNo=1&pageSize=20&serialIds=2143,3404&v=4.0.0

import urllib.request

# url接口(网址)
url = "http://mrobot.pcauto.com.cn/v2/cms/channels/1"

# 参数
paramDict = {
    "pageNo": "1",
    "pageSize": "20",
    "serialIds": "2143,3404",
    "v": "4.0.0"
}

# 将参数字典编码成字符串
paramStr = urllib.parse.urlencode(paramDict)
# print(paramStr)
paramData = paramStr.encode("utf-8") # 转换成二进制

# post的参数要加在请求体中
myRequest = urllib.request.Request(url, paramData)

# 发送请求
response = urllib.request.urlopen(myRequest)
print(response.read().decode("utf-8"))


# http: 请求头，请求体

# post请求的特点：
#     参数是放在请求体中，把参数数据单独封装了
#   优点： 安全，可以携带大数据
#   缺点： 速度相对较慢
#





