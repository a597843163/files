

import time

#
# for i in range(10):
#     print(i)
#
#     # 暂停，睡觉
#     # 让程序暂停1秒，会阻塞程序的运行
#     time.sleep(1)
#
# print("运行完成")



# 检测程序代码执行的时间

startTime = time.time()  # 运行之前的时间

sum = 0
for i in range(10000):
    sum += i
print("sum =", sum)

endTime = time.time()  # 运行之后的时间

# 时间差
intervalTime = endTime - startTime
print("程序运行的时间是:", intervalTime)



# time.clock() ： 计算程序运行的时间
startTime = time.clock()
print(startTime)  # 4e-07  4*10^-7, 0.0000004000, 接近0

time.sleep(2)

endTime = time.clock()
print(endTime)  # 1.9997752  接近2

time.sleep(3)

endTime2 = time.clock()
print(endTime2)  # 4.9997315  接近5


# 科学计数法
n = 3.14e5  # 3.14 * 10^5
print(n)  # 314000.0


