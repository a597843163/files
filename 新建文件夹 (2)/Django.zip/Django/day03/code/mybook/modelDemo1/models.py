from django.db import models

# Create your models here.

class People(models.Model):
    name = models.CharField(max_length=50,unique=True,db_column='姓名')
    USER_TYPE_LIST = (
        (1,'超级用户'),
        (2,'普通用户'),
    )

    age = models.IntegerField(choices=USER_TYPE_LIST,default=1,db_index=True)
    # address = models.TextField()
    # height = models.DecimalField(max_digits=4,decimal_places=2)
    # weight = models.FloatField()
    # gender = models.BooleanField(default=True)
    # n = models.NullBooleanField()

    d = models.DateField()
    t = models.TimeField()
    dt = models.DateTimeField()
    dt1 = models.DateTimeField(auto_now=True)   # 每次修改都可以更改的时间
    dt2 = models.DateTimeField(auto_now_add=True)   # 保存的是创建的时间，修改数据不会改变时间

    f = models.FileField()  # 上传文件
    # Img = models.ImageField()   # 上传图片

    def __str__(self):
        return self.name


