from django.contrib import admin
from .models import Author

# Register your models here.
@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):

    def show_gender(self):
        if self.gender:
            return "男"
        else:
            return "女"
    list_display = ['first_name','last_name','email',show_gender]

# admin.site.register(Author,AuthorAdmin)