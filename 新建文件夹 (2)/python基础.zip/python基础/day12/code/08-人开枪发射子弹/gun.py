



#   枪：
#       属性：弹夹
#       方法：发射子弹，换弹夹

import time
from clip import Clip

class Gun(object):
    def __init__(self, clip):
        self.clip = clip   # 弹夹

    # 开枪发射子弹(让弹夹中子弹数量-1)
    def shoot(self):
        # 获取弹夹中子弹的数量
        number = self.clip.getNumber()

        if number < 1:
            print("子弹已经发射完了")
            print("自动更换弹夹...")
            self.changeClip()
            time.sleep(1)
            print("更换弹夹完成...")

        else:
            # 让弹夹中的子弹数量-1
            self.clip.setNumber(number-1)

            # 打印子弹数量
            print("发射了1颗子弹， 剩余 %d 颗子弹" % self.clip.getNumber())


    # 换弹夹
    def changeClip(self):
        # 创建一个新的弹夹
        newClip = Clip()
        newClip.setNumber(30)

        # 将当前枪的弹夹更换为newClip
        self.clip = newClip