
# 3、班级学生类
# 	学生类：
# 		属性：姓名，年龄，性别，成绩，学号
#
# 	班级类：
# 		属性：班级号，班级口号，学生列表
# 		方法：
# 			显示所有学生
# 			根据学号查找学生
# 			添加一个学生
# 			根据学号删除一个学生
#
#   提示： 需要先创建多个学生对象，加入到班级对象中，再调用方法
#

from student import Student
from banji import Banji

# 先创建5个学生对象
nameList = ["杰伦", "蔡依林", "昆凌", "黄渤", "迪丽热巴"]
ageList = [39, 37, 25, 45, 26]
sexList = ["男", "女", "女", "男", "女"]
scoreList = [99, 98, 66, 77, 100]
stunoList = [11, 22, 33, 44, 55]

stuList = []  # 存的是对象，元素中虽然名字什么都一样，但是内存地址不一样，不同的对象
for i in range(len(nameList)):
    stu = Student(nameList[i], ageList[i], sexList[i], scoreList[i], stunoList[i])
    stuList.append(stu)

# 创建班级对象
myBanji = Banji("110", "生命不息，编程不止", stuList)

# 显示所有学生
myBanji.showStudents()
print()

# 根据学号查找学生
print(myBanji.searchByStuno(22))
print()

# 添加一个学生
stu = Student("白百何", 33, "女", 95, 88)
myBanji.addStudent(stu)
myBanji.showStudents()
print()

# 根据学号删除学生
myBanji.delStudentByStuno(22)
myBanji.showStudents()
print()

# 按成绩排序
myBanji.sortStudent()
myBanji.showStudents()
print()


# 排序
list1 = [{"name":"张三", "age":33}, {"name":"王五", "age":55}, {"name":"李四", "age":44}, {"name":"赵六", "age":66}]
list1.sort(reverse=True, key=lambda d: d["age"])
print(list1)
