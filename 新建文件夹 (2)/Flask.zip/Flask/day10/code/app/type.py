import pymysql
db = pymysql.connect('localhost','root','root','py')
db.set_charset('utf8')
cursor = db.cursor()
#添加顶级分类
def addTopType():
    topType = input('输入顶级分类的名称')
    sql = "insert into type values(null,'{}',{},'{}')".format(topType,0,'0,')
    cursor.execute(sql)
    db.commit()
    print('顶级分类添加成功 类别名称为',topType)

#添加子分类
def addSonType():
    fatherType = input('输入父类的类别名称')
    # 先找到父类的id 和path
    sql = 'select id,path from type where content=\'{}\''.format(fatherType)
    cursor.execute(sql)
    data = cursor.fetchone()#查询一条
    print(data)  # 列表
    sonType = input('输入子类的类别名称')
    sql = 'insert into type values(null,"{}",{},"{}")'.format(sonType,data[0],data[1]+str(data[0])+',')
    print(sql)
    cursor.execute(sql)
    db.commit()

#显示所有类别
def showType():
    pass

#删除类别
def delType():
    """
    1. 删除的类别不能有子类别
    2.怎么判断是否有子类别？
    :return:
    """
    typeName = input('输入类别名称')
    sql = 'select id from type where typename="{}"'.format(typeName)
    cursor.execute(sql)
    id = cursor.fetchone()[0]
    sql = 'select * from type where pid={}'.format(id)
    cursor.execute(sql)
    if cursor.fetchone():
        print('有子类别不能删除') #把当前类别下的所有子类别全部展示显示出来
    else:
        sql = 'delete from type where typename="{}"'.format(typeName)
        cursor.execute(sql)
        db.commit()
while True:
    print("**1 添加顶级*******2添加子类别************")
    print("**3 显示类别*******4删除类别************")
    choose = eval(input("选择"))
    if choose ==1:
        addTopType()
    elif choose == 2:
        addSonType()
    elif choose == 3:
        showType()
    else:
        delType()