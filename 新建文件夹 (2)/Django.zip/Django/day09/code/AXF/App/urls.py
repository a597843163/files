from django.conf.urls import url
from App.views import *

urlpatterns = [
    url(r'^home/$',home,name='home'),
    url(r'^market/$',market,name='market'),
    url(r'^cart/$',cart,name='cart'),
    url(r'^mine/$',mine,name='mine'),

    url(r'^market/(\d+)/(\d+)/(\d+)/$',market_with_params,name='market_with_params'),

    url(r'^register/$', register, name='register'),
    url(r'^login/$', login, name='login'),
    url(r'^logout/$', logout, name='logout'),

]



