print("hello world")
a=3
b=4
c= b is a
print(c)

age ="20"
X = int(age)
print(age,type(age))
print(X,type(X))