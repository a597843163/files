
#
# 英汉字典：使用类封装 Translate
#
# 如：
#   输入：a    得到结果：art. 一;字母A
#   输入：abc  得到结果：n. 基础知识;美国广播公司;澳大利亚广播公司
#

class Translate(object):

    def __init__(self):
        self.path = r"C:\wamp\www\day14\昨日作业\dict_eng.txt"
        self.wordDict = {}  # 存放所有单词
        self.parseWord()

    # 把单词对应的中英文存放到wordDict中
    def parseWord(self):

        # 打开文件，取出内容
        fp = open(self.path, "r", encoding="utf-8")
        content = fp.read()
        fp.close()

        # 对内容处理
        # 按照#号拆分
        wordList = content.split("#")

        for word in wordList:

            if len(word) == 0:
                continue

            list1 = word.split("\nTrans:")
            english = list1[0]  # 英语
            chinese = list1[1].rstrip("\n")  # 中文

            self.wordDict[english] = chinese


        '''
        #aardvark
        Trans:n. 土猪
        #aardwolf
        Trans:n. 土狼
        '''
    def tansFromEnglish(self, english):
        return self.wordDict[english]

#
tans = Translate()
print(tans.tansFromEnglish("aardvark"))
print(tans.tansFromEnglish("aardwolf"))








