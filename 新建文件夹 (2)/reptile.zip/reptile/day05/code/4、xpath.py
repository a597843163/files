from lxml import etree
import urllib.request
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
str = """
<div>
    <ul>
         <li class="item-0"><a href="link1.html">first item</a></li>
         <li class="item-1"><a href="link2.html">second item</a></li>
         <li class="item-inactive"><a href="link3.html"><span class="bold">third item</span></a></li>
         <li class="item-1"><a href="link4.html">fourth item</a></li>
         <li class="item-0"><a href="link5.html">fifth item</a></li>
     </ul>
 </div>
"""

html_etree = etree.fromstring(str)

# response = urllib.request.urlopen(url='http://www.baidu.com')

html_etree = etree.HTML(str)


# print(etree.tostring(html_etree).decode('utf-8'))
#
# html_parse = etree.parse('./test.html')
# print(etree.tostring(html_parse).decode('utf-8'))
#
# li_list = html_etree.xpath('//li')
# print(li_list)

#1. 查找所有的li
li_list = html_etree.xpath('/html/body/div/ul/li')
print(li_list)

# 2. 获取所有class属性
# 所有属性
c_list = html_etree.xpath('//*/@*')
print(c_list)
c_list = html_etree.xpath('//*/@class')
print(c_list)


# 3 获取所有li下的span标签
span_list = html_etree.xpath('//li//span')
print(span_list)
print(span_list[0].text)

# 4 获取倒数第二个li
li = html_etree.xpath('//li[last()-1]')
print(li)
print(etree.tostring(li[0]).decode('utf-8'))

# 选择li里面的a
a = li[0].xpath('./a')
print(a)
# 永远 记得xpath返回的是一个列表。
print(etree.tostring(a[0]))

# 查询li并且class等于item-0

li = html_etree.xpath('//li[@class!="item-0"]')
print(li)
print(etree.tostring(li[0]).decode('utf-8'))

# 属性中包含inactive

li = html_etree.xpath('//li[contains(@class, "inactive")]')
print(li)
print(etree.tostring(li[0]).decode('utf-8'))
# 不包含
li = html_etree.xpath('//li[not(contains(@class, "inactive"))]')
print(etree.tostring(li[0]).decode('utf-8'))

# 所有内容包含item的元素
el = html_etree.xpath('//*[contains(text(), "item")]')

print(el)