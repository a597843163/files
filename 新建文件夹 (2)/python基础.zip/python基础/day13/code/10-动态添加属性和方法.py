



class Person(object):
    def __init__(self, name):
        self.name = name

    def eat(self):
        print("吃货")

# 对象
p = Person("老王")
print(p.name)
p.eat()


# 动态添加属性
# 只会给当前对象添加属性，其他对象没有添加
p2 = Person("老李")
p2.age = 33
print(p2.age)  # 33
# print(p.age)  # 报错


# 动态添加方法
# sleep既是函数名，也是指向该函数的指针(变量)
def sleep(self):
    print(self.name, "睡觉")
# 等号 右边的sleep函数赋值给左边的sleep方法
p2.sleep = sleep
p2.sleep(p2)  # 老李 睡觉


from types import MethodType
def sleep2(self):
    print(self.name, "爱睡觉2")
p2.sleep2 = MethodType(sleep2, p2)
p2.sleep2()  # 老李 爱睡觉2





