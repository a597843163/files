
#
# MTK
#

'''
    时间time：
        UTC： 国际标准时间， 格林尼治时间

        1，时间戳 ： 从1970年1月1号0点开始到指定时间的总毫秒数，可以转换成秒
        2, 时间元组：
        3, 时间字符串：

        time.time() : 获取当前时间的时间戳（秒）
        # time.gmtime() : 将时间戳转换成时间元组（UTC）,默认获取当前时间的时间元组
        time.localtime() : 将时间戳转换成时间元组（中国标准时间），默认获取当前时间的时间元组

        time.mktime() : 将时间元组转换成时间戳
        time.strftime() : 将时间元组转换成字符串
        time.strptime() : 将时间字符串转换成时间元组

        # time.asctime() : 将时间元组转换成字符串
        # time.ctime() : 将时间戳转换成字符串

        time.sleep() : 暂停
        time.clock() : cpu执行时间


    字符串：
        + ： 连接字符串
        * ： 重复
        [:] : 截取/切片
        in ： 查看是否存在指定的子字符串
        len() : 字符串长度

        upper() : 转换成大写
        lower() : 转换成小写
        title() : 转换成标题形式的，每个单词的首字母大写，其他小写
        swapcase() : 字符串大小写翻转
        capitalize() : 首字母大写
        isupper() : 判断字符串中的所有字母是否为大写
        islower() : 判断字符串中的所有字母是否为小写
        istitle() : 判断是否为标题形式

        # 重要
        find() : 查找字符串第一次出现指定子字符串的下标位置，如果找不到则返回-1
        rfind() : 从右往左查找
        # index() : 跟find类似，如果查找不到会报错
        # rindex() : 从右往左查找
        split() : 字符串拆分， 返回一个列表
        splitlines() : 按行拆分， 返回一个列表
        join() : 将列表按照指定的字符串拼接成字符串
        replace(old,new,count) : new替换old, 替换前面count个，默认替换全部

        startswith() : 是否以指定字符串开头
        endswith() : 是否以指定字符串结尾
        count() : 统计子字符串出现的次数
        ord() : 将字符转换成ASCII
        chr() : 将ASCII码转换成字符
        eval() : 执行字符串表达式，返回字符串中的表达式
        list(str) : 将字符串转换成列表

'''







