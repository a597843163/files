

'''
dt_now = datetime.datetime.now()
        获取当前的日期对象，包含时间的
dt_ziding = datetime.datetime()
        根据指定的日期、时间生成一个日期对象
dt.strftime()  将日期对象转化为指定的格式
dt.date()   获取日期对象中的日期
dt.time()   获取日期对象中的时间
dt.timestamp()  获取日期对象的时间戳
dt.hour\minute\second  获取小时、分钟、秒
datetime.datetime.fromtimestamp()
        根据一个时间戳，转化为指定的日期对象
datetime.timedelta()
        生成一个差值对象，可以和日期对象直接进行相加减
        参数有，days,hours,minutes,seconds
'''


#
import datetime

# 获取当前日期对象
dtNow = datetime.datetime.now()
print(dtNow)  # 2018-03-09 15:05:55.400000
print(type(dtNow))  # <class 'datetime.datetime'>

# 获取指定日期对象
dtTime = datetime.datetime(2019, 11, 12, 3, 4, 5)
print(dtTime)  # 2019-11-12 03:04:05

print(dtTime.strftime("%Y/%m/%d"))  # 2019/11/12
print(dtTime.date())  # 2019-11-12
print(dtTime.time())  # 03:04:05

print(dtTime.timestamp())  # 1573499045.0
print(dtTime.hour)  # 3
print(dtTime.minute)  # 4
print(dtTime.second)  # 5

# 将时间戳转换成日期对象
print(datetime.datetime.fromtimestamp(1573499045.0))  # 2019-11-12 03:04:05

# 创建一个时间差的对象
delta = datetime.timedelta(days=1, hours=2, minutes=3, seconds=4)
print(dtTime + delta)
# 2019-11-12 03:04:05
# 2019-11-13 05:07:09




