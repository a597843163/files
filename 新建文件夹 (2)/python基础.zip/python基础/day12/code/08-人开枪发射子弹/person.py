



#   人：
#       属性：有枪
#       方法：开枪（让枪发射子弹），换弹夹（给枪换弹夹）


class Person(object):
    def __init__(self, gun):
        self.gun = gun   # 枪

    # 开枪
    def shoot(self):
        self.gun.shoot()  # 让枪发射子弹


    # 换弹夹
    def changeClip(self):
        self.gun.changeClip()  # 让枪换弹夹

