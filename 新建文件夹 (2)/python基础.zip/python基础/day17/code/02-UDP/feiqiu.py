

import socket

udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

data = '1:12345:廖先国:bb:32:我是SB'
address = ('10.36.137.44', 2425)
udp_socket.sendto(data.encode('gbk'), address)

udp_socket.close()