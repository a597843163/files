x = int(input("请输入一个数:"))
y = int(input("请输入一个数:"))

#max_value = x > y and x or y

max_value = x if x > y else y

print(max_value)
