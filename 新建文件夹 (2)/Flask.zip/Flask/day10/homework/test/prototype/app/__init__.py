from .models import User
from .views import register


# 注册蓝本
def register_blueprint(app):
    app.register_blurprint(register,url_prefix='/user')
