


# 偏函数

print(int("10"))

print(int("1010", base=10)) # 把值当成十进制转换成整数 1010
print(int("1010", base=2))  # 二进制, 10
print(int("1010", base=8))  # 八进制， 520


# 封装函数int2，能够将传入的str当成二进制进行转换
def int2(str):
    return int(str, base=2)

print(int2("1010"))  # 10


# 偏函数
import functools
fn2 = functools.partial(int, base=2)
print(fn2("1010"))  # 10

