from datetime import timedelta
from flask_script import Manager
from flask import Flask, session, redirect, url_for, request, render_template

app = Flask(__name__)
app.secret_key = 'adsfa'
manager = Manager(app)

@app.route('/')
def index():
    # return redirect(url_for('user.login'))
    # return render_template('index2.html')
    return render_template('child.html')

@app.route('/test/')
def test():
    return 'test函数'

# 设置isession并且设置过期时间
@app.route('/set_session/')
def set_session():
    session.permanent = True # 设置session持久化存储
    app.permanent_session_lifetime = timedelta(minutes=5) # 设置session过期时间为5分钟
    session['key'] = 'value'
    return '设置了session的过期时间'

# 删除session
@app.route('/del_session/')
def del_session():
    # session.pop('key')  # 删除某一个key的值
    session.clear()  # 删除所有的session
    return '删除session键为key的值'

# 获取session
@app.route('/get_session/')
def get_session():
    return '获取key的值为{}'.format(format(session.get('key')))

from user import user
# app.register_blueprint(user) # 注册蓝本
app.register_blueprint(user,url_prefix = '/user') # 注册蓝本 给蓝本添加一个前缀


@app.route('/form/')
def form():
    return 'form表单'


@app.before_first_request
def before_first_request():
    print('before_first_request',request.url)

@app.before_request
def before_request():
    print('before_request')

@app.after_request
def after_request(response):
    print('after_request')
    return response

@app.teardown_request
def teardown_request(response):
    print('teardown_request')


@app.route('/include/')
def include():
    return render_template('demo.html')




if __name__ == '__main__':
    # app.run(debug=True)
    # 用python manage.py runserver 启动服务器
    '''
        manage参数
        python manage.py runserver -d -r  # debug开启  r代码调试后自动修改
        python manage.py runserver -h127.0.0.1 -p5001 -d -r -threaded
    '''
    manager.run()









