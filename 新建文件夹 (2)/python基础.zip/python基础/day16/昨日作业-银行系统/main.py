

from view import View
from bank import Bank
import time

# 入口函数，主函数
def main():

    # 进入欢迎界面
    View.welcomeView()

    # 进入登录页面
    res = View.loginView()
    if res == -1:
        print("登录失败!")
        return


    # 进入功能界面
    # print("进入功能界面")
    View.functionView()

    # 创建银行对象
    myBank = Bank()

    # 循环
    while True:
        number = input("请输入您要操作的编号：")

        if number == "1":   #开户
            myBank.createUser()
        elif number == "2":  #查询
            myBank.searchUser()
        elif number == "3":  #存款
            myBank.saveMoney()
        elif number == "4":  #取款
            myBank.getMoney()
        elif number == "5":  #转账
            myBank.transferMoney()
        elif number == "6":  #改密
            myBank.modifyPasswd()
        elif number == "7":  #锁定
            myBank.lockCard()
        elif number == "8":  #解锁
            myBank.unlockCard()
        elif number == "9":  #补卡
            myBank.makeupCard()
        elif number == "0":  #销户
            myBank.delUser()
        elif number == "q":  #退出
            # 关闭银行系统， 退出程序
            print("感谢您的使用，再见!")
            time.sleep(1)
            break
        else:
            print("您输入的编号有误， 请重新输入")



# 在当前模块调用main函数
if __name__ == "__main__":
    main()


