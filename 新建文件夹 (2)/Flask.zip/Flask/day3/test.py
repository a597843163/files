def func(**kwargs):
    print(kwargs)

myDict = {'a': 1, 'b': 2}
# func(a=1,b=2)
func(**myDict)