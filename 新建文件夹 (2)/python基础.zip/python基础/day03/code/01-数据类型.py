'''
   数据类型：
            number:数字类型，整数int，浮点数float（小数）,
            string:字符串类型，如"宝强"
            boolean:布尔类型，只有两个值:True，False
            tuple:元组
            list:列表
            none：空值
            dict:字典
            set:集合

            byte:字节
'''
# type（） :用来获取变量的数据类型

#number   数字
num = 10
print (type(num))  #  <class 'int'>

# string   字符串
str = "宝强"
print(type(str))  #<class 'str'>

# boolean  布尔
b = False
a = True
print(type(b))  #<class 'bool'>
print(type(a))  #<class 'bool'>

#tuple  元组
t = (1, 2, 3, 4)
print(type(t))   #<class 'tuple'>

# list 列表
l = [1, 2, 3, 4]
print(type(l))  #<class 'list'>

#None  空值
n = None
print(type(n))  #<class 'NoneType'>

#dict   字典
d ={"name":"贾乃亮","age":33}
print(d)
print(type(d))   #<class 'dict'>

#set
s ={"贾乃亮","宝强","马蓉"}
print(s,type(s))  #<class 'set'>

# byte
b = b'12fg'
print(b,type(b)) # <class 'bytes'>