

import os

# 深度遍历

def getAllDirAndFile(sourcePath):

    # 判断目录是否存在
    if not os.path.exists(sourcePath):
        return "目录不存在"

    # 栈
    stack = []
    stack.append(sourcePath)

    while True:

        # 判断是否退出
        if len(stack) == 0:
            break

        # 从栈中获取数据（从最后取）
        dirPath = stack.pop()

        fileNameList = os.listdir(dirPath)
        for fileName in fileNameList:
            absPath = os.path.join(dirPath, fileName)
            if os.path.isfile(absPath):  # 文件
                print("fileName:", fileName)
            elif os.path.isdir(absPath):  # 目录
                print("dirName:", fileName)

                # 将当前子目录压栈
                stack.append(absPath)


if __name__ == "__main__":
    path = r"C:\wamp\www\day11\code\newdir"
    getAllDirAndFile(path)






