



'''

    面向对象： 封装， 继承， 多态

    继承：
        单继承： 多重继承
            只有一个父类
        多继承：有多个父类

    # 重写： 在继承的基础上，子类把父类的方法重写一遍
    # 类属性： 声明在类中但是在方法外面的属性，共享
    # 对象属性： 成员属性，成员变量，self.name

    # 类方法： @classmethod，可以使用类属性
    # 静态方法： @staticmethod, 不可以使用类属性，类名.类属性

    # 限制属性: __slots__ = ("name", "age")

    # 动态添加属性和方法
    # class Student:
    #     pass
    # stu.age = 33
    #
    # def eat():
    #   pass
    # stu.eat = eat
    #

    # property: 让私有变量可以通过.点语法去调用
    # self.__age = age
    # @property
    # def age():
    #
    # @age.setter
    # def age():
    #

    # __dict__

    # 多态:

'''


# 点语法.
# print(stu.age)  # 内部get方法
# stu.age = 33   # 内部set方法













