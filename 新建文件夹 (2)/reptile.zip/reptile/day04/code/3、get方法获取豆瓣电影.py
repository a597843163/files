import urllib.request
import urllib.parse
import ssl

# 如果出现证书问题，设置ssl
ssl._create_default_https_context = ssl._create_unverified_context


# get请求参数
# page_limit=50&page_start=0
url = 'https://movie.douban.com/j/search_subjects?type=tv&tag=%E7%83%AD%E9%97%A8&'

page = int(input('请输入您要获取第几页的电影：'))
data = {
    'page_limit': page * 50,
    'page_start': (page -1) * 50,
}

# 进行转化
data = urllib.parse.urlencode(data)
print(data)
url = url + data
# print(url)

response = urllib.request.urlopen(url)

# print(response.read().decode('utf-8'))
