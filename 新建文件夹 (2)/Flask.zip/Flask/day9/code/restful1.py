from flask import Flask, jsonify, abort, request
from flask_script import Manager

# 导入用户验证的模块
from flask_httpauth import HTTPBasicAuth

# 实例化用户验证
auth = HTTPBasicAuth()

# 验证用户的回调函数
@auth.verify_password
def verify_password(username,password):
    if username == '张三' and password == '123456':
        return True
    return False

app = Flask(__name__)
manager = Manager(app)

data = [
    {
        'id':1,
        'title':'孙悟空',
        'content':'老大'
     },
    {
        'id':2,
        'title':'猪悟能',
        'content':'2师兄'
    }
]


@app.route('/')
def index():

    return 'restful测试'

# 请求拿到所有的数据
@app.route('/getData/')
@auth.login_reque
def get_data_list():
    return jsonify({'data':data})

# 请求指定资源的数据
@app.route('/getData/<int:tid>/')
def get_data(tid):
    newData = list(filter(lambda p:p['id'] == tid ,data))
    if not newData:
        abort(404)
    return jsonify({'data':newData[0]})

# 创建资源
@app.route('/data/',methods=['POST'])
def creat_data():
    newData={
        'id':data[-1]['id']+1,
        'title':request.json['title'],
        'content':request.json['content']
    }
    data.append(newData)
    return jsonify({'data':newData}),201

# 删除资源
@app.route('/data/<int:tid>',methods=['DELETE'])
def delete_data(tid):
    # Bool = (lambda p:p['id'] == tid)
    # Bool(data[0])
    '''
    dataList = []
    for Dict in data:
        if (lambda p:p['id'] == tid)(Dict):
            dataList.append(Dict)
    '''
    newData = list(filter(lambda p:p['id'] == tid ,data))
    if not newData:
        abort(404)
    data.remove(newData[0])
    return jsonify({'result':200})

# 修改资源
@app.route('/data/<int:tid>',methods=['PUT'])
def put_data(tid):
    newData = list(filter(lambda p:p['id'] == tid ,data))
    if not newData:
        abort(404)
    newData[0]['title'] = request.json['title']
    newData[0]['content'] = request.json['content']
    return jsonify({'result':200})

# 错误定制
@app.errorhandler(404)
def page_not_found(e):
    return jsonify({'error':'page not found'}),404

if __name__=='__main__':
    manager.run()
