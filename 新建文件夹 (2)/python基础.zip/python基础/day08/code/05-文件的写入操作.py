


# 文件的写入操作：
#           w, a
#

# 先清空内容， 再写入内容
# fp = open("情书.txt", "w", encoding="utf-8")
# fp = open("情书.txt", "wb")
# fp = open("情书.txt", "w+", encoding="utf-8")

# fp.write("hello")
# fp.write("hello2".encode(encoding="utf-8"))

# print(fp.read())

# a
# fp = open("情书.txt", "a", encoding="utf-8")
# fp = open("情书.txt", "a+", encoding="utf-8")
#
# # fp.write("韩信")
#
# fp.seek(0)  # 设置定位在文件起始位置
# print(fp.read())
#
# fp.close()



# 定位符
# fp = open("情书.txt", "r", encoding="utf-8")
fp = open("情书.txt", "rb")

# seek() : 设置定位符的位置，单位是字节
# #  参数1： 表示偏移量，正数表示向右偏移，负数表示向左偏移
# #  参数2： 表示偏移的参考位置:
# #               0表示起始位置(默认)
# #               1表示当前位置
# #               2表示结尾位置
# hello韩信韩信
fp.seek(3)  # lo韩信韩信
fp.seek(-1, 1)  # llo韩信韩信
fp.seek(-3, 2)

# tell() : 获取定位符的位置
print(fp.tell())

print(fp.read())

fp.close()



#
#  r:  r, rb,  r+
#  w:  w, wb
#  a:  a, ab
#



