import re

from bs4 import BeautifulSoup


soup = BeautifulSoup(open('./soup_test.html', 'r', encoding='utf-8'), 'lxml')

print(type(soup), soup.name, soup.attrs)
# print(soup)
# 通过.查询标签
print(type(soup.li))
print(soup.li.string)
print(type(soup.li.string))
print(soup.head.title)



a = soup.find_all('a', {'class': 'taohua'})
print(type(a[0].string))


# 直接子节点
print(soup.head.children)

for item in soup.head.children:
    print(item)

print(soup.head.contents)
print(len(soup.head.contents))

# 子孙
print(soup.body.descendants)

for item in soup.body.descendants:
    print(item)


# find
print(soup.find('a'))

print(soup.find('a', href="https://www.baidu.com"))

# find_all

print(soup.find_all('a', href="https://www.baidu.com"))

print(soup.find_all(re.compile(r'li.*')))

print(soup.find_all(['a', 'title']))

print(soup.find_all(class_='hello'))
print(soup.find_all(id='world'))

# 使用css选择器
print(soup.select('a'))

# 通过class查找
print(soup.select('.hello'))

# 通过id查找
print(soup.select('#world'))

# 通过属性来查
print(soup.select('a[name="he"]'))


# 组合查找
print(soup.select('p.jiang'))

print(soup.select('li#world'))

# 通过标签来组合查找
print(soup.select('head > title'))

print(soup.select('body > div > ul > li > a'))


