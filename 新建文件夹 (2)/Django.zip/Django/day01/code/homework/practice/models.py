from django.db import models

# Create your models here.
# 数据库中存的内容
class Students(models.Model):
    # 字段/属性
    name = models.CharField(max_length=20)
    gender = models.CharField(max_length=20,default='男')
    age = models.IntegerField()
    info = models.CharField(max_length=20)
    is_delete = models.BooleanField(default=False)

    # 设置数据库显示格式
    def __str__(self):
        return self.name

class teachers(models.Model):
    # 字段/属性
    name = models.CharField(max_length=20)
    subject = models.CharField(max_length=20)
    info = models.CharField(max_length=20)
    like = models.CharField(max_length=20)

    def __str__(self):
        return self.name

