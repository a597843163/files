import random

from PIL import Image, ImageDraw, ImageFont
from django.http import HttpResponse
from django.shortcuts import render, redirect
import io

from django.urls import reverse


def index(request):
    return render(request, 'index.html')


def goods(request):
    return render(request, 'goods.html')


def get_goods(request):
    num = random.randrange(1, 200)
    if num > 150:
        return HttpResponse('恭喜您，抢到了满1000减999的优惠券')
    else:
        return HttpResponse("很遗憾，你没有抢到优惠券")


def hello(request):
    num = random.randint(1, 100)
    if num > 80:
        a = 1 / 0
        print(a)
    return HttpResponse("计算完毕，你的智商为200")


# 获取验证码
def get_verify_code(request):
    # Image: 画布
    size = (100, 50)  # 画布大小
    bgcolor = random_color()
    image = Image.new('RGB', size, bgcolor)

    # ImageDraw : 画笔
    image_draw = ImageDraw.Draw(image, 'RGB')

    # 创建字体对象
    image_font = ImageFont.truetype(r'C:\wamp\www\day08\code\Demo\static\fonts\ADOBEARABIC-ITALIC.OTF', 30)

    # 画内容
    # image_draw.text((10, 10), 'M', font=image_font)
    # image_draw.text((30, 10), 'A', font=image_font)
    # image_draw.text((50, 10), '9', font=image_font)
    # image_draw.text((70, 10), 'c', font=image_font)

    # 随机取4个数字或字母
    str1 = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    verify = ""  # 4位字符的验证码
    for i in range(4):
        ch = str1[random.randrange(0, len(str1))]  # 随机取一个字符
        xy = (10 + i * 20, random.randint(6, 14))
        image_draw.text(xy, ch, font=image_font, fill=random_color())
        verify += ch

    print(verify)
    request.session['verify'] = verify

    # 画一些干扰点
    for i in range(500):
        image_draw.point(random_point(), fill=random_color())

    # 通过缓冲区显示到浏览器
    buf = io.BytesIO()  # 创建二进制的缓冲区
    image.save(buf, 'png')  # 将画布写入缓冲区

    # 将画布以图片的形式返回到浏览器
    return HttpResponse(buf.getvalue(), 'image/png')


# 随机颜色
def random_color():
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    return r, g, b


# 随机点
def random_point():
    x = random.randint(0, 100)
    y = random.randint(0, 100)
    return x, y


# 用户登录页面
def user_login(request):
    return render(request, 'userLogin.html')


def do_login(request):
    if request.method == "POST":
        verify_code = request.POST.get('verifycode')  # 从浏览器提交过来的验证码
        verify = request.session['verify']  # 保存在服务器session中的验证码

        # 都变成大写，让大小写不区分
        verify_code = verify_code.upper()
        verify = verify.upper()

        # 验证成功
        if verify == verify_code:
            return HttpResponse("验证成功!")
        # 验证失败
        else:
            return HttpResponse("验证失败!")
    else:
        return redirect(reverse('app:user_login'))
