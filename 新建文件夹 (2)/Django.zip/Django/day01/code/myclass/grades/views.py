from django.shortcuts import render
from .models import Grade

# Create your views here.

def grade_list(requeset):
    g_list = Grade.objects.all() #获取Grade模型中所有的数据
    return render(requeset,'grades/list.html',{'g_list':g_list})