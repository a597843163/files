from datetime import datetime

from flask import Blueprint, render_template, flash, get_flashed_messages, redirect, url_for, request, jsonify
from app.models import Posts,User
from app.forms import PostsForm
from flask_login import current_user
from app.extensions import db

posts = Blueprint('posts',__name__)

#发表帖子的路由
@posts.route('/publish/',methods=['GET','POST'])
def publish():
    form = PostsForm()
    if form.validate_on_submit():
        if current_user.is_authenticated:
            #获取当前current_user代理对象的真实对象
            u = current_user._get_current_object()
            p = Posts(content=form.content.data,user=u)
            db.session.add(p)
            flash('博客发表成功！！！')
            return redirect(url_for('posts.publish'))
        else:
            flash('你还没有登录 请登录在发表')
            return redirect(url_for('user.login'))
    return render_template('posts/publish.html',form=form)

# 处理收藏和取消收藏的路由
@posts.route('/collect/<int:pid>')
def collect(pid):
    if current_user.is_favorite(pid):
        # 取消收藏
        current_user.remove_favorite(pid)
    else:
        # 添加收藏
        current_user.add_favorite(pid)
    return jsonify({'result':'ok'})

'''
# append 添加
    # remove  删除
    #拿到 id为1 的用户对象
    """
    #取消收藏
    u = User.query.get(1)
    p = Posts.query.get(2)
    u.favorites.remove(p) #取消收藏 2号帖子

    #查看用户1 收藏了哪些帖子
    u = User.query.get(1)
    print(u.favorites.all()) #查询当前id为1的用户有哪些收藏的帖子

    #1号用户 收藏了2号提诶
    u = User.query.get(1)
    p = Posts.query.get(2)
    u.favorites.append(p) #1号用户收藏了1号帖子
    """
    #查看2 号帖子都被谁收藏了
    p = Posts.query.get(2)
    print(p.users.all())  #获取帖子都被谁收藏了
'''


@posts.route('/insertto/')
def insertto():
    # u = current_user._get_current_object()
    p = Posts(content='送个p的礼物，不送了！',pid=14,path='0,2,14,',uid=2)
    db.session.add(p)
    db.session.commit()
    return '加入数据成功'
#
# insertto('送一幢豪宅',2,'0,2,',2)


# 点击我发布的帖子,显示帖子
# 点击我发布的帖子,显示帖子
@posts.route('/showposts/')
def show_myposts():
    '''
    1.把数据传给template,
    2.模板进行显示
    :return:
    '''
    # 获取当前用户的所有帖子
    if current_user.is_authenticated:
        # 得到当前用户对象
        u = current_user._get_current_object()
        # 当前页码数
        page = int(request.args.get('page', 1))
        # 拿到本用户的分页对象
        pagination = Posts.query.filter(Posts.uid == u.id).order_by(Posts.timestamp.desc()).paginate(page, 5, False)
        data = pagination.items
    return render_template('posts/show_myposts.html',data=data,pagination=pagination,def_name='posts.show_myposts')

# 帖子详情页
'''
    1.点击一个帖子，然后进入页面
    2.页面显示内容: 1.user, 2.user头像  3.帖子的内容  4.时间.  5.评论回复 
'''
# # 帖子详情页
@posts.route('/postsinfo/<posts_id>')
def posts_info(posts_id):
    # 拿到帖子对象,并且传入
    p = Posts.query.filter(Posts.id==posts_id).first()
    # 找到path字段中带有,2,
    Str1 = ','+str(posts_id)+','
    # 找到所有的评论,并且按照path+pid做一个排序
    # answers = Posts.query.order_by(Posts.path+Posts.pid).filter(Posts.path.contains(Str1))
    # return render_template('posts/postsinfo.html',p=p ,answers=answers)
    # 一级对象:
    answers1 = Posts.query.filter(Posts.pid==posts_id)
    # answers.pid == posts_id  此条件为一级条件 ,一级评论对象
    # 二级评论对象:  answers.pid(二级) = answers.id(一级)
    answers2 = Posts.query.filter(Posts.path.contains(Str1))
    return render_template('posts/postsinfo.html',p=p ,answers1=answers1,answers2=answers2)

# 评论功能,,1.评论内容(有了),   2.当前登陆的用户  3.评论帖子的对象(有了)  3.存入posts表
# 回复评论功能 ,1.评论内容  2.回复的谁的帖子  3.当前登陆的用户  4.存入posts表  5.
@posts.route('/comment/')
def comment():
    # 当前登陆的用户
    u = current_user._get_current_object()
    # 当前评论的内容
    content = request.args.get('value')
    # print(content)
    # 当前帖子的对象
    pid = request.args.get('pid')
    po = Posts.query.filter(Posts.id==pid).first()
    # print(pid)
    p = Posts(content=content,pid=pid,path=(po.path+pid+','),user=u)
    db.session.add(p)
    db.session.commit()
    print('评论成功')
    return jsonify({'result':'ok'})
    # return redirect(url_for('posts.posts_info',posts_id=pid))

# 我的收藏
@posts.route('/shoucang/')
def shoucang():
    return '收藏页面'

