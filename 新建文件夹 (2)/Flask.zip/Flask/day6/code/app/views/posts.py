from flask import Blueprint

posts = Blueprint('posts',__name__)

@posts.route('/collect/')
def collect():
    return '收藏帖子'
