

import re

# {} : 表示前面字符出现的次数
# [] : 表示单个字符出现的范围
# () : 分组，整体


str = "0755-98765432"
# reg = "\d{3,4}-\d{8}"
# reg = "(\d{3,4}-\d{8})"
reg = "((\d{3,4})-(\d{8}))"

res = re.search(reg, str)
print(res)

# group() : 获取分组的内容
print(res.group())  # '0755-98765432'
print(type(res.group()))  # <class 'str'>
print(res.group(0))  # '0755-98765432'
print(res.group(1))  # 获取第一个()中的内容  0755-98765432
print(res.group(2))  # 0755
print(res.group(3))  # 98765432
# print(res.group(4))  # 报错， 没有第4个括号


# 起别名 (?P<别名>正则)
str = "0755-98765432"
reg = "(?P<First>\d{3,4})-(?P<Last>\d{8})"

res = re.search(reg, str)
print(res.group("First"))  # 0755
print(res.group("Last"))  # 98765432
print(res.group(1))  # 0755

# groups() : 捕获所有分组中的内容，返回一个元组
print(res.groups())  # ('0755', '98765432')


# findall()
str = "0755-98765432"
# reg = "\d{3,4}-\d{8}"
# reg = "(\d{3,4})-(\d{8})"
reg = "((\d{3,4})-(\d{8}))"

res = re.findall(reg, str)
print(res)  # ['0755-98765432']
            # [('0755', '98765432')]
            # [('0755-98765432', '0755', '98765432')]
print(type(res))    # <class 'list'>
print(type(res[0]))  # <class 'tuple'>








