
# 导入socket模块
import socket

# UDP服务端

# 1，创建UDP服务端的socket对象
# 2，绑定ip和端口
# 3，可以接收客户端的数据

# 1，创建UDP服务端的socket对象
# SOCK_DGRAM : 表示udp， 发送报文
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 2，绑定ip和端口
serverSocket.bind(("10.36.137.101", 8887))

# 3，可以接收客户端的数据
while True:
    print("等待客户端发送数据..")

    # 接收数据
    data, address = serverSocket.recvfrom(1024)
    print(data.decode("utf-8"))
    print(address)

    # 发送数据
    sendData = "今晚吃鸡"
    serverSocket.sendto(sendData.encode("utf-8"), address)





