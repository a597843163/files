
from person import Person
from gun import Gun
from clip import Clip


# 创建弹夹对象, 并设置30发子弹
clip1 = Clip(30)


# 创建枪对象
gun1 = Gun(clip1)

# 创建人的对象
person1 = Person(gun1)


for i in range(100):
    person1.shoot()

# person1.shoot()












