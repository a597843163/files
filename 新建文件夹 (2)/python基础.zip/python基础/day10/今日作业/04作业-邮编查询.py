fp = open("youbian.txt","r",encoding="utf-8")
str1=fp.read()
# import youbian
#
# 题目： 邮编查询
# 	创建函数， 传入一个邮编，得到归属地
#
#  key = 左边
#  value = 右边
# str1=youbian.yb
# print(str1)

def fn(n):
        dict1 = {}
        str2 = str1.splitlines()
        for i in str2 :
            str3 = i.replace('"],',"")
            str3 = str3.replace('"',"")
            str3 = str3.replace("[","")
            list1 =str3.split(",")   #  按逗号拆分，得到2个元素，取第一个和第二个
            key = int(list1[0])
            value=list1[1]
            dict1[key]=value
        return dict1[n]
print(fn(654322))
fp.close()
