
# debug
# 断点

a = 10
b = "hello"
c = [1,2,3]

def fn():
    d = 100
    e = 200

print(a)
print(b)
print(c)

fn()

print(1)


# 解决bug
# 1, 简单的bug直接看（line，Error信息， nameError, typeError）
# 2，使用print()
# 3，调试debug
# 4，注释代码（简单粗暴）



