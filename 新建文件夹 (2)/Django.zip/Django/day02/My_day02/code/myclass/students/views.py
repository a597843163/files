from django.shortcuts import render,redirect
from .models import Student
from django.urls import reverse
from datetime import datetime

def student_list(request):
    s_list = Student.objects.all()
    return render(request, 'students/list.html', {'s_list': s_list})


def detail(request):
    return render(request, 'students/detail.html')


def detail2(request, id):
    # 获取id1所对应的学生信息
    stu = Student.objects.get(id=id)
    return render(request, 'students/detail.html', {'id1': id, 'stu': stu})


def detail3(request, id1, id2):
    return render(request, 'students/detail.html', {'id1': id1, 'stu': {}, 'id2': id2})


def index(request):
    # 重定向
    # return redirect(reverse('students:list'))
    # return redirect(reverse('students:detail2',args=[2]))
    # return redirect(reverse('students:detail2',kwargs={'id': 1}))

    # 变量
    name = '宝强'
    age  = 32
    height = 160
    is_handsome = False
    is_strong = True

    likes = ['吃鸡蛋', '喝牛奶', '坑队友']

    # for
    city_list = [
        {'country':'中国','city_list':['北京','深圳','上海','广州']},
        {'country': '日本', 'city_list': ['东京', '大阪', '广岛', '名古屋']},
        {'country': '美国', 'city_list': ['华盛顿', '西雅图', '纽约', '洛杉矶']},
        {'country': '英国', 'city_list': ['伦敦', '格林尼治', '利物浦', '曼彻斯特']}

    ]

    # 过滤器
    stu_num = 40
    stu_name = "zhang SAN"
    showtime = datetime.now()


    return render(request,'students/index.html',
                  {
                    'name':name,
                    'age':age,
                    'is_handsom':is_handsome,
                    'is_strong':is_strong,
                    'likes':likes,
                    'city_list':city_list,
                    'stu_num':stu_num,
                    'stu_name':stu_name,
                    'd':showtime,
                  })
