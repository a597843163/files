


# 银行卡
#  Card
#    属性： 卡号，密码，余额， 是否锁定
#

class Card(object):
    def __init__(self, cardId, passwd, money):
        self.cardId = cardId
        self.passwd = passwd
        self.money = money
        self.isLock = False  # 默认不锁定

    def __str__(self):
        return "卡号:%s  密码:%s  余额:%.2f  是否锁定:%d" % (self.cardId, self.passwd, self.money, self.isLock)



