
'''

    作用域： 起作用的范围
        全局作用域
        局部作用域

    python中模块，类， 函数会形成作用域
            while,for,if,elif,else都不会形成作用域

    全局变量：作用于全局范围的变量
    局部变量：作用于局部范围的变量

'''

# num1 是全局变量， 全局变量一旦定以后，可以在其他地方使用（包括函数内部）
num1 = 10
def fn():
    print(num1)  # 10

fn()
print(num1)  # 10


# 局部变量
# num2 是局部变量，作用范围在当前的函数内，只能在函数内部使用
def fn2():
    num2 = 100
    print("num2 =", num2)  # num2 = 100

fn2()
# print(num2)  # 报错,在作用于范围之外不可以使用局部变量


# 形参也是局部变量
def fn3(num3):
    print("num3 =", num3)  # num3 = 10

fn3(10)
# print(num3) # 报错


# if,while,for不包含作用域
if True:
    num4 = 44
print("num4 =", num4)

for i in range(1):
    pass  # 占位符
    num5 = 55
print(num5)




n1 = 10
def fn4():
    # n1 = 1  #定义了一个局部变量n1,只是变量名和函数外面的全局变量名一样

    global n1  #将变量n1设置为全局变量的n1，那么后面使用的都是全局变量的n1
    n1 = n1 + 1
    print(n1)

fn4()
print("-- n1 =", n1)


# 函数嵌套
# fn5()  #不可以在函数定义之前调用
m = 1000
def fn5():
    m = 100
    def fn6():
        #global m  # 这里使用的m=1000
        nonlocal m  # 不使用局部变量m, 这里的m=100
        m += 1
        print("fn6, m =", m)

    fn6()

fn5()




