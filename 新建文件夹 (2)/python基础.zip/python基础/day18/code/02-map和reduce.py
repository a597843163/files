

# 高阶函数
# map() : 可以根据现有的列表返回一个新的列表
# fn1 既是函数名， 也是指向该函数的变量
def fn1(n):
    return n*n

list1 = [1, 2, 3, 4]
list2 = map(fn1, list1)
print(list2)  # <map object at 0x00000000021DAAC8>
print(type(list2))  # <class 'map'>
print(list(list2))  # [1, 4, 9, 16]
print(list1)  # [1, 2, 3, 4]

# [1,2,3,4] => ["1", "2", "3", "4"]
list3 = list(map(str, list1))
print(list3)  # ['1', '2', '3', '4']


# reduce()
from functools import reduce

# 累加
def fn2(a, b):
    return a + b
# [1, 2, 3, 4, 5, 6,...]
res = reduce(fn2, list(range(1, 101)))
print(res)  # 5050

# 累乘
def fn3(a, b):
    return a * b

res = reduce(fn3, list(range(1, 6)))
print(res)  # 120











