import urllib.request
from bs4 import BeautifulSoup
import urllib.parse
import json


class ZhiLian(object):
    """docstring for ZhiLian"""

    def __init__(self, url, area, gangwei, start_page, end_page):
        super(ZhiLian, self).__init__()
        self.url = url
        self.area = area
        self.gangwei = gangwei
        self.start_page = start_page
        self.end_page = end_page
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537'
        }
        self.items = []

    # 将url生成请求对象的函数
    def handle_url(self, page):
        data = {
            'jl': self.area,
            'kw': self.gangwei,
            'p': page
        }
        # 将参数编译成url可以识别的
        data = urllib.parse.urlencode(data)
        url = self.url + data
        request = urllib.request.Request(url=url, headers=self.headers)
        return request

    # 处理下载请求的函数
    def download(self, request):
        response = urllib.request.urlopen(request)
        data = response.read()
        soup = BeautifulSoup(data, 'lxml')
        # print(soup,data)
        table_list = soup.select('#newlist_list_content_table > table')[1:]
        for table in table_list:
            item = {}
            # 获取职位名称
            zwmc = table.select('.zwmc > div > a')[0].get_text()
            # 去除最后的&nbsp
            zwmc = zwmc.strip()
            # 获取公司名称
            gsmc = table.select('.gsmc > a')[0].string
            # 获取职位月薪
            zwyx = table.select('.zwyx')[0].string
            # 获取工作地点
            gzdd = table.select('.gzdd')[0].string
            item['zwmc'] = zwmc
            item['gsmc'] = gsmc
            item['zwyx'] = zwyx
            item['gzdd'] = gzdd
            self.items.append(item)

    # 对外提供的接口函数
    def start(self):
        for page in range(self.start_page, self.end_page + 1):
            request = self.handle_url(page)
            self.download(request)
        # 将保存的内容写入到文件中
        string = json.dumps(self.items, ensure_ascii=False)
        with open('zhilian.json', 'w', encoding='utf-8') as fp:
            fp.write(string)

def main():
    url = 'http://sou.zhaopin.com/jobs/searchresult.ashx?'
    area = input('请输入工作地点:')
    gangwei = input('请输入工作岗位:')
    start_page = int(input('请输入起始页面:'))
    end_page = int(input('请输入结束页面:'))

    obj = ZhiLian(url, area, gangwei, start_page, end_page)
    obj.start()

if __name__ == '__main__':
    main()