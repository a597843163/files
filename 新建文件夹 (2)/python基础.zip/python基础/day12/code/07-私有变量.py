# 私有变量： 只能在类中使用的变量
class BoyFriend(object):

    # 构造函数
    def __init__(self, name, age, height):
        self.name = name

        # 私有变量：给变量的前面添加两个下划线,如__age, 那么该变量就会变成一个私有变量
        #          如果想在类外部使用私有变量，一般提供get方法和set方法，使变量更加安全
        self.__age = age
        self._height = height

    # 获取年龄
    def getAge(self):
        return self.__age

    # 设置年龄
    def setAge(self, newAge):
        if newAge>=22 and newAge<=90:
            self.__age = newAge
        else:
            print("年龄不符合要求")



# 创建对象
wangSiCong = BoyFriend("王思聪", 30, 175)
print(wangSiCong.name)
# print(wangSiCong.age)  # 报错
# print(wangSiCong.__age)  # 报错
print(wangSiCong._height)

# 使用get和set方法
print(wangSiCong.getAge())  # 30
wangSiCong.setAge(31)
print(wangSiCong.getAge())  # 31


# 也可以通过_类名__属性 来获取和设置私有变量
#   私有变量在python解释器运行时，会将私有变量转成 _类名__属性 属性名
#   帅的人一般不这么做
print(wangSiCong._BoyFriend__age)  # 31
wangSiCong._BoyFriend__age = 32
print(wangSiCong._BoyFriend__age)  # 32


# __A__ 这种形式的变量一般是特殊变量
# __name__ : 获取类名
print(BoyFriend.__name__)  # BoyFriend


# _A : 一个下划线开头的属性相同于普通属性, 但是如果碰到有一个下划线开头的变量
#      那么该变量想表达"请把我当成私有变量看待，不要直接使用我"






