


# 字符串String：使用单引号或双引号包裹的内容

name = "宝强"
age = 33
sex = '爷们'

# 只要是变量就不用加引号
#  + ： 表示字符串连接
print(name + "是" + sex)

# print(name + "是" + age)  # 报错
print(name + "是" + str(age))

# * : 重复字符串
print(name + " very "*10 + sex)



# 字符串中字符的获取
str1 = "I like KingOfGlory"

# 字符串[索引/下标]，如：str1[0]
# 索引：从0开始, 负数表示倒数第几个,如str1[-1]表示获取倒数第1个字符
print(str1[0])  # I
print(str1[1])  #
print(str1[2])  # l
print(str1[3])  # i
print(str1[-1])  # y
# print(str1[100])  #报错，IndexError: string index out of range ,下标越界:超出了字符串长度范围

# len() : 可以获取字符串的长度
print(len(str1))  # 18

# 字符串最后一个字符的下标：len(str1)-1
print(str1[len(str1)-1])  # y


# 字符串截取， 不会改变字符串的， 字符串是不可变的类型
# str[start:end]
# start: 表示字符串中的起始位置(下标，包含),默认可以不写，默认值是0
# end :表示字符串中的结束位置(下标，不包含)，默认也可以不写，表示一直到字符串末尾
str1 = "I like KingOfGlory"
print(str1[:])   # "I like KingOfGlory"
print(str1[7:])  # "KingOfGlory"
print(str1[:5])  # "I lik"
print(str1[2:6])  # "like"
# print(str1[12:6])  # 获取不到内容，因为前面的下标比后面的下标大，不要这么写


# 逆序
# 第三个参数： 表示步长，-1表示倒序，默认是1
print(str1[::-1])  # "yrolGfOgniK ekil I"
print(str1[::2])  #"Ilk igflr"


# 字符串占位符： %d, %s, %f(%.2f)


# 使用in来判断子字符串是否在字符串中
str2 = "KingOfGlory"
print(str2 in str1)  # True



# 转义字符
# \n : 换行符
# \t : 制表符
print("张三", end=" love ")
print("李四")

print("论语\n子在川上曰\n逝者如斯夫\t不舍昼夜")

print("""论语
子在川上曰
逝者如斯夫 不舍昼夜""")

# \" : 在字符串内部表示", \的作用是将带有语义的字符变成没有语义
print("I am, \"good\"")
print("I am \\\\good man")

# C:\wamp\www\day04
print("C:\\wamp\\www\\day04")

# r"C:\wamp\www\day04" :可以让字符串中的带有语义的字符没有语义
print(r"C:\wamp\www\day04")




