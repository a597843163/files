from django.apps import AppConfig


class PublishersConfig(AppConfig):
    name = 'publishers'
