


# 实现装饰器，返回被装饰函数hello()执行过程所需的时间
import time

def outer(fn):
    def inner(*args, **kwargs):

        # time.clock()
        # fn(*args, **kwargs)
        # return time.clock()

        start = time.time()
        fn(*args, **kwargs)
        return time.time()-start

    return inner

@outer
def hello():
    for i in range(3):
        time.sleep(0.2)

# 调用
print(hello())  # ≈0.6s




# isdigit() :判读是否为数值型字符串
# str1 = "342342"
# print(str1.isdigit()) # 判读是否为数值型字符串







