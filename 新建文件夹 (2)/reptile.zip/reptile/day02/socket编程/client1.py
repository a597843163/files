import socket


# 创建一个socket对象
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 连接服务器

client.connect(('10.36.137.63', 10201))

while True:
    data = input('请输入你想说的话：')
    client.send(data.encode('utf-8'))
    recv = client.recv(1024)
    print(recv.decode('utf-8'))