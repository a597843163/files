## NoSQL Mongodb

NoSQL(NoSQL = Not Only SQL )，意即"不仅仅是SQL"。

MongoDB 将数据存储为一个文档，数据结构由键值(key=>value)对组成。MongoDB 文档类似于 JSON 对象。字段值可以包含其他文档，数组及文档数组。

#### MongoDB  概念解析

| SQL术语/概念    | MongoDB术语/概念 | 解释/说明                   |
| ----------- | ------------ | ----------------------- |
| database    | database     | 数据库                     |
| table       | collection   | 数据库表/集合                 |
| row         | document     | 数据记录行/文档                |
| column      | field        | 数据字段/域                  |
| index       | index        | 索引                      |
| table joins |              | 表连接,MongoDB不支持          |
| primary key | primary key  | 主键,MongoDB自动将_id字段设置为主键 |

## 数据类型

- 下表为MongoDB中常用的几种数据类型：
- Object ID：文档ID
- String：字符串，最常用，必须是有效的UTF-8
- Boolean：存储一个布尔值，true或false
- Integer：整数可以是32位或64位，这取决于服务器
- Double：存储浮点值
- Arrays：数组或列表，多个值存储到一个键
- Object：用于嵌入式的文档，即一个值为一个文档
- Null：存储Null值
- Timestamp：时间戳
- Date：存储当前日期或时间的UNIX时间格式

#### 需要注意的是：

1. 文档中的键/值对是有序的。
2. 文档中的值不仅可以是在双引号里面的字符串,还可以是其他几种数据类型（甚至可以是整个嵌入的文档)。
3. MongoDB区分类型和大小写。
4. MongoDB的文档不能有重复的键。
5. 文档的键是字符串。除了少数例外情况，键可以使用任意UTF-8字符。

#### 文档键命名规范：

- 键不能含有\0 (空字符)。这个字符用来表示键的结尾。
- .和$有特别的意义，只有在特定环境下才能使用。
- 以下划线"_"开头的键是保留的(不是严格要求的)。


## 安装

- 下载mongodb的版本，两点注意
  - 根据业界规则，偶数为稳定版，如1.6.X，奇数为开发版，如1.7.X
  - 32bit的mongodb最大只能存放2G的数据，64bit就没有限制


### 一 链接Mongodb

##### (1) cd mongo安装的目录/bin

##### 	输入 mongod.exe     --dbpath=路径

(2) 重新启动一个Windows的终端  再次进入到 **mongo安装的目录/bin**

​	cd   **mongo安装的目录/bin**

​	mongo.exe   #此刻 进入到Mongodb数据库了



### 二 对于库的操作

#####  (1)  查看所有的库

​	show dbs

##### (2) 选择数据库 (如果使用的数据库存在 则使用 不存在 则创建)

​	use 库名 

​	注意:

​		新创建的数据库 默认你是看不到的 可以使用db/db.getName() 去查看当前所在的库   往新的库里创建集合

##### (3) 查看当前所在的数据库

```python
1. db
2. db.getName()
```

##### (4) 创建集合(也就是创建表) 

1. db.createCollection("集合名")

   例如：db.createCollection("user") #创建一个user的集合 在当前的库里

2. db.集合名.insert(文档)  #如果 当前的集合名不存在 那么就创建该集合 并插入文档(数据) 

注意：

```python
1. 在库里对于文档 集合的操作 统一使用db. (db代表当前的库)
2. 严格区分大小写
```

##### (5) 查看当前库下的所有集合

​	show collections

##### (5) 删除集合

​	db.集合名.drop()

### 三 INSERT/SAVE文档的添加

##### (1) 使用insert		如果是添加数据 建议使用 insert

​	db.集合名.insert(文档) #如果是添加数据 建议使用 insert

##### 	插入多条数据:

​	db.集合名.insert([文档]) #注意 一定要加[] 否则可能只会把 第一条文档插入进去

#### 3.2 版本后还有以下几种语法可用于插入文档:

- **db.collection.insertOne**():向指定集合中插入一条文档数据
- **db.collection.insertMany**():向指定集合中插入多条文档数据

##### (2) 使用save

1.   db.集合名.save(文档)  #新添加 一个文档 

2. db.集合名.save({_id:ObjectId("59a385d4a356cb252c1dcd73"),文档})  #对原有的数据进行覆盖

  ```python
   db.user.save({_id:ObjectId("59a385d4a356cb252c1dcd73"),name:"王五"})
  ```


### 四 UPDATE 文档的修改 

```python
db.collection.update(
   <query>,
   <update>,
   {
     upsert: <boolean>,
     multi: <boolean>,
     writeConcern: <document>
   }
)
```

- **query **: update的查询条件，类似sql update查询内where后面的。
- **update **: update的对象和一些更新的操作符（如$,$inc...）等，也可以理解为sql update查询内set后面的
- **upsert **: 可选，这个参数的意思是，如果不存在update的记录，是否插入objNew,true为插入，默认是false，不插入。
- **multi **: 可选，mongodb 默认是false,只更新找到的第一条记录，如果这个参数为true,就把按条件查出来多条记录全部更新

#### 更新操作符  `$set直接修改   $inc累加修改`

##### 例子：

###### db.集合名.update(条件,数据,{multi:true}) 更改

###### db.user.update({name:"张三"},{$inc:{age:5}}) #修改name为张三的文档  将age在原有的基础上 加5

###### db.user.update({name:"张三"},{$set:{age:5}}) #修改name为张三的文档  将age的值 修改为5

db.user.update({name:"张三"},{$set:{age:5}},{multi:true}) #将所有name为张三的文档 的年龄 全部修改为 5

##### 只更新第一条记录：

###### db.col.update( { "count" : { $gt : 1 } } , { $set : { "test2" : "OK"} } );

##### 全部更新：

###### db.col.update( { "count" : { $gt : 3 } } , { $set : { "test2" : "OK"} },false,true ); 

##### 只添加第一条：

###### db.col.update( { "count" : { $gt : 4 } } , { $set : { "test5" : "OK"} },true,false );

#### **删除集合中所有文档的一个域**

db.posts.update({}, { $unset: { deleted_at: 1 } }, { multi: true })

1.第一个参数表示选中某些文档，这里为 {} 表示选中当前 posts 集合中的所有文档
2.第二个参数为具体的更新操作，$unset 表示删除域
3.第三个参数为额外选项，{ multi: true } 表示更新所有满足要求的文档，默认只会更新第一个

**也可以同时删除多个域** 代码如下:
db.categories.update({}, { $unset: { deleted_at: 1, desc: 1 } }, { multi: true })

**也以同时删除和新增域** 代码如下:

```python
db.tags.update(
    {},
    { $unset: { deleted_at: 1 }, $set: { slug: 1, description: 1 } },
    { multi: true }
)
```



#### 3.2版本以后

**updateOne()**  更新一条

**updateMany(query,update,true/false)** 更新多条  第三个参数为upsert:true/false

### 五 REMOVE 文档的删除

```python
db.collection.remove(
   <query>,
   {
     justOne: <boolean>,
     writeConcern: <document>
   }
)
```

**参数说明：**

- **query **:（可选）删除的文档的条件。
- **justOne **: （可选）如果设为 true 或 1，则只删除一个文档。
- **writeConcern **:（可选）抛出异常的级别。

##### 主体结构

**db.集合名.remove(条件)** #默认将所有都匹配到的数据进行删除

**db.集合名.remove(条件,1)** #只删除 第一个匹配到的数据

**db.集合名.remove(条件,,{justOne:true})** #只删除 第一个匹配到的数据

db.t.remove({price:{\$gte:16},price:{$lte:32}}) #删除 价格在 16-32之间的所有数据

db.col.remove({})  清空集合 "col" 的数据

#### 3.2 版本后还有以下几种语法可用于插入文档:

remove() 方法已经过时了，现在官方推荐使用 

##### deleteOne() 删除一条

##### deleteMany() 删除多条

### 六 FIND 查询

##### (1) find 查询所有

​	db.集合名.find([条件],{key1:1[,[key2:1]]}) #查询所有的数据   代表 显示哪些字段名

​	db.collection.find(query, {title: 1, by: 1}) // inclusion模式 指定返回的键，不返回其他键	    

​	db.collection.find(query, {title: 0, by: 0}) // exclusion模式 指定不返回的键,返回其他键

##### 注意：

两种模式不可混用（因为这样的话无法推断其他键是否应返回）

```python
db.collection.find(query, {title: 1, by: 0}) // 错误
```

_id 键默认返回，需要主动指定 _id:0 才会隐藏

只能全1或全0，除了在inclusion模式时可以指定_id为0

```python
db.collection.find(query, {_id:0, title: 1, by: 1}) // 正确
```

##### (2) findOne()  查询一条

​	db.集合名.findOne([条件],{key1:1[,[key2:1]]}) #查询一条数据  代表 显示哪些字段名

##### (3) count 统计数据条数

​	db.集合名.find([条件]).count()

##### (4) pretty()  展开来查看

​	db.集合名.find([条件]).pretty()

##### (5) 查询条件的操作符

```python
1. $gt 	大于 		db.user.find({age:{$gt:18}})
2. $gte 大于等于       db.user.find({age:{$gte:20}})
3. $lt     小于              db.user.find({age:{$lt:20}})
4. $lte   小于等于       db.user.find({age:{$lte:20}})
5. 等于 {key:value}    db.user.find({age:20})
6. 使用id来进行查询  {_id:ObjectId("id值")}
7. /数据/ 模糊查询      {name:/张/}
8. /^数据/   以什么作为开头   {name:/^张/}
9. /数据$/   以什么作为结尾   {name:/张$d/}
9. $in 在...之内           {age:{$in:[10,20]}}   #查询所有数据 年龄为 10,20
10. $nin  不在...之内    {age:{$nin:[10,20]}}
11.$ne    不等于!=		  db.user.find({age:{$nin:20}})
```

##### (6) AND 查询

```python
db.col.find({key1:value1, key2:value2}).pretty()
```

db.集合名.find({条件一，条件二,,,})

例如：

​	db.user.find({name:"张三",age:{$gt:10}}) #查询name为张三的 且 年龄 大于10岁的

​	db.user.find({name:"张三",age:10}) 		#查询name为张三的 且 年龄为10岁的

​	db.user.find({name:"张三",age:{\$gte:10,$lte:28}})  #name为张三  年龄 大于等于10  小于等于28

##### (7) OR  查询

db.集合名.find({$or:[{条件一},{条件二},,,]})

例如：
​	db.user.find({$or:[{name:"张三"},{name:"赵六"}]})   #查询name为张三 或者为赵六的所有数据

​	db.col.find({$or:[{"by":"菜鸟教程"},{"title": "MongoDB 教程"}]}).pretty()

##### (8) AND 和 OR 的使用

db.集合名.find({条件一,,,$or:[{条件1},{条件2}]})

例如:

​	db.user.find({name:"张三",$or:[{age:10},{age:28}]})  #name为张三   年龄为10岁或者28岁的所有数据

​	db.col.find({"likes": {$gt:50}, $or: [{"by": "菜鸟教程"},{"title": "MongoDB 教程"}]}).pretty()

##### (9) LIMIT  取值

db.集合名.find().limit(num)   #从第0个开始取几个

例如：

​	db.user.find().limit(5)   #从0开始取5条数据

##### (10)  skip 跳过几个

edb.集合名.find().skip(num) #跳过几条数据

##### 例如:

##### 	db.user.find().skip(2) #从第三条数据 取到最后

##### (11) limit  skip 配合使用

db.集合名.find().skip().limit(num) 

例如:

​	db.user.find().skip(2).limit(2)  #从第三个开始 取2个

##### (12) SORT 排序

###### 在MongoDB中使用使用sort()方法对数据进行排序，sort()方法可以通过参数指定排序的字段，并使用 1 和 -1 来指定排序的方式，其中 1 为升序排列，而-1是用于降序排列。

db.集合名.find().sort({key:1|-1})  #升序或者降序

例如:

​	db.user.find().sort({age:1})  #查询所有数据 按照年龄 升序

​	db.user.find().sort({age:-1})  #查询所有数据 按照年龄 降序

### 七 创建索引 ensureIndex() 方法

MongoDB使用 ensureIndex() 方法来创建索引。

#### 语法

ensureIndex()方法基本语法格式如下所示：

```python
>db.COLLECTION_NAME.ensureIndex({KEY:1})
```

语法中 Key 值为你要创建的索引字段，1为指定按升序创建索引，如果你想按降序来创建索引指定为-1即可。

#### 实例

```python
>db.col.ensureIndex({"title":1})
```

ensureIndex() 方法中你也可以设置使用多个字段创建索引（关系型数据库中称作复合索引）。

```python
>db.col.ensureIndex({"title":1,"description":-1})
```

### 八  删除数据库

1. 删除之前 最好use一下
2. db.dropDatabase()

### 九  数据库的退出

​	exit

### 十 MongoDB 备份(mongodump)与恢复(mongorestore)

##### 备份:

```
>mongodump -h dbhost -d dbname -o dbdirectory
```

- **-h：**MongDB所在服务器地址，例如：127.0.0.1，当然也可以指定端口号：127.0.0.1:27017
- **-d：**需要备份的数据库实例，例如：test
- **-o：**备份的数据存放位置，例如：c:\data\dump，当然该目录需要提前建立，在备份完成后，系统自动在dump目录下建立一个test目录，这个目录里面存放该数据库实例的备份数据。

在本地使用 27017 启动你的mongod服务。打开命令提示符窗口，进入MongoDB安装目录的bin目录输入命令mongodump:

```python
>mongodump -h127.0.0.1 -ddemo -o C:\mongodb
```

##### MongoDB数据恢复

mongorestore命令脚本语法如下：

```python
>mongorestore -h <hostname><:port> -d dbname <path>
```

- **--host <:port>, -h <:port>：**MongoDB所在服务器地址，默认为： localhost:27017
- **--db , -d ：**需要恢复的数据库实例，例如：test，当然这个名称也可以和备份时候的不一样，比如test2
- **--drop：**恢复的时候，先删除当前数据，然后恢复备份的数据。就是说，恢复后，备份后添加修改的数据都会被删除，慎用哦！
- **<path>：**mongorestore 最后的一个参数，设置备份数据所在位置，例如：c:\data\dump\test。你不能同时指定 <path> 和 --dir 选项，--dir也可以设置备份目录。
- **--dir：**指定备份的目录你不能同时指定 <path> 和 --dir 选项。

mongodb使用 mongorestore 命令来恢复备份的数据。

```python
mongorestore -h127.0.0.1 -ddemo  C:\mongodb\demo(备份数据所在的位置)
```

##### 注意：

不管是备份还是恢复数据 都先将服务运行起来 再次新建终端 来执行备份或者恢复的命令