from django.shortcuts import render
from .models import Grade


def grade_list(request):
    
    g_list = Grade.objects.all()  # 获取Grade中的所有数据
    
    return render(request, 'grades/list.html', {'g_list': g_list})
    

