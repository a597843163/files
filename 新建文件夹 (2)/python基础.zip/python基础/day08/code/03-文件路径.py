

# 文件路径：
#   相对路径： 相对于当前文件的路径，如："情书.txt", "..\day08.xmind"
#   绝对路径： 完整的路径,包括盘符，如：C:\wamp\www\day08\code\情书.txt
#                                   C:\wamp\www\day08\day08.xmind
#
#   ..表示父级(上一层目录), .表示当前目录
#

# filePath = "C:\\wamp\\www\\day08\\code\\情书.txt"
# filePath = r"C:\wamp\www\day08\code\情书.txt"
# fp = open(filePath, "r", encoding="utf-8")
#
# content = fp.read()
# print(content)
#
# fp.close()


# try:
#     fp = None
#     fp = open(r"C:\wamp\www\day08\code\情书3.txt", "r", encoding="utf-8")
#     print(fp.read())
# except:
#     print("文件打开出错")
# finally:
#     # pass
#     if fp != None:
#         fp.close()


# with..as : 简化文件操作的代码，可以自动关闭文件
with open(r"C:\wamp\www\day08\code\情书.txt", "r", encoding="utf-8") as fp:
    print(fp.read())


