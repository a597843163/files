from django.db import models
from tinymce.models import HTMLField


class Blog(models.Model):
    name = models.CharField(max_length=30)
    content = HTMLField()  # 富文本输入框

