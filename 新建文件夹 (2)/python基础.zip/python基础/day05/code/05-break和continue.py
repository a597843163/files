

'''

    break: 终止当前循环

    continue: 只终止当次循环，继续执行下一次循环

'''


# 4,判断一个数是不是合数。(指自然数中除了能被1和本身整除外，还能被其他的数整除（不包括0)的数。)
n = 24
i = 2
while i < n:
    if n % i == 0:
        print(n, "是合数")
        break
    i += 1

# 非诚勿扰，从1号到24号，找到20号美女
i = 1
while i <= 24:
    if i == 20:
        print("找到了20号美女")
        print("break之前的语句")
        break  # 终止整个while循环，break之后的语句不会执行
        print("break之后的语句")
    i += 1

print("i =", i)


# break只会终止当前的循环，只会终止一层循环
i = 1
while i <= 5:

    j = 1
    while j <= 3:
        if j == 2:
            break  # 只会终止里面的这一层循环
        print("i =", i, ",j =", j)
        j += 1

    i += 1



# 6,求整数1～100的累加值，但要求跳过所有个位为3的数。
sum = 0
i = 1
while i <= 100:
    if i%10 == 3:
        i += 1
        print("continue之前的语句")
        continue  #终止当次循环，进入下一次循环， continue之后的语句也不会执行
        print("continue之后的语句")
    sum += i
    i += 1

print(sum)


sum = 0
i = 1
while i <= 100:
    if i%10 == 3:
        pass
    else:
        sum += i
    i += 1

print(sum)
