import socket

# 协议
# tcp
# udp

print("_________________tcp服务端_____________________")

# tcp
# 客户端   SOCK_STREAM

# 创建服务端
serverSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
# 绑定服务端IP
#  ip :"10.36.137.48"  端口 : 8252
serverSocket.bind(("10.36.137.48",8252))
#  设置最大监听数
serverSocket.listen(5)
# 接受客户端信息
clientSocket ,address =serverSocket.accept()
# 接受/发送数据给客户端
while True:

    #  接受
    res = serverSocket.recv(1024)
    print(res.decode("utf-8"))

    # 发送
    sendStr = ""
    clientSocket.send(sendStr.encode("utf-8"))

# 关闭链接
clientSocket.close()

print("_________________tcp客户端_____________________")

# 创建客户端对象
clientSocket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
# 链接服务端ip
clientSocket.connect(("10.36.137.48",8252))
while True:
    # 发送
    clientSocket.send(("hello").encode("utf-8"))
    # 接受
    res = clientSocket.recv(1024)
    print(res.decode("utf-8"))

print("________________udp服务端_____________________")

#  创建udp服务端
udpsocket = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

# 绑定ip
udpsocket.bind(("10.36.137.48",8252))

# 接收
while True:
    #  返回数据和地址
    data,adress = udpsocket.recvfrom(1024)
    print(data.decode("utf-8"))
    #  发送
    udpsocket.sendto(("hello").encode("utf-8"))

print("________________udp客户端_____________________")

# 创建对象
udpclientsocket = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

# 直接发送
while True:
    # 发送
    sendStr = "hello"
    udpclientsocket.sento(sendStr.encode("utf-8"),("10.36.137.48",8252))
    # 接收
    data,address1 = udpclientsocket.recvfrom(1024)
    print(data.decode("utf-8"))
    print(address1)

